from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('algorithm.html', views.algo),
    path('agglomerative.html', views.aggloCluster),
]
