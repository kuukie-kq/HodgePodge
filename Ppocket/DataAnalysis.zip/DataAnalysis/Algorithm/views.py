from django.shortcuts import render

# Create your views here.


def home(request):
    return algo(request)


def algo(request):
    return render(request, 'algorithm.html')


def aggloCluster(request):
    return render(request, 'agglomerative.html')
