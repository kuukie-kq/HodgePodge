from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
import json

# Create your views here.
"""
层次聚类
"""

"""
确定聚类数量的聚类

请求json
{
    'method': *str, //可选 return disk
    'tableName': *str, //数据源 数据所在路径
    'tableColumnNames': *list<str>, //数据源对应的列名
    'unfitColumnNames': *list<str>, //不拟合的列
    'clusters': *int, //聚类数量
可选 
    'resultName': *str //return情况下为返回格式 disk情况下为文件路径
    视情况 resultName的值为json字符串
}
"""


def quantityCluster(request):
    if request.method == "POST":
        if request.POST.get('method') == "return":
            resultData = fitModelLearn(request)
            if request.POST.get('resultName') == 'jpg':
                pass
            else:
                return HttpResponse(content=json.dumps(resultData), content_type="application/json", status=200)
        elif request.POST.get('method') == 'disk':
            resultData = fitModelLearn(request)
            resultData.to_csv(request.POST.get('resultName'), sep=',', header=True, index=False)
            return JsonResponse({'result': 0, 'return': request.POST.get('resultName')})
        else:
            return JsonResponse({'result': -1, 'message': 'request body error'})
    else:
        return JsonResponse({'result': -2, 'message': 'request method error'})


"""
层次聚类核心
1)pandas 数据集对象
2)数据预处理
3)设定模型算法
4)拟合
5)结果返回
"""


def fitModelLearn(request):
    sourceData = pd.read_csv(request.POST.get('tableName'), header=None, names=request.POST.getlist('tableColumnNames'), skiprows=1)
    sourceData.drop(request.POST.getlist('unfitColumnNames'), axis=1, inplace=True)
    ago = AgglomerativeClustering(n_clusters=int(request.POST.get('clusters')))
    ago.fit(sourceData)
    sourceData['fit'] = ago.labels_
    return sourceData
