package main.java.com;

public class FlagTest implements TestOne {
    private int flag = 0;

    @Override
    public int loop() {
        if (flag < 0) {
            return 1;
        } else if (flag > 18) {
            System.out.println(flag);
            flag = 0;
            return 1;
        } else {
            System.out.print(flag + "\t");
            flag++;
            return 0;
        }
    }
}

