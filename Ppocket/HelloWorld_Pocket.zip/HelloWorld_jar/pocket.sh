#!/bin/bash
:<<!
一个代表包路径的参数
以/号分割例如 main/java/com/
!
package=$1
echo "${package}"
echo "${package//\//.}"

echo -e "The start \n"

cp HelloWorld_Primitive.jar HelloWorld.jar

echo -e "javac -cp HelloWorld.jar FlagTest.java \n"
javac -cp HelloWorld.jar FlagTest.java
mkdir --parents ${package} ;mv FlagTest.class $_

echo -e "jar -uvf HelloWorld.jar main/java/com/FlagTest.class \n"
jar -uvf HelloWorld.jar ${package}FlagTest.class

echo -e "java -jar HelloWorld.jar main.java.com.FlagTest \n"
java -jar HelloWorld.jar ${package//\//.}FlagTest

rm -rf ${package%%/*}
rm HelloWorld.jar

echo "The end"

