//
// Created by kuu-kie on 2022/7/8.
// 可以不使用extern关键字，extern意思为外部实现函数
// 这里使用是避免多个include导致的多次申明，无影响
//

#ifndef CUSTOMPROTOCOLANALYSIS_PROTOCOL_ANALYSIS_MAIN_H
#define CUSTOMPROTOCOLANALYSIS_PROTOCOL_ANALYSIS_MAIN_H

#include "src/pcap_file_analysis.h"

extern int dump_analysis_main();

#endif //CUSTOMPROTOCOLANALYSIS_PROTOCOL_ANALYSIS_MAIN_H
