#include <iostream>
#include "protocol_analysis_main.h"

int main() {
    system("chcp 65001");
    std::cout << "The start line ==== 起跑线" << std::endl;
    dump_analysis_main();
    std::cout << "The end line ==== 终点线" << std::endl;
    return 0;
}

// 思路
// 第一步，函数定义，main函数，程序入口
// 第二步，读取文件并获取pcap文件的头部信息，main函数中的两个步骤
// 第三步，底层协议的解析，以及一些粘包粘包分组问题
// 第四步，应用层数据解析，由于粘包问题，需要进行循环操作 >.<不可避免的粘包，数据包不大，但太快，使处理队列堆积，形成多包。

// 文件结构
// protocol_analysis_main 主函数，相当于main
//      shared_data 全局变量 read_analysis analysis ERRORCODE
// pcap_file_analysis 调用的read_analysis，思路中的第二步
//      ether_analysis struct fopen 全局变量 ERRORCODE
// global_protocol_analysis 调用的ether_analysis以及相关的函数，思路中的第三步
//      special_not_analysis struct ERRORCODE
// cache_protocol_analysis 调用的special_not_analysis，作为数据的缓冲区将思路中的第三步第四步分开，同时处理tcp分组的情况
//      data_response_analysis data_request_analysis 全局变量 ERRORCODE struct
// reflection_struct 解析所用到的结构体
//
// custom_protocol_analysis 调用的data**analysis，思路中的第四步 >.<不可避免的粘包，数据包不大，但太快，使处理队列堆积，形成多包
//      ERRORCODE read_data 全局变量 display_client_to_server display_server_to_client
// read_data_utils 调用的read_data，作为一个工具
//
// not_own_xcode 调用的display***，属于自定义协议的相关解释
//
// global_use_variable 全局变量以及相关的魔法数字和ERRORCODE，含有include<>
//
// >*<特殊文件
// global_base_define 本项目中使用到的所有类型，既所有文件都可能用到的
