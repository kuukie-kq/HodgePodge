//
// Created by kuu-kie on 2022/7/8.
//

#include "protocol_analysis_main.h"

int dump_analysis_main() {
    try {
        SDD = new shared_data("../GxAI.dll");
        SDDCCF = new shared_data("../GxAL.dll");
        read_analysis("../202207151442.pcap");
        analysis();
    } catch (ERRORCODE e) {
        switch (e) {
            case DLL_FILE_NOT_FOUND:
                // 没有找到加密解密加压解压的文件，请确认路径是否正确
                printf("\nerror(0x%X)DLL_FILE_NOT_FOUND\t没有找到加密解密加压解压的文件，请确认路径是否正确\n", (u1_int)DLL_FILE_NOT_FOUND);
                break;
            case DLL_FUNCTION_NOT_FOUND:
                // 没有找到dll文件内的对应函数，请确认函数名是否正确
                printf("\nerror(0x%X)DLL_FUNCTION_NOT_FOUND\t没有找到dll文件内的对应函数，请确认函数名是否正确\n", (u1_int)DLL_FUNCTION_NOT_FOUND);
                break;
            case DATA_LENGTH_READ_FAILED:
                // 读取数据的长度有问题
                printf("\nerror(0x%X)DATA_LENGTH_READ_FAILED\t读取数据的长度有问题\n", (u1_int)DATA_LENGTH_READ_FAILED);
                break;
            case DATA_TOO_SMALL:
                // 数据部分的长度太小，可能不是业务包
                printf("\nerror(0x%X)DATA_TOO_SMALL\t数据部分的长度太小，可能不是业务包\n", (u1_int)DATA_TOO_SMALL);
                break;
            case DATA_PACKAGE_LENGTH_FAILED:
                // 业务包的长度读取有问题，可能粘包粘包
                printf("\nerror(0x%X)DATA_PACKAGE_LENGTH_FAILED\t业务包的长度读取有问题，可能粘包粘包\n", (u1_int)DATA_PACKAGE_LENGTH_FAILED);
                break;
            case PACKAGE_HAVE_NO_DATA:
                // 业务包中没有数据，难道是心跳包
                printf("\nerror(0x%X)PACKAGE_HAVE_NO_DATA\t业务包中没有数据，难道是心跳包\n", (u1_int)PACKAGE_HAVE_NO_DATA);
                break;
            case DATA_CRC_ERROR:
                // 魔法数字crc不正确，可能是没有进行init
                printf("\nerror(0x%X)DATA_CRC_ERROR\t魔法数字crc不正确，可能是没有进行init\n", (u1_int)DATA_CRC_ERROR);
                break;
            case NORMAL_FILE_NOT_FOUND:
                // 没有找到读取的pcap文件
                printf("\nerror(0x%X)NORMAL_FILE_NOT_FOUND\t没有找到读取的pcap文件\n", (u1_int)NORMAL_FILE_NOT_FOUND);
                break;
            case NOT_PRIMARY_TASK:
                // 这条报文不是程序需要解析的
                printf("\nerror(0x%X)NOT_PRIMARY_TASK\t这条报文不是程序需要解析的\n", (u1_int)NOT_PRIMARY_TASK);
                break;
            case NOT_DATA_NOT_PADDING:
                // 这条报文既不是数据，也不是数据链路层填充的
                printf("\nerror(0x%X)NOT_DATA_NOT_PADDING\t这条报文既不是数据，也不是数据链路层填充的\n", (u1_int)NOT_DATA_NOT_PADDING);
                break;
            case LENGTH_MORETHEN_MAX:
                // 这条报文的最大长度大于1514，可能是传参出错
                printf("\nerror(0x%X)LENGTH_MORETHEN_MAX\t这条报文的最大长度大于1514，可能是传参出错\n", (u1_int)LENGTH_MORETHEN_MAX);
                break;
            case STATIC_MEMORE_ERROR:
                // 作为分组拼包的内存出错
                printf("\nerror(0x%X)NOT_PRIMARY_TASK\t作为分组拼包的内存出错\n", (u1_int)STATIC_MEMORE_ERROR);
                break;
            case NOT_SYN_FIN_BUT_ACK:
                // 这条报文不是连接断开连接，也不是push&ack，但是属于有ack包
                printf("\nerror(0x%X)NOT_PRIMARY_TASK\t这条报文不是连接断开连接，也不是push&ack，但是属于有ack包\n", (u1_int)NOT_SYN_FIN_BUT_ACK);
                break;
            case NOT_ACK_BUT_DATA:
                // 这条报文不是ack包，但是有数据，可能是筛选条件漏了
                printf("\nerror(0x%X)NOT_PRIMARY_TASK\t这条报文不是ack包，但是有数据，可能是筛选条件漏了\n", (u1_int)NOT_ACK_BUT_DATA);
                break;
            default:
                printf("\nerror(0x%X)????\tunknow code %u\n", (u1_int)e, (u1_int)e);
                break;
        }
    }
    delete SDDCCF;
    delete SDD;
    return 0;
}
