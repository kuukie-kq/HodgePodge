//
// Created by Admin on 2022/7/11.
//

#ifndef CUSTOMPROTOCOLANALYSIS_UP_AND_DOWN_H
#define CUSTOMPROTOCOLANALYSIS_UP_AND_DOWN_H

#include <iostream>
#include <winsock2.h>
using namespace std;

class up_and_down {/*
private:
    using init = int(*)(int);
    using up = int (*)(int, void*, int);
    typedef unsigned char u1_int;
public:
    HINSTANCE dll_file;
    init gaxi_init;
    up gxai_up;
    up_and_down();
    ~up_and_down();

    void test_up();
*/};


#endif //CUSTOMPROTOCOLANALYSIS_UP_AND_DOWN_H
