//
// Created by kuu-kie on 2022/7/8.
// 对于一个长串，从头一点一点读数据的相关函数
//

#ifndef CUSTOMPROTOCOLANALYSIS_READ_DATA_UTILS_H
#define CUSTOMPROTOCOLANALYSIS_READ_DATA_UTILS_H

#include "global_use_variable.h"

extern int read_data(u1_int*& data, int& len, u4_int& read, int read_len);
extern int read_data(u1_int*& data, int& len, u2_int& read, int read_len);
extern int read_data(u1_int*& data, int& len, u1_int& read, int read_len);
extern int read_data(u1_int*& data, int& len, u1_int*& read, int read_len);

#endif //CUSTOMPROTOCOLANALYSIS_READ_DATA_UTILS_H
