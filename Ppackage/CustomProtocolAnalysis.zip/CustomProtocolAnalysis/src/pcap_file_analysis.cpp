//
// Created by kuu-kie on 2022/7/8.
//

#include "pcap_file_analysis.h"

int read_analysis(const char* const file) {
    file_pcap_header fileh;
    pcap_header pcaph;
    int count = NUMBER_ZERO;
    void* buff = nullptr;

    FILE* fp = fopen(file, "rb");
    if (fp == nullptr) { throw NORMAL_FILE_NOT_FOUND; }
    fread(&fileh, sizeof(file_pcap_header), NUMBER_ONE, fp);
    // display pcap文件头信息
    #ifdef DISPLAY1
    printf("pcap file header message :\n\tmagic:%d\n\tversion_major:%d\n\tversion_minor:%d\n\tthiszone:%d\n\tsigfigs:%d\n\tsnaplen:%d\n\tlinktype:%d\n",
           fileh.magic, fileh.version_major, fileh.version_minor, fileh.thiszone, fileh.sigfigs, fileh.snaplen, fileh.linktype);
    #endif // DISPLAY1

    buff = (void*)malloc(MTU_PACKET_LENGTH + ETHER_HEAD_LENGTH);
    for (count = NUMBER_ONE;; count++) {
        if (fread(&pcaph, sizeof(pcap_header), NUMBER_ONE, fp) <= NUMBER_ZERO) { break; }
        // display pcap保存的每一个包的包头信息，因为是二进制文件，所以要先读固定长度，再读变长，既包与包之间是紧密相连的
        #ifdef DISPLAY1
        printf("\n(%d) time: %ds%dms\tcapture_len:%d\tframe_len:%d\n",
               count, pcaph.ts_seconds, pcaph.ts_millisecond, pcaph.capture_len, pcaph.len);
        #endif // DISPLAY1

        SDD->tss = pcaph.ts_seconds;
        SDD->tsm = pcaph.ts_millisecond;
        memset(buff, NUMBER_ZERO, MTU_PACKET_LENGTH + ETHER_HEAD_LENGTH);
        fread(buff, pcaph.capture_len, NUMBER_ONE, fp);

        ether_analysis(buff, pcaph.capture_len);

        if (feof(fp)) { break; }
    }
    free(buff);
    fclose(fp);
    return 0;
}
