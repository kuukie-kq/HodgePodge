//
// Created by kuu-kie on 2022/7/8.
// 应用层协议解析，分为两种
//

#ifndef CUSTOMPROTOCOLANALYSIS_CUSTOM_PROTOCOL_ANALYSIS_H
#define CUSTOMPROTOCOLANALYSIS_CUSTOM_PROTOCOL_ANALYSIS_H

#include "read_data_utils.h"
#include "not_own_xcode.h"
#include "global_use_variable.h"

extern void data_request_analysis(u1_int* data, int len);
extern void data_response_analysis(u1_int* data, int len);
extern void data_package(u1_int* data, int len);
extern void process_package(int cmd, int fmt, u1_int* data, int size);

#endif //CUSTOMPROTOCOLANALYSIS_CUSTOM_PROTOCOL_ANALYSIS_H
