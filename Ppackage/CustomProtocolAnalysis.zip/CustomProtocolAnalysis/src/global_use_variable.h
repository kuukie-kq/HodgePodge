//
// Created by kuu-kie on 2022/7/8.
// 相当于最顶层
// 使用到的
//      iostream作为控制台输出
//      WinSock2为ntohs等网络相关库且只适合windows下
//      queue作为中间缓存
//      chrono为时间库，用于时间的输出，且visual studio下还需包含ctime，locale
//

#ifndef CUSTOMPROTOCOLANALYSIS_GLOBAL_USE_VARIABLE_H
#define CUSTOMPROTOCOLANALYSIS_GLOBAL_USE_VARIABLE_H

#include <iostream>
#include <winsock2.h>
#include <queue>
#include <chrono>
#include "global_base_define.h"

enum ERRORCODE {
    DLL_FILE_NOT_FOUND = 0xCC,
    DLL_FUNCTION_NOT_FOUND = 0xCD,
    DATA_LENGTH_READ_FAILED = 0xDC,
    DATA_TOO_SMALL = 0xDD,
    DATA_PACKAGE_LENGTH_FAILED = 0xDE,
    PACKAGE_HAVE_NO_DATA = 0xDF,
    DATA_CRC_ERROR = 0xD9,
    NORMAL_FILE_NOT_FOUND = 0xEC,
    NOT_PRIMARY_TASK = 0xFC,

    NOT_DATA_NOT_PADDING = 0xBC,
    LENGTH_MORETHEN_MAX = 0xBD,
    STATIC_MEMORE_ERROR = 0xBE,
    NOT_SYN_FIN_BUT_ACK = 0xBF,
    NOT_ACK_BUT_DATA = 0xB7,
};

enum USINGNUMBER {
    // Number
    NUMBER_ZERO = 0,
    NUMBER_ONE = 1,
    NUMBER_TWO = 2,
    NUMBER_FOUR = 4,
    NUMBER_SIX = 6,
    NUMBER_NINE = 9,
    NUMBER_ELEVEN = 11,
    //
    NANO_FROM_SECOND = 1000000000,
    NANO_FROM_MILLISECOND = 1000000,
    NANO_FROM_MICROSECOND = 1000,
    // Bitoperation
    FIRST_14 = 0x3FFF,
    LAST_2 = 14u,
    SECOND_TCP_SYN = 0x02,
    SECOND_TCP_PSH = 0x08,
    SECOND_TCK_ACK = 0x10,
    // Length
    ETHER_HEAD_LENGTH = 14,
    IPV4_FIXED_HEAD_LENGTH = 20,
    TCP_FIXED_HEAD_LENGTH = IPV4_FIXED_HEAD_LENGTH,
    MTU_PACKET_LENGTH = 1500,
    // IEEE以太网帧最大为1518，14+1500+4crc
    // InternetV2以太网帧最大为1512加入了VLEN的支持
    // 0x0600 = 1536 为最大帧长度
    // Type
    TYPE_IPV4 = 0x0800,
    TYPE_IPV6 = 0x86DD,
    TYPE_ARP = 0x0806,
    TYPE_RARP = 0x0835,
    // Proto
    IP_PROTO_ICMP = 1,
    IP_PROTO_TCP = 6,
    IP_PROTO_UDP = 17,
    // tcp data flags
    TCP_DATA_PSH_ACK = 0x18,
    // Dll
    CLIENT_START = 0x0000,
    CLIENT_CONNECT = 0x0001,
    MASK_ENCRYPT = CLIENT_CONNECT,
    MASK_COMPRESS = 0x0002,
    MAX_COMPRESS_LENGTH = 1024 * 512,
    OUT_MESSAGE_LENGTH = 1024,
    // Magic Number
    CRC_NUMBER = 12345678,
    // MyPort
    MY_SERVER_TCP_PORT = 38301,
    MY_SERVER_UDP_PORT = 26400,
};

class shared_data {
private:
    using init = int(*)(int);
    using down = int(*)(int, void*, int);
    using ver = void(*)(int&, int&, int&, int&);
    using uncp = int(*)(u1_int*, int*, u1_int*, int);
    HINSTANCE dll_file;
public:
    // dll
    init gaxi_init;
    down gxai_down;
    ver gxai_version;
    uncp gxai_uncompress;
    // 缓冲区
    std::queue<u1_int*> buf;
    std::queue<int> cnt;
    // static
    std::queue<bool> bcs;
    std::queue<std::chrono::nanoseconds> timestamp;
    u4_int tss;
    u4_int tsm;
    u1_int* gcs;
    u4_int gss;
    // 解压缓冲
    u1_int* compress_byte;
    int* compress_len;
    // 简单业务逻辑
    int last_port;
    std::queue<int> port;
    // unused
    char* message;

    explicit shared_data(const char* file = "GxAI.dll");
    ~shared_data();
};

extern shared_data* SDD;
extern shared_data* SDDCCF;

#endif //CUSTOMPROTOCOLANALYSIS_GLOBAL_USE_VARIABLE_H
