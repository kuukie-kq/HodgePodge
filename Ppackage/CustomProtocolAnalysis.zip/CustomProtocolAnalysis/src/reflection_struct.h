//
// Created by kuu-kie on 2022/7/8.
// 协议格式对应的结构体，使用指针进行强制转换，可以直接获取对应的内容，而不需要自己去拼
//

#ifndef CUSTOMPROTOCOLANALYSIS_REFLECTION_STRUCT_H
#define CUSTOMPROTOCOLANALYSIS_REFLECTION_STRUCT_H

#include "global_base_define.h"

typedef struct file_pcap_header file_pcap_header;
typedef struct pcap_header pcap_header;
typedef struct eth_header eth_header;
typedef struct ip_header ip_header;
typedef struct icmp_header icmp_header;
typedef struct tcp_header tcp_header;

struct file_pcap_header {
    u4_int magic;//4B 标记文件开始，并用来识别文件和字节顺序
    u2_int version_major;//2B 当前文件的主要版本号
    u2_int version_minor;//2B 当前文件的次要版本号
    int thiszone;//4B 当地的标准事件
    u4_int sigfigs;//4B 时间戳精度
    u4_int snaplen;//4B 最大存储长度
    u4_int linktype;//4B 链路类型
    //共24B
};

struct pcap_header {
    u4_int ts_seconds;//4B
    u4_int ts_millisecond;//4B
    u4_int capture_len;//4B
    u4_int len;//4B
    //共16B
};

//7字节前导同步码＋1字节帧开始定界符＋6字节的目的MAC＋6字节的源MAC＋2字节的帧类型＋1500（ip数据包的最大限制）＋4字节的FCS
//共1526 B
//网卡会去掉（前导同步码，帧开始定界符，FCS）实际最大字节为1514 B

struct eth_header {
    u1_int des_address[6];//6B 目的mac地址
    u1_int src_address[6];//6B 源mac地址
    u2_int next_type;//2B 下一层协议类型
    //共14B
};

struct ip_header {
    u2_int version : 4;//4b 版本
    u2_int header_length : 4;//1B 4b版本+4b首部长度
    u2_int differentiated : 8;//1B 服务类型
    u2_int total_length : 16;//2B 总长度
    u2_int identification : 16;//2B 标识
    u2_int flag : 3;//3b 标志
    u2_int fragment_offset : 13;//2B 3b标志+13b片偏移
    u2_int time_to_live : 8;//1B 生成时间
    u2_int protocol : 8;//1B 协议
    u2_int header_check_count : 16;//2B 首部校验和
    u1_int src_ip_address[4];//4B 源ip地址
    u1_int des_ip_address[4];//4B 目的ip地址
    //共20B 使用位域的方式来匹配对应细节字段 注意，位域需要用较大的同种类型定义
};

struct icmp_header {
    u1_int kind;//1B 类型
    u1_int code;//1B 代码
    u2_int check_count;//2B 校验和
    u2_int identification;//2B 标识
    u2_int serial;//2B 序号
    //共8B
};

struct tcp_header {
    u2_int src_port;//2B 源端口
    u2_int des_port;//2B 目的端口
    u4_int sequence;//4B 序号
    u4_int acknowledgement;//4B 确认序号
    u1_int offset;//4b+4b 首部长度以及4个保留位
    u1_int flags;//2b+6b 2个保留位以及6个标志位，URG、ACK、PSH、RST、SYN、FIN
    u2_int windows;//2B 窗口大小
    u2_int check_count;//2B 校验和
    u2_int urgent_pointer;//2B 紧急指针
    //共20B
};

#endif //CUSTOMPROTOCOLANALYSIS_REFLECTION_STRUCT_H
