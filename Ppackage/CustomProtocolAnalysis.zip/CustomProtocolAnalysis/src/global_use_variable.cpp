//
// Created by kuu-kie on 2022/7/8.
//

#include "global_use_variable.h"

shared_data::shared_data(const char* const file) {
    dll_file = LoadLibrary(file);
    if (dll_file == nullptr) { throw DLL_FILE_NOT_FOUND; }
    gaxi_init = (init)GetProcAddress(dll_file, "GXAI_PPC_Init");
    gxai_down = (down)GetProcAddress(dll_file, "GXAI_PPC_Down");
    gxai_version = (ver)GetProcAddress(dll_file, "GXAI_GetVersion");
    gxai_uncompress = (uncp)GetProcAddress(dll_file, "GXAI_Zlib_uncompress");
    if (gaxi_init == nullptr) { throw DLL_FUNCTION_NOT_FOUND; }
    if (gxai_down == nullptr) { throw DLL_FUNCTION_NOT_FOUND; }
    if (gxai_version == nullptr) { throw DLL_FUNCTION_NOT_FOUND; }
    if (gxai_uncompress == nullptr) { throw DLL_FUNCTION_NOT_FOUND; }
    tss = (u4_int)NUMBER_ZERO;
    tsm = (u4_int)NUMBER_ZERO;
    gcs = nullptr;
    gss = (u4_int)NUMBER_ZERO;
    compress_byte = nullptr;
    compress_len = nullptr;
    last_port = 0;
    message = nullptr;
}

shared_data::~shared_data() {
    FreeLibrary(dll_file);
}

// 全局变量
shared_data* SDD = nullptr;
shared_data* SDDCCF = nullptr;
