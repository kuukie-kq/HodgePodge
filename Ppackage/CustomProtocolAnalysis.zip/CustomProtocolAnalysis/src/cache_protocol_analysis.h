//
// Created by kuu-kie on 2022/7/8.
// 生产者消费者模型，使用queue作为中间缓存
//

#ifndef CUSTOMPROTOCOLANALYSIS_CACHE_PROTOCOL_ANALYSIS_H
#define CUSTOMPROTOCOLANALYSIS_CACHE_PROTOCOL_ANALYSIS_H

#include "reflection_struct.h"
#include "custom_protocol_analysis.h"

extern int analysis();
extern void special_not_analysis(const tcp_header* tcp, const void* packet, int length);

#endif //CUSTOMPROTOCOLANALYSIS_CACHE_PROTOCOL_ANALYSIS_H
