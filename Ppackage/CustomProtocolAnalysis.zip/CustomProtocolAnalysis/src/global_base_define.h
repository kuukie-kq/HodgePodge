//
// Created by kuu-kie on 2022/7/8.
// 实际上的最顶层
// 对无符号类型进行缩减申明
// 剩下的可以看成是配置文件
//

#ifndef CUSTOMPROTOCOLANALYSIS_GLOBAL_BASE_DEFINE_H
#define CUSTOMPROTOCOLANALYSIS_GLOBAL_BASE_DEFINE_H

typedef unsigned int u4_int;
typedef unsigned short u2_int;
typedef unsigned char u1_int;

//#define DISPLAY1	//一阶段，解析文件头
//#define DISPLAY2	//二阶段，解析底层协议，数据链路层
//#define DISPLAY3	//三阶段，解析底层协议，网络层
//#define DISPLAY4	//四阶段，解析底层协议，传输层
//#define DISPLAY5	//五阶段，解析数据基本信息，以一个数据包为单位
//#define DISPLAY6	//六阶段，解析数据基本信息，以一条数据为单位
#define DISPLAY7	//七阶段，解析主要数据信息
//#define THROW_11	//单个数据解析异常，为了使程序继续执行，不抛异常

#endif //CUSTOMPROTOCOLANALYSIS_GLOBAL_BASE_DEFINE_H
