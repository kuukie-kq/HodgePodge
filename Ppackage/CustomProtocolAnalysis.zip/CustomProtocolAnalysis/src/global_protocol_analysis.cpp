//
// Created by kuu-kie on 2022/7/8.
//

#include "global_protocol_analysis.h"

void ether_analysis(const void* const packet, const int length) {
    eth_header* ethh = nullptr;
    u1_int* data = (u1_int*)packet;
    u1_int etht[ETHER_HEAD_LENGTH];
    for (int i = NUMBER_ZERO; i < length; i++) {
        if (i == ETHER_HEAD_LENGTH) {
            break;
        }
        if (i < ETHER_HEAD_LENGTH) {
            etht[i] = *data;
        }
        data++;
    }
    ethh = (eth_header*)etht;
    // display
    #ifdef DISPLAY2
    printf("源mac地址 %02x:%02x:%02x:%02x:%02x:%02x\t目的mac地址 %02x:%02x:%02x:%02x:%02x:%02x\t下一层协议值 0x%04X\n",
		ethh->src_address[0], ethh->src_address[1], ethh->src_address[2], ethh->src_address[3], ethh->src_address[4], ethh->src_address[5], ethh->des_address[0], ethh->des_address[1], ethh->des_address[2], ethh->des_address[3], ethh->des_address[4], ethh->des_address[5], ntohs(ethh->next_type));
    #endif // DISPLAY2

    if (ntohs(ethh->next_type) == TYPE_IPV4) {
        internet_analysis(data, length - ETHER_HEAD_LENGTH);
    } else {
        // pass
        throw NOT_PRIMARY_TASK;
    }
}

void internet_analysis(const void* const packet, const int length) {
    ip_header* iph;
    u1_int* data = (u1_int*)packet;
    u1_int ipt[IPV4_FIXED_HEAD_LENGTH];
    for (int i = NUMBER_ZERO; i < length; i++) {
        if (i == IPV4_FIXED_HEAD_LENGTH) {
            break;
        }
        if (i < IPV4_FIXED_HEAD_LENGTH) {
            ipt[i] = *data;
        }
        data++;
    }
    iph = (ip_header*)ipt;
    // display
    #ifdef DISPLAY3
    printf("源ip地址 %u.%u.%u.%u\t目的ip地址 %u.%u.%u.%u\t下一层协议值 %3d\n",
		iph->src_ip_address[0], iph->src_ip_address[1], iph->src_ip_address[2], iph->src_ip_address[3], iph->des_ip_address[0], iph->des_ip_address[1], iph->des_ip_address[2], iph->des_ip_address[3], iph->protocol);
    #endif // DISPLAY3

    if (iph->protocol == IP_PROTO_TCP) {
        transport_analysis(data, length - IPV4_FIXED_HEAD_LENGTH);
    } else {
        // pass
        throw NOT_PRIMARY_TASK;
    }
}

void transport_analysis(const void* const packet, const int length) {
    tcp_header* tcph;
    u1_int* data = (u1_int*)packet;
    u1_int tcpt[TCP_FIXED_HEAD_LENGTH];
    for (int i = NUMBER_ZERO; i < length; i++) {
        if (i == TCP_FIXED_HEAD_LENGTH) {
            break;
        }
        if (i < TCP_FIXED_HEAD_LENGTH) {
            tcpt[i] = *data;
        }
        data++;
    }
    tcph = (tcp_header*)tcpt;
    // display
    #ifdef DISPLAY4
    printf("源端口 %u\t目的端口 %u\t数据包类型 %3d\nThe End\n",
		tcph->src_port, tcph->des_port, tcph->flags);
    #endif // DISPLAY4

    // special 为应用层包，对应的应用层相关解析，这里只作为生产者
    special_not_analysis(tcph, data, length - TCP_FIXED_HEAD_LENGTH);
}
