//
// Created by Admin on 2022/7/8.
//

#include "not_own_xcode.h"

void display_client_to_server(const u2_int cmd) {
    switch ((eCTS)cmd) {
        case eCTS_Mark_Min:
            printf("{最小值，不使用}");
            break;
        case eCTS_CAAFS_LOGIN:
            printf("{登录CAAFS}");
            break;
        case eCTS_CAAFS_QUERY_HOME_LIST:
            printf("{获取home服列表}");
            break;
        case eCTS_CAAFS_QUERY_CLICFG:
            printf("{请求配置文件}");
            break;
        case eCTS_CLS_LOGIN:
            printf("{登录CLS}");
            break;
        case eCTS_ACCT_GET_INIT:
            printf("{获取所有角色数据}");
            break;
        case eCTS_CHAR_SELECT:
            printf("{选择一个角色进入游戏}");
            break;
        case eCTS_ACCT_NICK:
            printf("{创建角色}");
            break;
        case eCTS_Request:
            printf("{客户端回调协议}");
            break;
        case eCTS_GET_PING:
            printf("{获取网络延迟}");
            break;
        case eCTS_CHOOSE_HOME:
            printf("{选择home服，预留协议}");
            break;
        case eCTS_GET_SCN_SVR_LIST:
            printf("{获取场景列表}");
            break;
        case eCTS_CHANGE_SCN_SVR:
            printf("{切换场景服}");
            break;
        case eCTS_CAAFS_PRELOGIN:
            printf("{CAAFS预登陆，排队时检查是否有权限登录}");
            break;
        case eCTS_END_GAME:
            printf("{结束游戏}");
            break;
        case eCTS_DELETE_CHAR:
            printf("{删除角色}");
            break;
        case eCTS_TSS_ANTI:
            printf("{腾讯的数据}");
            break;
        case eCTS_REFRESH_TOKEN:
            printf("{刷新key token}");
            break;
        case eCTS_FCM_Notify:
            printf("{防沉迷提醒回包}");
            break;
        case eCTS_ScnObj_Mark_Min:
            printf("{场景相关分界线，未使用}");
            break;
        case eCTS_ScnObj_Flag:
            printf("{设置标志位}");
            break;
        case eCTS_ScnObj_Target:
            printf("{设置目标对象}");
            break;
        case eCTS_ScnObj_SKILL:
            printf("{释放技能}");
            break;
        case eCTS_ScnObj_GroupTrans:
            printf("{作废，未使用}");
            break;
        case eCTS_ScnObj_BreakSkill:
            printf("{作废，未使用}");
            break;
        case eCTS_ScnObj_DelState:
            printf("{作废，未使用}");
            break;
        case eCTS_ScnObj_PauseAutoFight:
            printf("{暂停自动战斗}");
            break;
        case eCTS_ScnObj_Mark_Max:
            printf("{场景相关分界线，未使用}");
            break;
        case eCTS_GMTool:
            printf("{GM命令相关，未使用}");
            break;
        case eCTS_TRAVEL_WORLD:
            printf("{大世界挂机的消息}");
            break;
        case eCTS_TRAVEL_SCN:
            printf("{场景挂机的消息}");
            break;
        case eCTS_PLAYER:
            printf("{仙侣相关}");
            break;
        case eCTS_Flower_Lamp:
            printf("{鲜花许愿}");
            break;
        case eCTS_GetMail:
            printf("{获取邮件}");
            break;
        case eCTS_UpdateMail:
            printf("{操作邮件}");
            break;
        case eCTS_SendMail:
            printf("{发送邮件测试操作}");
            break;
        case eCTS_ChangeEquip:
            printf("{更换装备}");
            break;
        case eCTS_RideUpAndDown:
            printf("{上下坐骑}");
            break;
        case eCTS_AddAtbPoint:
            printf("{玩家加属性点}");
            break;
        case eCTS_SetGuideFlag:
            printf("{新手引导设置}");
            break;
        case eCTS_SetCurrNovice:
            printf("{设置当前进行的新手教学，以便下次上线时触发}");
            break;
        case eCTS_Novice:
            printf("{新手教学相关}");
            break;
        case eCTS_Goout_WorldBoss:
            printf("{出大世界}");
            break;
        case eCTS_IntoArea:
            printf("{进区域}");
            break;
        case eCTS_OutArea:
            printf("{出区域}");
            break;
        case eCTS_GetTeamInfo:
            printf("{客户端打印队伍数量，用来检测数据是否正常}");
            break;
        case eCTS_Skill_Short_Change:
            printf("{快捷技能组切换}");
            break;
        case eCTS_GMTool_Log:
            printf("{GM要求客户端上传log}");
            break;
        case eCTS_GMTool_Bridge_Info:
            printf("{桥接的GM信息}");
            break;
        case eCTS_GMTool_Bridge_VarInfo:
            printf("{桥接的varinfo信息}");
            break;
        case eCTS_GMTool_Bridge_Command:
            printf("{桥接的command信息}");
            break;
        case eCTS_FPS_Stat:
            printf("{客户端FPS占位}");
            break;
        case eCTS_Tdbk_Zbg:
            printf("{eCTS_Tdbk_Zbg}");
            break;
        case eCTS_ClientLogSave:
            printf("{记录客户端log}");
            break;
        case eCTS_PlayerInfo:
            printf("{玩家数据相关}");
            break;
        case eCTS_ConfuseBattle:
            printf("{虫虫大乱斗}");
            break;
        case eCTS_SetFlyTouchDownEnable:
            printf("{同步地面自动下落}");
            break;
        case eCTS_GetWarcraftinfos:
            printf("{获取仙府信息}");
            break;
        case eCTS_WarcraftRace:
            printf("{仙府争霸竞价}");
            break;
        case eCTS_BattleField_ToRelation:
            printf("{仙府争霸消息torelation}");
            break;
        case eCTS_BattleField_ToScn:
            printf("{仙府争霸消息toscn}");
            break;
        case eCTS_Level:
            printf("{关卡相关}");
            break;
        case eCTS_Copy:
            printf("{副本相关}");
            break;
        case eCTS_ChgScn:
            printf("{切换场景}");
            break;
        case eCTS_LoadScnEnd:
            printf("{场景加载完毕}");
            break;
        case eCTS_OnPlayerInState:
            printf("{查询QQvip信息}");
            break;
        case eCTS_Team_Racing:
            printf("{eCTS_Team_Racing}");
            break;
        case eCTS_Team_Racing_To_Relation:
            printf("{eCTS_Team_Racing_To_Relation}");
            break;
        case eCTS_War_Team_Title:
            printf("{eCTS_War_Team_Title}");
            break;
        case eCTS_War_Team_Fight:
            printf("{eCTS_War_Team_Fight}");
            break;
        case eCTS_EternalAtb:
            printf("{永恒四属性}");
            break;
        case eCTS_ClearEvil:
            printf("{清除邪恶值}");
            break;
        case eCTS_onPKmode:
            printf("{切换PK模式}");
            break;
        case eCTS_Fabao_StepUp:
            printf("{法宝升阶}");
            break;
        case eCTS_Fabao_LevelUp:
            printf("{法宝升级}");
            break;
        case eCTS_Fabao_RankUp:
            printf("{法宝升等}");
            break;
        case eCTS_Fabao_Fumo:
            printf("{法宝附魔，未使用}");
            break;
        case eCTS_Skill_Select:
            printf("{技能选择替换}");
            break;
        case eCTS_UI_Chat:
            printf("{聊天}");
            break;
        case eCTS_UI_Chat_SendSystemChat:
            printf("{废弃}(2 same)");
            break;
            //case eCTS_UI_ChatVoice:
        case eCTS_UI_InnateUpdate:
            printf("{天赋升级}");
            break;
        case eCTS_UI_InnateReset:
            printf("{天赋重置}");
            break;
        case eCTS_UI_InnateConf:
            printf("{天赋互斥互换}");
            break;
        case eCTS_UI_InnateReqFreeReset:
            printf("{请求免费重置信息}");
            break;
        case eCTS_Fabao_SkillSelect:
            printf("{修改法宝技能}");
            break;
        case eCTS_VerAsset:
            printf("{自动下载的资源，用于MB动态下载}");
            break;
        case eCTS_Fly_Trans:
            printf("{飞行自动导航穿墙}");
            break;
        case eCTS_UI_Daily_Gift_Charge:
            printf("{请求最新的每日礼包信息}");
            break;
        case eCTS_Week_Rebate:
            printf("{周消费返利}");
            break;
        case eCTS_UI_FightTeamCfg:
            printf("{阵容配置相关}");
            break;
        case eCTS_UI_TalkOpen:
            printf("{对话开启}");
            break;
        case eCTS_UI_TalkClose:
            printf("{对话关闭}");
            break;
        case eCTS_UI_TalkChgSel:
            printf("{任务飞行结束同步状态}");
            break;
        case eCTS_UI_DelItem:
            printf("{道具消耗}");
            break;
        case eCTS_UI_UseItem:
            printf("{道具使用}");
            break;
        case eCTS_UI_SellItem:
            printf("{道具出售}");
            break;
        case eCTS_UI_NpcTalkStory:
            printf("{npc对话流程}");
            break;
        case eCTS_UI_TalkHandleCli:
            printf("{对话处理}");
            break;
        case eCTS_UI_TalkEnd:
            printf("{eCTS_UI_TalkEnd}");
            break;
        case eCTS_UI_DeathUIAck:
            printf("{死亡复活界面}");
            break;
        case eCTS_UI_Quest:
            printf("{eCTS_UI_Quest}");
            break;
        case eCTS_LevelFlag:
            printf("{手动升级}");
            break;
        case eCTS_UI_CommonInvite:
            printf("{通用邀请}");
            break;
        case eCTS_UI_CommonInviteAck:
            printf("{通用邀请答复}");
            break;
        case eCTS_UI_Disc:
            printf("{探索}");
            break;
        case eCTS_Title:
            printf("{称号}");
            break;
        case eCTS_Shortcut:
            printf("{快捷方式}");
            break;
        case eCTS_UI_GetFightValue:
            printf("{获取自己的各项战力}");
            break;
        case eCTS_UI_Pet_Pray:
            printf("{宠物祈福}");
            break;
        case eCTS_UI_TacticEnforce:
            printf("{宠物阵法强化}");
            break;
        case eCTS_UI_PetPvp:
            printf("{宠物pvp}");
            break;
        case eCTS_UI_PetFetter:
            printf("{宠物羁绊}");
            break;
        case eCTS_UI_Enchant:
            printf("{器灵}");
            break;
        case eCTS_UI_Rare:
            printf("{稀有度}");
            break;
        case eCTS_UI_Gem:
            printf("{宝石}");
            break;
        case eCTS_UI_EnforceLevelUp:
            printf("{强化}");
            break;
        case eCTS_UI_EquipMelt:
            printf("{装备熔炼}");
            break;
        case eCTS_UI_Ability:
            printf("{生活技能}");
            break;
        case eCTS_UI_Recipe:
            printf("{定向打造}");
            break;
        case eCTS_UI_Randmake:
            printf("{随机打造}");
            break;
        case eCTS_UI_Pet:
            printf("{宠物}");
            break;
        case eCTS_UI_OpenCDShop:
            printf("{打开冷却商店}");
            break;
        case eCTS_UI_BuyCDGoods:
            printf("{购买冷却商品}");
            break;
        case eCTS_UI_RefreshCDShop:
            printf("{刷新冷却商店}");
            break;
        case eCTS_UI_Auction:
            printf("{寄售行}");
            break;
        case eCTS_UI_PetStudy:
            printf("{宠物修行}");
            break;
        case eCTS_UI_PetBid:
            printf("{宠物拍卖}");
            break;
        case eCTS_UI_ItemBid:
            printf("{道具拍卖}");
            break;
        case eCTS_UI_RedPacket:
            printf("{红包}");
            break;
        case eCTS_Travel:
            printf("{挂机}");
            break;
        case eCTS_UI_Awaken:
            printf("{装备觉醒}");
            break;
        case eCTS_UI_OpenOrder:
            printf("{未完订单}");
            break;
        case eCTS_UI_Refine:
            printf("{装备洗炼}");
            break;
        case eCTS_UI_PetCol:
            printf("{宠物图鉴}");
            break;
        case eCTS_UI_SearchDist:
            printf("{eCTS_UI_SearchDist}");
            break;
        case eCTS_UI_Xianqi:
            printf("{仙器}");
            break;
        case eCTS_UI_Flower_ToRelation:
            printf("{鲜花torelation}");
            break;
        case eCTS_UI_Flower_ToScn:
            printf("{鲜花toscn}");
            break;
        case eCTS_UI_ItemCombine:
            printf("{淬炼}");
            break;
        case eCTS_UI_Transfer:
            printf("{转职}");
            break;
        case eCTS_UI_GuildBid:
            printf("{门派拍卖}");
            break;
        case eCTS_Ylg_BattleField:
            printf("{隐龙谷阵营战}");
            break;
        case eCTS_UI_Trade:
            printf("{新寄售交易}");
            break;
        case eCTS_UI_SecretBook:
            printf("{秘籍}");
            break;
        case eCTS_VipOnlineNotice:
            printf("{vip上线提醒}");
            break;
        case eCTS_LeaderTransfer:
            printf("{eCTS_LeaderTransfer}");
            break;
        case eCTS_TeamMember_Invite:
            printf("{邀请入队}");
            break;
        case eCTS_TeamLeave:
            printf("{离开队伍}");
            break;
        case eCTS_TeamJoin:
            printf("{请求入队}");
            break;
        case eCTS_TeamMerge:
            printf("{队伍合并}");
            break;
        case eCTS_TeamCreate:
            printf("{创建队伍}");
            break;
        case eCTS_TeamDismiss:
            printf("{解散队伍}");
            break;
        case eCTS_TeamFilter:
            printf("{组队招募相关}");
            break;
        case eCTS_TeamCall:
            printf("{仙友召唤符}");
            break;
        case eCTS_Col:
            printf("{风物志相关协议}");
            break;
        case eCTS_ZYT:
            printf("{镇妖塔相关协议}");
            break;
        case eCTS_TeamSyncPos:
            printf("{队友地图同步位置}");
            break;
        case eCTS_TeamHp:
            printf("{队友血量}");
            break;
        case eCTS_UI_AutoFight:
            printf("{自动战斗相关设置}");
            break;
        case eCTS_SeeOther:
            printf("{查看别人的属性}");
            break;
        case eCTS_GetSimpleInfo:
            printf("{获取别人一些属性}");
            break;
        case eCTS_GetZytActRank:
            printf("{获取镇妖塔活动的数据}");
            break;
        case eCTS_TravelLog:
            printf("{挂机日志}");
            break;
        case eCTS_Bestowal:
            printf("{传功}");
            break;
        case eCTS_Scn_Team:
            printf("{场景服组队相关信息}");
            break;
        case eCTS_Team_Follow:
            printf("{跟随}");
            break;
        case eCTS_Group:
            printf("{团队}");
            break;
        case eCTS_Group_Merge:
            printf("{团队合并}");
            break;
        case eCTS_Group_Apply:
            printf("{团队申请}");
            break;
        case eCTS_Group_Merge_Invite:
            printf("{邀请合并}");
            break;
        case eCTS_Group_Merge_Apply:
            printf("{申请合并}");
            break;
        case eCTS_Group_Merge_Invite_Respond:
            printf("{邀请合并回复}");
            break;
        case eCTS_Group_Merge_Invite_Ask:
            printf("{请求邀请合并}");
            break;
        case eCTS_Group_Merge_Apply_Ask:
            printf("{请求申请合并}");
            break;
        case eCTS_Group_Invite:
            printf("{团队邀请}");
            break;
        case eCTS_Group_Invite_Respond:
            printf("{团队邀请应答}");
            break;
        case eCTS_Group_Leave:
            printf("{团队离开}");
            break;
        case eCTS_Group_Apply_Agree:
            printf("{同意某人的团队申请}");
            break;
        case eCTS_Group_Kick:
            printf("{团队踢人}");
            break;
        case eCTS_Group_Move:
            printf("{移动}");
            break;
        case eCTS_Group_Replace:
            printf("{替换}");
            break;
        case eCTS_Group_Transfer:
            printf("{转让团长}");
            break;
        case eCTS_Group_Recruit:
            printf("{团队招募}");
            break;
        case eCTS_Group_Apply_Clear:
            printf("{清空申请列表}");
            break;
        case eCTS_Group_Report:
            printf("{上报错误}");
            break;
        case eCTS_Group_Refresh:
            printf("{刷新团队数据}");
            break;
        case eCTS_GetShaYunRankValue:
            printf("{获取杀运排行榜数量}");
            break;
        case eCTS_Team_Trusteeship:
            printf("{托管}");
            break;
        case eCTS_Team_BN:
            printf("{跨服队伍}");
            break;
        case eCTS_RelationAddFriend:
            printf("{添加好友，废弃}");
            break;
        case eCTS_RelationDelFriend:
            printf("{删除好友，废弃}");
            break;
        case eCTS_RelationAddBlack:
            printf("{添加黑名单，废弃}");
            break;
        case eCTS_RelationAgree:
            printf("{同意添加，废弃}");
            break;
        case eCTS_RelationFindFriend:
            printf("{查找好友}");
            break;
        case eCTS_RelationRequestFriend:
            printf("{请求好友，废弃}");
            break;
        case eCTS_RelationAddGroup:
            printf("{添加分组，废弃}");
            break;
        case eCTS_RelationChangeGroup:
            printf("{给好友换分组，废弃}");
            break;
        case eCTS_RelationSendFlower:
            printf("{给好友送花，废弃}");
            break;
        case eCTS_SendMessageToFriend:
            printf("{给好友发送消息}");
            break;
        case eCTS_TeamRide:
            printf("{eCTS_TeamRide}");
            break;
        case eCTS_RidePlayer:
            printf("{背人}");
            break;
        case eCTS_RelationForFriendLoginMessage:
            printf("{告诉好友上线信息}");
            break;
        case eCTS_RelationDeleteAllFriendRequests:
            printf("{删除所有好友请求消息}");
            break;
        case eCTS_RelationEditorGroup:
            printf("{编辑分组消息}");
            break;
        case eCTS_RelationDeleteGroup:
            printf("{删除分组消息}");
            break;
        case eCTS_RelationDeleteFriend:
            printf("{删除好友}");
            break;
        case eCTS_RelationRecentContact:
            printf("{最近联系人}");
            break;
        case eCTS_UI_Chat_GetInfoFromSever:
            printf("{通过名字获取当前人物player}");
            break;
        case eCTS_RelationCancelBlackList:
            printf("{取消黑名单设置}");
            break;
        case eCTS_GetYanli:
            printf("{领取愿力}");
            break;
        case eCTS_RelationUpdate:
            printf("{更新关系}");
            break;
        case eCTS_Revenge:
            printf("{仇人}");
            break;
        case eCTS_GetZytActData:
            printf("{获取玩转镇妖塔数据}");
            break;
        case eCTS_Achievement:
            printf("{成就上报}");
            break;
        case eCTS_RMB_Buy:
            printf("{直购}");
            break;
        case eCTS_Pet_ToTactic:
            printf("{宠物装备到阵法中}");
            break;
        case eCTS_Pet_UpdateTactic:
            printf("{阵眼升级}");
            break;
        case eCTS_Pet_SetTactic:
            printf("{装备阵法}");
            break;
        case eCTS_Pet_UnLockNewTactic:
            printf("{解锁新阵法}");
            break;
        case eCTS_Pet_UnLockIndex:
            printf("{解锁新的阵眼}");
            break;
        case eCTS_FishingBegin:
            printf("{开始钓鱼}");
            break;
        case eCTS_FishingRaise:
            printf("{起竿}");
            break;
        case eCTS_PartyOpen:
            printf("{家宴}");
            break;
        case eCTS_PartyPlay:
            printf("{eCTS_PartyPlay}");
            break;
        case eCTS_FishingOver:
            printf("{终止}");
            break;
        case eCTS_ChangESyncPos:
            printf("{开启嫦娥位置}");
            break;
        case eCTS_Compensate_Sync:
            printf("{同步补偿系统}");
            break;
        case eCTS_Compensate_Claim:
            printf("{领奖}");
            break;
        case eCTS_GetFirstLoginTime:
            printf("{补偿系统获取第一次登录时间}");
            break;
        case eCTS_levelUpBundle_Sync:
            printf("{同步}");
            break;
        case eCTS_levelUpBundle_Claim:
            printf("{领奖}");
            break;
        case eCTS_onlineBundle_Sync:
            printf("{同步}");
            break;
        case eCTS_onlineBundle_Claim:
            printf("{领奖}");
            break;
        case eCTS_exchange_exec:
            printf("{货币兑换}");
            break;
        case eCTS_HeadBorder:
            printf("{设置个性装扮}");
            break;
        case eCTS_UI_Wing:
            printf("{翅膀}");
            break;
        case eCTS_Achv:
            printf("{成就}");
            break;
        case eCTS_beginDancing:
            printf("{开始跳舞}");
            break;
        case eCTS_stopDancing:
            printf("{结束跳舞}");
            break;
        case eCTS_UI_Num_Click:
            printf("{数字点击界面}");
            break;
        case eCTS_Move:
            printf("{地面移动}");
            break;
        case eCTS_Fly:
            printf("{空中飞行}");
            break;
        case eCTS_Fly_Toggle:
            printf("{切换飞行}");
            break;
        case eCTS_Fly_Game:
            printf("{飞行玩法}");
            break;
        case eCTS_Level_Challenge:
            printf("{挑战关卡}");
            break;
        case eCTS_Qiecuo:
            printf("{切磋}");
            break;
        case eCTS_NormalLogic:
            printf("{非战斗逻辑}");
            break;
        case eCTS_FlyStatus:
            printf("{飞行}");
            break;
        case eCTS_Item_Slot_Rand:
            printf("{抽奖道具掉落相关}");
            break;
        case eCTS_UI_Demon:
            printf("{心魔}");
            break;
        case eCTS_Fight_AutoFight:
            printf("{开启或关闭自动战斗}");
            break;
        case eCTS_GroupRecharge:
            printf("{团购礼包}");
            break;
        case eCTS_Guild:
            printf("{门派}");
            break;
        case eCTS_GuildActivity_KillCrt:
            printf("{门派活动清缴精英战}");
            break;
        case eCTS_Guild_Training:
            printf("{门派试练}");
            break;
        case eCTS_HiddenLoveRel:
            printf("{婚缘暗恋关系}");
            break;
        case eCTS_Love:
            printf("{婚缘协议}");
            break;
        case eCTS_GuildChangeName:
            printf("{门派改名}");
            break;
        case eCTS_GuildProtectOrKill:
            printf("{门派护送或刺杀}");
            break;
        case eCTS_Guild_Union:
            printf("{门派敌对}");
            break;
        case eCTS_Guild_Revenge:
            printf("{门派复仇}");
            break;
        case eCTS_Guild_Activity:
            printf("{门派活动}");
            break;
        case eCTS_Guild_Real_Union:
            printf("{门派联盟}");
            break;
        case eCTS_GuildAddNumber:
            printf("{门派额外增加人数}");
            break;
        case eCTS_GuildWarehouse:
            printf("{门派仓库}");
            break;
        case eCTS_Scn_Guild_Real_Union:
            printf("{门派联盟}");
            break;
        case eCTS_TrialLevel:
            printf("{高难度属性副本试练}");
            break;
        case eCTS_GuildSkill:
            printf("{门派技能}");
            break;
        case eCTS_Twin_Tower:
            printf("{双塔奇兵}");
            break;
        case eCTS_Avatar_Enchant:
            printf("{时装附魔}");
            break;
        case eCTS_TeamRacing_Watch:
            printf("{观战}");
            break;
        case eCTS_PartnerTrialLevel:
            printf("{伙伴幻境试炼}");
            break;
        case eCTS_Bowl:
            printf("{聚宝盆}");
            break;
        case eCTS_Liveness:
            printf("{活跃度相关}");
            break;
        case eCTS_Online_Act:
            printf("{显示活动相关}");
            break;
        case eCTS_WorldBoss:
            printf("{世界boss}");
            break;
        case eCTS_DataRank:
            printf("{数据排行榜}");
            break;
        case eCTS_RPTask:
            printf("{系统红包任务}");
            break;
        case eCTS_Disaster:
            printf("{仙阶}");
            break;
        case eCTS_RelationRank:
            printf("{向关系服请求数据}");
            break;
        case eCTS_Guild_family:
            printf("{门派家族}");
            break;
        case eCTS_Guild_BnWar:
            printf("{上古战场消息}");
            break;
        case eCTS_Puzzles:
            printf("{拼图豪礼}");
            break;
        case eCTS_CloneBattle_ToRelation:
            printf("{形神竞技torelation}");
            break;
        case eCTS_CloneBattle_ToScn:
            printf("{形神竞技toscn}");
            break;
        case eCTS_Accompany_ToRelation:
            printf("{陪伴帮助torelation}");
            break;
        case eCTS_Accompany_ToScn:
            printf("{陪伴帮助toscn}");
            break;
        case eCTS_PVPGod:
            printf("{斗神}");
            break;
        case eCTS_Match_ToRelation:
            printf("{玩家匹配torelation}");
            break;
        case eCTS_Match_ToScn:
            printf("{玩家匹配toscn}");
            break;
        case eCTS_TeamVote_ToRelation:
            printf("{队伍内投票}");
            break;
        case eCTS_ActivityCopy:
            printf("{活动副本相关}");
            break;
        case eCTS_ActivityPvp:
            printf("{活动pvp相关}");
            break;
        case eCTS_PvpFight:
            printf("{pvp战斗相关}");
            break;
        case eCTS_NoviceCopy:
            printf("{新手本}");
            break;
        case eCTS_SignIn:
            printf("{签到}");
            break;
        case eCTS_TimeSync:
            printf("{时间同步}");
            break;
        case eCTS_Master:
            printf("{师徒}");
            break;
        case eCTS_GetRelationInfo:
            printf("{获取关系数据}");
            break;
        case eCTS_GuildGodLight:
            printf("{公会神光}");
            break;
        case eCTS_AllXX:
            printf("{全民寻仙}");
            break;
        case eCTS_Monopoly:
            printf("{大富翁}");
            break;
        case eCTS_ActivityStaging:
            printf("{活动集结}");
            break;
        case eCTS_PvNpc:
            printf("{仙友教学本}");
            break;
        case eCTS_LicaiCard:
            printf("{理财卡}");
            break;
        case eCTS_ClientTime:
            printf("{向服务器发送客户端时间}");
            break;
        case eCTS_MasterMate:
            printf("{师徒师门活动}");
            break;
        case eCTS_New_LicaiCard:
            printf("{新月卡}");
            break;
        case eCTS_SetPause:
            printf("{设置暂停}");
            break;
        case eCTS_CheckTaskFinished:
            printf("{检查任务是否完成}");
            break;
        case eCTS_RewardTask:
            printf("{完成任务领奖}");
            break;
        case eCTS_LevelLock:
            printf("{请求等级锁信息}");
            break;
        case eCTS_Levelfly:
            printf("{等级直升活动}");
            break;
        case eCTS_PVPWarTeam:
            printf("{eCTS_PVPWarTeam}");
            break;
        case eCTS_PVPWT_ToRelation:
            printf("{eCTS_PVPWT_ToRelation}");
            break;
        case eCTS_GoToBN:
            printf("{请求跨服}");
            break;
        case eCTS_LeaveBN:
            printf("{请求返回}");
            break;
        case eCTS_ACCT_GET_OPENID:
            printf("{根据openid获取玩家数据}");
            break;
        case eCTS_TX_Friend_Gift:
            printf("{给好友送心}");
            break;
        case eCTS_TX_Friend_GetList:
            printf("{请求好友openid列表}");
            break;
        case eCTS_TX_Friend_Award:
            printf("{自己的好友数量达到多少个领取奖励}");
            break;
        case eCTS_TX_Daily_Share:
            printf("{每日大图分享}");
            break;
        case eCTS_Tdbk:
            printf("{天帝宝库}");
            break;
        case eCTS_PAY_GET:
            printf("{接入支付，查询}");
            break;
        case eCTS_PAY_SET:
            printf("{接入支付，购买}");
            break;
        case eCTS_PAY_CANCEL:
            printf("{接入支付取消}");
            break;
        case eCTS_PAY_PRESENT:
            printf("{接入支付，赠送}");
            break;
        case eCTS_Misc_ToRelation:
            printf("{eCTS_Misc_ToRelation}");
            break;
        case eCTS_Grow_Fund:
            printf("{成长基金}");
            break;
        case eCTS_Misc_ToScn:
            printf("{eCTS_Misc_ToScn}");
            break;
        case eCTS_Total_RMB_Buy:
            printf("{累计充值}");
            break;
        case eCTS_GetQQVip_RedDot:
            printf("{获取QQ会员是否点击}");
            break;
        case eCTS_MsdkBtn_Control:
            printf("{eCTS_MsdkBtn_Control}");
            break;
        case eCTS_SetQQVip_RedDot:
            printf("{设置QQ会员}");
            break;
        case eCTS_Change_Name:
            printf("{改名请求}");
            break;
        case eCTS_KF_SignIn:
            printf("{开服30天签到}");
            break;
        case eCTS_Report_Channel:
            printf("{上报注册渠道下载渠道}");
            break;
        case eCTS_ExpToInnate:
            printf("{角色经验转天赋经验}");
            break;
        case eCTS_AvatarDye:
            printf("{时装解锁染色}");
            break;
        case eCTS_Wedding:
            printf("{婚礼}");
            break;
        case eCTS_VipClub:
            printf("{上仙俱乐部}");
            break;
        case eCTS_Voip:
            printf("{实时语音}");
            break;
        case eCTS_GetKillingActInfo:
            printf("{获取杀劫界面信息}");
            break;
        case eCTS_GetKillingActOpenInfo:
            printf("{个人获取杀劫界面开启信息}");
            break;
        case eCTS_BuyKillingCount:
            printf("{购买杀劫次数}");
            break;
        case eCTS_BeginKilling:
            printf("{开启杀劫}");
            break;
        case eCTS_SendLuckyBag:
            printf("{发放福袋}");
            break;
        case eCTS_TX_Get_Friend_List:
            printf("{密友获取未注册好友}");
            break;
        case eCTS_TX_Invite_Friend:
            printf("{密友邀请好友}");
            break;
        case eCTS_TX_Friend_GetAward:
            printf("{密友发放奖励}");
            break;
        case eCTS_SingleFriend_SendAward:
            printf("{密友单个发奖}");
            break;
        case eCTS_TitleAward:
            printf("{称号积分达标发奖}");
            break;
        case eCTS_UI_SkillJinJie:
            printf("{技能进阶}");
            break;
        case eCTS_qiangdanSkill:
            printf("{背蛋无敌技能}");
            break;
        case eCTS_QiangDanExit:
            printf("{背蛋结算退出}");
            break;
        case eCTS_Lottery:
            printf("{海外十连抽}");
            break;
        case eCTS_LotteryStore:
            printf("{海外积分商城}");
            break;
        case eCTS_UI_addDaoheng:
            printf("{炼心系统添加道行值}");
            break;
        case eCTS_gotoTrial:
            printf("{炼心系统进入心魔试炼}");
            break;
        case eCTS_Patface:
            printf("{海外拍脸}");
            break;
        case eCTS_answer_playerChgScn:
            printf("{玩家切换场景}");
            break;
        case eCTS_Season_Box:
            printf("{四时仙盒}");
            break;
        case eCTS_PlayerReturn_award:
            printf("{回流活动发奖励}");
            break;
        case eCTS_LoveEvent:
            printf("{520情缘活动}");
            break;
        case eCTS_LoveBoatEvent:
            printf("{520情缘小船}");
            break;
        case eCTS_LoveBoatEvent_Island:
            printf("{情缘岛小船}");
            break;
        case eCTS_MergeSvr_GetAward:
            printf("{和服活动}");
            break;
        case eCTS_mopupOneClick:
            printf("{使用道具一键扫荡}");
            break;
        case eCTS_useItemOneClick:
            printf("{使用道具一键扫荡2}");
            break;
        case eCTS_Scn_Corps:
            printf("{战队赛创建战队}");
            break;
        case eCTS_Corps:
            printf("{战队赛创建战队}");
            break;
        case eCTS_WorldBoss24h:
            printf("{全天世界boss}");
            break;
        case eCTS_HeroStatue:
            printf("{宁海县雕像}");
            break;
        case eCTS_Activity_Misc:
            printf("{一些杂乱的活动或者需求很简单的协议}");
            break;
        case eCTS_NewAnswer:
            printf("{新答题活动}");
            break;
        case eCTS_Joingame_sendinfo:
            printf("{请求加入骰子游戏}");
            break;
        case eCTS_playerClick_sendinfo:
            printf("{点击进行掷骰子}");
            break;
        case eCTS_racingGuess:
            printf("{战队赛竞猜界面}");
            break;
        case eCTS_ArenaContest:
            printf("{擂台赛}");
            break;
        case eCTS_Arena_Battle:
            printf("{eCTS_Arena_Battle}");
            break;
        case eCTS_AutoSelectTarget:
            printf("{快捷选目标}");
            break;
        case eCTS_HeroRankToRelation:
            printf("{英雄榜}");
            break;
        case eCTS_RushXianjie:
            printf("{冲仙阶活动}");
            break;
        case eCTS_SuitCollect:
            printf("{套装}");
            break;
        case eCTS_UpdatePetPos:
            printf("{更新宠物位置}");
            break;
        case eCTS_RedPacket_Statue:
            printf("{宁海县雕像红包}");
            break;
        case eCTS_Ancient_BattleField:
            printf("{上古战场}");
            break;
        case eCTS_pet_car_equip:
            printf("{骑宠装备}");
            break;
        case eCTS_ancientBattleField:
            printf("{上古战场竞技服消息}");
            break;
        case eCTS_UI_AutoMelt:
            printf("{自动熔炼}");
            break;
        case eCTS_Copy_Wasteland:
            printf("{开荒模式}");
            break;
        case eCTS_MiniGame:
            printf("{迷你游戏}");
            break;
        case eCTS_RidePet_Collect:
            printf("{骑宠收集}");
            break;
        case eCTS_UI_Aerocraft:
            printf("{飞行器}");
            break;
        case eCTS_ZhaoCaiMao:
            printf("{eCTS_ZhaoCaiMao}");
            break;
        case eCTS_GlobalLimitBuying:
            printf("{全服抢购}");
            break;
        case eCTS_OYToBuy:
            printf("{eCTS_OYToBuy}");
            break;
        case eCTS_UI_OrnamentAction:
            printf("{配饰动作按钮}");
            break;
        case eCTS_RidePet_Soul:
            printf("{骑宠御灵}");
            break;
        case eCTS_MultiBattle:
            printf("{无战力多人活动}");
            break;
        case eCTS_RMB_Bowl:
            printf("{rmb聚宝盆}");
            break;
        case eCTS_Contest_PVP:
            printf("{竞赛pvp}");
            break;
        case eCTS_Fly_Chg:
            printf("{飞行器切换}");
            break;
        case eCTS_NewZone_BackFlow:
            printf("{新区绑定老角色福利活动}");
            break;
        case eCTS_UI_Chat_FaceOp:
            printf("{表情包}");
            break;
        case eCTS_Friend_Remarks:
            printf("{好友修改备注}");
            break;
        case eCTS_Scry:
            printf("{卦象}");
            break;
        case eCTS_XianJie_Battle:
            printf("{天宫仙位积分赛}");
            break;
        case eCTS_xianban:
            printf("{eCTS_xianban}");
            break;
        case eCTS_LotteryPendant:
            printf("{娃娃挂件}");
            break;
        case eCTS_personalGuessMsg:
            printf("{巅峰赛竞猜相关消息}");
            break;
        case eCTS_GetSuperRInfo:
            printf("{获取超R玩家会员等级信息}");
            break;
        case eCTS_GameConfig:
            printf("{玩家游戏设置}");
            break;
        case eCTS_Complaint:
            printf("{举报投诉}");
            break;
        case eCTS_Lottery_new:
            printf("{新须弥纳宝盒}");
            break;
        case eCTS_Screen_Shot:
            printf("{拍照道具激活}");
            break;
        case eCTS_TempleMatch:
            printf("{天宫赛相关信息}");
            break;
        case eCTS_Love_Match:
            printf("{情缘匹配}");
            break;
        case eCTS_New_TotalCharge:
            printf("{新累计充值活动}");
            break;
        case eCTS_Flea_Market:
            printf("{跳蚤市场}");
            break;
        case eCTS_New_Bid:
            printf("{绑定仙玉拍卖行}");
            break;
        case eCTS_partner_equip:
            printf("{伙伴装备}");
            break;
        case eCTS_Partner:
            printf("{伙伴}");
            break;
        case eCTS_Tdbk_New:
            printf("{天帝宝库}");
            break;
        case eCTS_FireworksParty:
            printf("{烟花大会}");
            break;
        case eCTS_Birthday:
            printf("{生辰返利}");
            break;
        case eCTS_Flop:
            printf("{翻牌子}");
            break;
        case eCTS_AnswerMatch:
            printf("{竞技答题}");
            break;
        case eCTS_Ornament:
            printf("{配饰}");
            break;
        case eCTS_Alchemy:
            printf("{炼丹}");
            break;
        case eCTS_Online_Quest:
            printf("{在线活动}");
            break;
        case eCTS_Family_Chess:
            printf("{对弈}");
            break;
        case eCTS_New_Share:
            printf("{激活码拉新活动}");
            break;
        case eCTS_Other_Book:
            printf("{异闻录}");
            break;
        case eCTS_Bounty:
            printf("{悬赏}");
            break;
        case eCTS_UI_Debts:
            printf("{欠账}");
            break;
        case eCTS_NewServer:
            printf("{新服活动}");
            break;
        case eCTS_Player_Cancellation:
            printf("{注销}");
            break;
        case eCTS_UI_Ghost:
            printf("{残影}");
            break;
        case eCTS_GetPlayer_Identity:
            printf("{获取玩家身份}");
            break;
        case eCTS_Span_KillMonster:
            printf("{跨服杀怪}");
            break;
        case eCTS_imprint:
            printf("{装备雕刻系统}");
            break;
        case eCTS_Dream_Activity:
            printf("{追梦活动}");
            break;
        case eCTS_Spring_Activity:
            printf("{春游活动}");
            break;
        case eCTS_Practice:
            printf("{穴位修炼}");
            break;
        case eCTS_XianQi_Awaken:
            printf("{仙器觉醒}");
            break;
        case eCTS_BountyOrder_Activity:
            printf("{犒赏令}");
            break;
        case eCTS_Weekend_Race_Speed:
            printf("{周末竞速}");
            break;
        case eCTS_UI_QuickBuy:
            printf("{道聚城}");
            break;
        case eCTS_Five_Elements:
            printf("{五行}");
            break;
        case eCTS_CharmAward:
            printf("{eCTS_CharmAward}");
            break;
        case eCTS_Copy_GreatSecret:
            printf("{eCTS_Copy_GreatSecret}");
            break;
        case eCTS_respectGod:
            printf("{敬天宝囊}");
            break;
        case eCTS_UI_Xmhj:
            printf("{须弥幻境}");
            break;
        case eCTS_PVPGod_Robot:
            printf("{斗神坛root}");
            break;
        case eCTS_Universe:
            printf("{乾坤袋}");
            break;
        case eCTS_SuperPowers:
            printf("{神通}");
            break;
        case eCTS_TcgCard:
            printf("{集换卡牌}");
            break;
        case eCTS_Devildom:
            printf("{魔界裂缝}");
            break;
        case eCTS_OptionalGift:
            printf("{自选礼包}");
            break;
        case eCTS_TreasureHunt:
            printf("{跨服寻宝}");
            break;
        case eCTS_FestivalSignIn:
            printf("{节日签到}");
            break;
        case eCTS_Love_Chess:
            printf("{eCTS_Love_Chess}");
            break;
        case eCTS_NewLoop_Quest:
            printf("{eCTS_NewLoop_Quest}");
            break;
        case eCTS_Holy_Spirit:
            printf("{圣灵}");
            break;
        case eCTS_VipRechargeAward:
            printf("{vip充值兑换活动}");
            break;
        case eCTS_Seal_Monster:
            printf("{封妖玩法}");
            break;
        case eCTS_DivineWeapon:
            printf("{神兵系统}");
            break;
        case eCTS_WestWalk:
            printf("{西行玩法}");
            break;
        case eCTS_ReturnShop:
            printf("{返厂商店}");
            break;
        case eCTS_RantPet:
            printf("{宠物室}");
            break;
        case eCTS_Copy_Growth:
            printf("{副本成长}");
            break;
        case eCTS_Gather_Demon_Array:
            printf("{聚魔阵}");
            break;
        case eCTS_CDShop_Sticky:
            printf("{置顶}");
            break;
        case eCTS_Secret_SetUp:
            printf("{eCTS_Secret_SetUp}");
            break;
        case eCTS_OldPlayerReturn:
            printf("{老玩家回归}");
            break;
        case eCTS_Ribbon:
            printf("{飘带}");
            break;
        case eCTS_Trigger_Activity:
            printf("{触发道具活动}");
            break;
        case eCTS_Xianyue_Chess:
            printf("{仙乐台对弈}");
            break;
        case eCTS_Guild_Chess:
            printf("{门派对弈}");
            break;
        case eCTS_PVP_30v30:
            printf("{快富战场30v30}");
            break;
        case eCTS_New_Server_Item:
            printf("{获取新服活动礼包道具}");
            break;
        case eCTS_New_Server_Buy:
            printf("{新服活动购买}");
            break;
        case eCTS_New_Server_Time:
            printf("{新服活动时间}");
            break;
        case eCTS_New_Server_Receive:
            printf("{新服嘉年华领取}");
            break;
        case eCTS_Carnival_Liveness_Receive:
            printf("{新服嘉年华活跃度领取}");
            break;
        case eCTS_Map_Set_Define_scn:
            printf("{新地图定义场景}");
            break;
        case eCTS_Mark_Max:
            printf("{最大协议号，未使用}");
            break;
        default:
            printf("{unknown cmd code}");
            break;
    }
}

void display_server_to_client(const u2_int cmd) {
    switch ((eSTC)cmd) {
        case eSTC_Fake_Connected:
            printf("{连接反馈}");
            break;
        case eSTC_Mark_Min:
            printf("{最小值，未使用}");
            break;
        case eSTC_CAAFS_LOGIN:
            printf("{eSTC_CAAFS_LOGIN}");
            break;
        case eSTC_CAAFS_QUERY_HOME_LIST:
            printf("{eSTC_CAAFS_QUERY_HOME_LIST}");
            break;
        case eSTC_CAAFS_QUERY_CLICFG:
            printf("{eSTC_CAAFS_QUERY_CLICFG}");
            break;
        case eSTC_CLS_LOGIN:
            printf("{eSTC_CLS_LOGIN}");
            break;
        case eSTC_ACCT_GET_INIT:
            printf("{eSTC_ACCT_GET_INIT}");
            break;
        case eSTC_ACCT_INIT_TEAM:
            printf("{eSTC_ACCT_INIT_TEAM}");
            break;
        case eSTC_ACCT_NICK:
            printf("{eSTC_ACCT_NICK}");
            break;
        case eSTC_Respond:
            printf("{eSTC_Respond}");
            break;
        case eSTC_START_GAME:
            printf("{eSTC_START_GAME}");
            break;
        case eSTC_GET_PING:
            printf("{eSTC_GET_PING}");
            break;
        case eSTC_GET_LOGIC_PING:
            printf("{eSTC_GET_LOGIC_PING}");
            break;
        case eSTC_CHOOSE_HOME:
            printf("{eSTC_CHOOSE_HOME}");
            break;
        case eSTC_GET_SCN_SVR_LIST:
            printf("{eSTC_GET_SCN_SVR_LIST}");
            break;
        case eSTC_CAAFS_QUEUEINFO:
            printf("{eSTC_CAAFS_QUEUEINFO}");
            break;
        case eSTC_CAAFS_INFO:
            printf("{eSTC_CAAFS_INFO}");
            break;
        case eSTC_CAAFS_WAITTOCONNECT:
            printf("{eSTC_CAAFS_WAITTOCONNECT}");
            break;
        case eSTC_GMS_FILE:
            printf("{eSTC_GMS_FILE}");
            break;
        case eSTC_APOLLO_VOICE:
            printf("{eSTC_APOLLO_VOICE}");
            break;
        case eSTC_CHAR_SELECT:
            printf("{eSTC_CHAR_SELECT}");
            break;
        case eSTC_DELETE_CHAR:
            printf("{角色删除}");
            break;
        case eSTC_TSS_ANTI:
            printf("{腾讯的数据}");
            break;
        case eSTC_CLS_LOGINSESSION:
            printf("{eSTC_CLS_LOGINSESSION}");
            break;
        case eSTC_CLS_GZSSVROUTAGE:
            printf("{eSTC_CLS_GZSSVROUTAGE}");
            break;
        case eSTC_Stop_Server:
            printf("{eSTC_Stop_Server}");
            break;
        case eSTC_FCM_Nodify:
            printf("{eSTC_FCM_Nodify}");
            break;
        case eSTC_FCM2_Nodify:
            printf("{eSTC_FCM2_Nodify}");
            break;
        case eSTC_ScnObj_Mark_Min:
            printf("{场景相关分界线，未使用}");
            break;
        case eSTC_ScnObj_Flag:
            printf("{设置标志位}");
            break;
        case eSTC_ScnObj_InitStart:
            printf("{eSTC_ScnObj_InitStart}");
            break;
        case eSTC_ScnObj_InitEnd:
            printf("{eSTC_ScnObj_InitEnd}");
            break;
        case eSTC_Game_LoadScn:
            printf("{加载场景}");
            break;
        case eSTC_ScnObj_Create:
            printf("{创建scnobj}");
            break;
        case eSTC_ScnObj_Destroy:
            printf("{销毁scnobj}");
            break;
        case eSTC_ScnObj_Skill:
            printf("{eSTC_ScnObj_Skill}");
            break;
        case eSTC_ScnObj_AddState:
            printf("{eSTC_ScnObj_AddState}");
            break;
        case eSTC_ScnObj_JoinBus:
            printf("{加入坐骑}");
            break;
        case eSTC_ScnObj_LeaveBus:
            printf("{离开坐骑}");
            break;
        case eSTC_ScnObj_CreateBus:
            printf("{创建坐骑}");
            break;
        case eSTC_ScnObj_SetBusDriver:
            printf("{设置坐骑驾驶者}");
            break;
        case eSTC_ScnObj_SelfData:
            printf("{角色发送存档数据给客户端}");
            break;
        case eSTC_ScnObj_EquipModel:
            printf("{设置装备串}");
            break;
        case eSTC_ScnObj_Dead:
            printf("{死亡消息}");
            break;
        case eSTC_ScnObj_Forcedly:
            printf("{eSTC_ScnObj_Forcedly}");
            break;
        case eSTC_ScnObj_Move:
            printf("{eSTC_ScnObj_Move}");
            break;
        case eSTC_ScnObj_SetTarget:
            printf("{eSTC_ScnObj_SetTarget}");
            break;
        case eSTC_ScnObj_Kinematic:
            printf("{eSTC_ScnObj_Kinematic}");
            break;
        case eSTC_ScnObj_RideLink:
            printf("{eSTC_ScnObj_RideLink}");
            break;
        case eSTC_ScnObj_LookTargetEvet:
            printf("{eSTC_ScnObj_LookTargetEvet}");
            break;
        case eSTC_ScnObj_DelState:
            printf("{eSTC_ScnObj_DelState}");
            break;
        case eSTC_ScnObj_Summon:
            printf("{eSTC_ScnObj_Summon}");
            break;
        case eSTC_ScnObj_Fly:
            printf("{飞行同步}");
            break;
        case eSTC_ScnObj_StopSkill:
            printf("{eSTC_ScnObj_StopSkill}");
            break;
        case eSTC_ScnObj_HpChg:
            printf("{eSTC_ScnObj_HpChg}");
            break;
        case eSTC_ScnObj_FlyStatus:
            printf("{飞行状态}");
            break;
        case eSTC_ScnObj_SyncChildObject:
            printf("{eSTC_ScnObj_SyncChildObject}");
            break;
        case eSTC_ScnObj_SetTargetPos:
            printf("{eSTC_ScnObj_SetTargetPos}");
            break;
        case eSTC_ScnObj_Float:
            printf("{单纯的浮空改变位置，去掉飞行的各种限制}");
            break;
        case eSTC_ScnObj_StopFlag:
            printf("{eSTC_ScnObj_StopFlag}");
            break;
        case eSTC_ScnObj_FlagFast:
            printf("{eSTC_ScnObj_FlagFast}");
            break;
        case eSTC_ScnObj_Hp:
            printf("{血量变化}");
            break;
        case eSTC_ScnObj_Fly_Test:
            printf("{压测回包}");
            break;
        case eSTC_ScnObj_Skill_Failed:
            printf("{压测回包技能失败}");
            break;
        case eSTC_ScnObj_PlaySound:
            printf("{播放音乐}");
            break;
        case eSTC_ScnObj_BringDownChain:
            printf("{坠仙索}");
            break;
        case eSTC_ScnObj_SyncAngle:
            printf("{技能同步角度}");
            break;
        case eSTC_ScnObj_AddEffect:
            printf("{添加特效}");
            break;
        case eSTC_ScnObj_SkillTrigger:
            printf("{技能触发}");
            break;
        case eSTC_ScnObj_Mark_Max:
            printf("{场景相关分界线，未使用}");
            break;
        case eSTC_GMTool:
            printf("{GM命令相关}");
            break;
        case eSTC_Special_Fb:
            printf("{特殊副本大世界的消息}");
            break;
        case eSTC_TRAVEL_SCN:
            printf("{挂机场景的消息}");
            break;
        case eSTC_PLAYER:
            printf("{eSTC_PLAYER}");
            break;
        case eSTC_Mail_NewMsg:
            printf("{接收新邮件}");
            break;
        case eSTC_SHENXIAN:
            printf("{eSTC_SHENXIAN}");
            break;
        case eSTC_PET:
            printf("{eSTC_PET}");
            break;
        case eSTC_GM:
            printf("{GM相关}");
            break;
        case eSTC_Mail_AllMsg:
            printf("{接收所有邮件}");
            break;
        case eSTC_EternalAtb:
            printf("{永恒四属性}");
            break;
        case eSTC_Mail_MultiMsg:
            printf("{接收全服或多人邮件}");
            break;
        case eSTC_TravelOffline:
            printf("{离线挂机}");
            break;
        case eSTC_Copy:
            printf("{副本相关}");
            break;
        case eSTC_Disaster:
            printf("{仙阶}");
            break;
        case eSTC_ChangESyncPos:
            printf("{返回嫦娥位置}");
            break;
        case eSTC_Fabao_StepUp:
            printf("{eSTC_Fabao_StepUp}");
            break;
        case eSTC_Fabao_LevelUp:
            printf("{eSTC_Fabao_LevelUp}");
            break;
        case eSTC_Fabao_RankUp:
            printf("{eSTC_Fabao_RankUp}");
            break;
        case eSTC_GMTool_Log:
            printf("{GM log}");
            break;
        case eSTC_SkillLevel:
            printf("{eSTC_SkillLevel}");
            break;
        case eSTC_UI_Chat:
            printf("{eSTC_UI_Chat}");
            break;
        case eSTC_UI_ChatVoice:
            printf("{eSTC_UI_ChatVoice}");
            break;
        case eSTC_UI_InnateUpdate:
            printf("{天赋升级}");
            break;
        case eSTC_UI_Auction:
            printf("{寄售行}");
            break;
        case eSTC_UI_PetStudy:
            printf("{宠物修行}");
            break;
        case eSTC_UI_PetBid:
            printf("{宠物拍卖}");
            break;
        case eSTC_UI_ItemBid:
            printf("{道具拍卖}");
            break;
        case eSTC_UI_RedPacket:
            printf("{红包}");
            break;
        case eSTC_UI_OpenOrder:
            printf("{未完订单}");
            break;
        case eSTC_GMTool_Bridge_Info:
            printf("{桥接的GM信息}");
            break;
        case eSTC_GMTool_Bridge_VarInfo:
            printf("{桥接的varinfo信息}");
            break;
        case eSTC_GMTool_Bridge_Command:
            printf("{桥接的command信息}");
            break;
        case eSTC_UI_PetCol:
            printf("{宠物图鉴}");
            break;
        case eSTC_VerAsset:
            printf("{自动下载的资源，用于MB动态下载}");
            break;
        case eSTC_UI_GuildBid:
            printf("{门派拍卖}");
            break;
        case eSTC_UI_PetFetters:
            printf("{宠物羁绊}");
            break;
        case eSTC_UI_Pet_Pray:
            printf("{宠物祈福}");
            break;
        case eSTC_UI_Daily_Gift_Charge:
            printf("{请求最新的每日礼包信息}");
            break;
        case eSTC_Flower_Lamp:
            printf("{花灯许愿}");
            break;
        case eSTC_UI_TacticEnforce:
            printf("{宠物阵法强化}");
            break;
        case eSTC_Cache_Data:
            printf("{eSTC_Cache_Data}");
            break;
        case eSTC_GroupRecharge:
            printf("{团购礼包}");
            break;
        case eSTC_FishingUIOpen:
            printf("{打开钓鱼界面}");
            break;
        case eSTC_FishingOver:
            printf("{服务器返回钓鱼结果}");
            break;
        case eSTC_FishingTimeOut:
            printf("{钓鱼超时}");
            break;
        case eSTC_FishingBegin:
            printf("{钓鱼开始}");
            break;
        case eSTC_PartyOpen:
            printf("{家宴}");
            break;
        case eSTC_PartyPlay:
            printf("{eSTC_PartyPlay}");
            break;
        case eSTC_UI_ITEM_START:
            printf("{道具数量改变}(2 same)");
            break;
            //case eSTC_UI_ItemCount:
        case eSTC_UI_AddItem:
            printf("{增加道具}");
            break;
        case eSTC_UI_DelItem:
            printf("{删除道具}");
            break;
        case eSTC_UI_ItemData:
            printf("{修改道具标记位}");
            break;
        case eSTC_UI_UseItem:
            printf("{道具使用}");
            break;
        case eSTC_UI_Progress:
            printf("{进度条}");
            break;
        case eSTC_UI_Trade:
            printf("{新寄售交易}");
            break;
        case eSTC_UI_ITEM_END:
            printf("{eSTC_UI_ITEM_END}");
            break;
        case eSTC_UI_TalkOpen:
            printf("{对话打开}");
            break;
        case eSTC_UI_TalkClose:
            printf("{对话关闭}");
            break;
        case eSTC_UI_TalkChgSel:
            printf("{对话}");
            break;
        case eSTC_UI_OnQiangdanEnd:
            printf("{抢蛋活动结束}");
            break;
        case eSTC_UI_OnRideDownDan:
            printf("{抢蛋活动放下蛋}");
            break;
        case eSTC_UI_TalkEnd:
            printf("{对话结束}");
            break;
        case eSTC_UI_DeathUIOpen:
            printf("{死亡复活界面打开}");
            break;
        case eSTC_UI_DeathUIClose:
            printf("{死亡复活界面关闭}");
            break;
        case eSTC_UI_Quest:
            printf("{任务}");
            break;
        case eSTC_UI_Recipe:
            printf("{配方}");
            break;
        case eSTC_UI_Pet:
            printf("{宠物}");
            break;
        case eSTC_UI_OpenCDShop:
            printf("{打开CD商店}");
            break;
        case eSTC_UI_CloseCDShop:
            printf("{关闭并清理CD商店}");
            break;
        case eSTC_UI_CDGoods:
            printf("{CD商店货物}");
            break;
        case eSTC_UI_CDShopTime:
            printf("{刷新时间}");
            break;
        case eSTC_UI_Survey:
            printf("{问卷}");
            break;
        case eSTC_UI_AutoFight:
            printf("{eSTC_UI_AutoFight}");
            break;
        case eSTC_TransCmn:
            printf("{传送}");
            break;
        case eSTC_ZhenYan_Hurts:
            printf("{世界boss阵眼伤害信息}");
            break;
        case eSTC_Warcraftinfos:
            printf("{向客户端发送战场信息}");
            break;
        case eSTC_Warcraft_situation:
            printf("{战况信息}");
            break;
        case eSTC_BattleField:
            printf("{仙府争霸消息}");
            break;
        case eSTC_UI_Gem:
            printf("{宝石}");
            break;
        case eSTC_UI_Flower:
            printf("{鲜花}");
            break;
        case eSTC_UI_TranserCareer:
            printf("{转职}");
            break;
        case eSTC_UI_HeadBorder:
            printf("{个性装扮}");
            break;
        case eSTC_UI_Wing:
            printf("{翅膀}");
            break;
        case eSTC_Wing:
            printf("{翅膀}");
            break;
        case eSTC_Team_Wing:
            printf("{翅膀}");
            break;
        case eSTC_UI_DyeGroup:
            printf("{宠物染色组}");
            break;
        case eSTC_Ylg_BattleField:
            printf("{隐龙谷阵营战}");
            break;
        case eSTC_TenYearFire:
            printf("{十周年烟火}");
            break;
        case eSTC_Xianqi:
            printf("{仙器}");
            break;
        case eSTC_Team_Xianqi:
            printf("{仙器}");
            break;
        case eSTC_Ornament:
            printf("{配饰}");
            break;
        case eSTC_Team_Ornament:
            printf("{配饰}");
            break;
        case eSTC_RMB_Buy:
            printf("{直购}");
            break;
        case eSTC_TeamInfo_Modify:
            printf("{队伍数据}");
            break;
        case eSTC_TeamInfo_Del:
            printf("{队伍数据删除}");
            break;
        case eSTC_TeamMember_Modify:
            printf("{队伍成员数据}");
            break;
        case eSTC_TeamMember_Del:
            printf("{队伍成员数据删除}");
            break;
        case eSTC_LevelFlag:
            printf("{同步客户端levelflag}");
            break;
        case eSTC_TeamMember_Invite:
            printf("{组队邀请}");
            break;
        case eSTC_TeamCreate:
            printf("{创建队伍}");
            break;
        case eSTC_TeamDismiss:
            printf("{解散队伍}");
            break;
        case eSTC_TeamFilter:
            printf("{eSTC_TeamFilter}");
            break;
        case eSTC_TeamMerge:
            printf("{队伍合并}");
            break;
        case eSTC_TeamRide:
            printf("{eSTC_TeamRide}");
            break;
        case eSTC_Team_Tips:
            printf("{eSTC_Team_Tips}");
            break;
        case eSTC_ZYT:
            printf("{镇妖塔}");
            break;
        case eSTC_Col:
            printf("{风物志}");
            break;
        case eSTC_Title:
            printf("{eSTC_Title}");
            break;
        case eSTC_TeamCall:
            printf("{eSTC_TeamCall}");
            break;
        case eSTC_TeamSyncPos:
            printf("{eSTC_TeamSyncPos}");
            break;
        case eSTC_Title_Loop:
            printf("{循环播放称号}");
            break;
        case eSTC_GetSimpleInfo:
            printf("{获取别人的信息}");
            break;
        case eSTC_Bestowal:
            printf("{传功}");
            break;
        case eSTC_UI_Notify:
            printf("{提示}");
            break;
        case eSTC_UI_HudText:
            printf("{eSTC_UI_HudText}");
            break;
        case eSTC_UI_AddCooldown:
            printf("{添加CD}");
            break;
        case eSTC_UI_DelCooldown:
            printf("{删除CD}");
            break;
        case eSTC_UI_PlayAnimation:
            printf("{播放动画}");
            break;
        case eSTC_UI_NpcTalkStory:
            printf("{npc讲故事}");
            break;
        case eSTC_UI_SetCameraTarget:
            printf("{eSTC_UI_SetCameraTarget}");
            break;
        case eSTC_UI_PlayCameraAnim:
            printf("{eSTC_UI_PlayCameraAnim}");
            break;
        case eSTC_UI_DataRank:
            printf("{eSTC_UI_DataRank}");
            break;
        case eSTC_UI_GatherAtbChg:
            printf("{收集atb变化}");
            break;
        case eSTC_UI_ShowAcquire:
            printf("{显示获得的道具}");
            break;
        case eSTC_UI_GetFightValue:
            printf("{eSTC_UI_GetFightValue}");
            break;
        case eSTC_SeeOther:
            printf("{查看别人的信息}");
            break;
        case eSTC_Invite:
            printf("{邀请别人}");
            break;
        case eSTC_Team:
            printf("{组队}");
            break;
        case eSTC_Time:
            printf("{时间}");
            break;
        case eSTC_Team_Follow:
            printf("{组队跟随}");
            break;
        case eSTC_Group:
            printf("{团队}");
            break;
        case eSTC_Group_Flag:
            printf("{团队flag}");
            break;
        case eSTC_Group_Insert:
            printf("{加入团队}");
            break;
        case eSTC_Group_Delete:
            printf("{离开团队}");
            break;
        case eSTC_Group_Update:
            printf("{修改团队}");
            break;
        case eSTC_Group_Select:
            printf("{查找团队}");
            break;
        case eSTC_Group_Hp:
            printf("{血量}");
            break;
        case eSTC_Group_Invite:
            printf("{团队邀请}");
            break;
        case eSTC_Group_Merge_Invite_Ask:
            printf("{请求邀请合并}");
            break;
        case eSTC_Group_Merge_Apply_Ask:
            printf("{请求申请合并}");
            break;
        case eSTC_Group_Apply:
            printf("{团队申请}");
            break;
        case eSTC_Group_Merge:
            printf("{团队合并}");
            break;
        case eSTC_Group_Leave:
            printf("{团队离开}");
            break;
        case eSTC_Recruit:
            printf("{招募}");
            break;
        case eSTC_Group_Invite_Collect:
            printf("{收集邀请数据}");
            break;
        case eSTC_Group_Apply_Collect:
            printf("{收集申请数据}");
            break;
        case eSTC_Group_Replace:
            printf("{替换}");
            break;
        case eSTC_Group_Move:
            printf("{移动}");
            break;
        case eSTC_Group_Merge_Invite:
            printf("{团队邀请合并}");
            break;
        case eSTC_Group_Merge_Apply:
            printf("{团队申请合并}");
            break;
        case eSTC_Disaster_Progress:
            printf("{渡劫进度条}");
            break;
        case eSTC_Title_Delete:
            printf("{删除称号}");
            break;
        case eSTC_Group_Apply_Clear:
            printf("{清空团队申请列表}");
            break;
        case eSTC_ZYT_Notify:
            printf("{镇妖塔通知}");
            break;
        case eSTC_Group_TeamDismiss:
            printf("{团队中某一队伍解散}");
            break;
        case eSTC_Group_Invite_Request:
            printf("{团员请求团长邀请别人入团}");
            break;
        case eSTC_Achv:
            printf("{成就}");
            break;
        case eSTC_LianXinCopy:
            printf("{仙阶炼心副本}");
            break;
        case eSTC_BeidanScore:
            printf("{背蛋积分}");
            break;
        case eSTC_ui_minimap:
            printf("{背蛋小地图}");
            break;
        case eSTC_BeidanResult:
            printf("{背蛋结果显示}");
            break;
        case eSTC_TimeQueue:
            printf("{时间队列消息}");
            break;
        case eSTC_Level_Challenge:
            printf("{挑战关卡}");
            break;
        case eSTC_Qiecuo:
            printf("{切磋}");
            break;
        case eSTC_Fly_Game:
            printf("{飞行玩法}");
            break;
        case eSTC_CommonInvite:
            printf("{eSTC_CommonInvite}");
            break;
        case eSTC_Qiecuo_1v1:
            printf("{大世界单人切磋}");
            break;
        case eSTC_SendTeamInfo:
            printf("{下发队伍数据到客户端}");
            break;
        case eSTC_Item_Slot_Rand:
            printf("{抽奖随机道具想相关}");
            break;
        case eSTC_UI_Num_Click:
            printf("{数字点击界面}");
            break;
        case eSTC_RelationFindFriend:
            printf("{eSTC_RelationFindFriend}");
            break;
        case eSTC_RelationUpdate:
            printf("{eSTC_RelationUpdate}");
            break;
        case eSTC_RelationUpdateData:
            printf("{eSTC_RelationUpdateData}");
            break;
        case eSTC_RelationAddGroup:
            printf("{eSTC_RelationAddGroup}");
            break;
        case eSTC_RelationFriendOnline:
            printf("{eSTC_RelationFriendOnline}");
            break;
        case eSTC_Relation_Flag:
            printf("{关系服同步flag}");
            break;
        case eSTC_RelationCallBackMessage:
            printf("{好友信息服务器返回}");
            break;
        case eSTC_RelationGetMessageFromFriend:
            printf("{好友聊天功能添加}");
            break;
        case eSTC_RelationGetMessageFromFriendLogin:
            printf("{好友上线消息更新}");
            break;
        case eSTC_SelfStateUpdate:
            printf("{自身分组状态更新}");
            break;
        case eSTC_RelationGroupUpdate:
            printf("{分组状态更新}");
            break;
        case eSTC_RelationOnLineStateUpdate:
            printf("{好友上线提醒更新}");
            break;
        case eSTC_RelationDelFriendUpdate:
            printf("{eSTC_RelationDelFriendUpdate}");
            break;
        case eSTC_Team_Flag:
            printf("{eSTC_Team_Flag}");
            break;
        case eSTC_MailRecieveMailNotice:
            printf("{接收邮件通知}");
            break;
        case eSTC_RelationStrangersCallback:
            printf("{最近聊天的陌生人关系信息回复}");
            break;
        case eSTC_ChatplayerInfoCallBack:
            printf("{陌生玩家信息获取}");
            break;
        case eSTC_FriendplayerInfoCallBack:
            printf("{好友玩家信息获取}");
            break;
        case eSTC_CompensateReLogin:
            printf("{补偿系统重新登录红点}");
            break;
        case eSTC_NoviceCopy_Step:
            printf("{新手引导重新登录的进度提醒}");
            break;
        case eSTC_Fly_Trans:
            printf("{穿墙后}");
            break;
        case eSTC_CompensateSync:
            printf("{补偿系统同步}");
            break;
        case eSTC_PvNpc:
            printf("{仙友教学本}");
            break;
        case eSTC_Demon:
            printf("{天劫试炼}");
            break;
        case eSTC_Team_HeadBorder:
            printf("{eSTC_Team_HeadBorder}");
            break;
        case eSTC_Health:
            printf("{eSTC_Health}");
            break;
        case eSTC_Team_VipLevel:
            printf("{eSTC_Team_VipLevel}");
            break;
        case eSTC_Team_Vip:
            printf("{eSTC_Team_Vip}");
            break;
        case eSTC_Guild_News:
            printf("{门派的消息提示}");
            break;
        case eSTC_Guild:
            printf("{门派}");
            break;
        case eSTC_GuildActivity_KillCrt:
            printf("{门派活动清缴精英怪}");
            break;
        case eSTC_Guild_Training:
            printf("{门派试炼}");
            break;
        case eSTC_HiddenLoveRel:
            printf("{婚缘暗恋关系}");
            break;
        case eSTC_Love:
            printf("{婚缘协议}");
            break;
        case eSTC_GuildChangeName:
            printf("{门派改名}");
            break;
        case eSTC_GuildProtectOrKill:
            printf("{门派护送或刺杀}");
            break;
        case eSTC_Guild_Union:
            printf("{门派敌对}");
            break;
        case eSTC_Guild_Activity:
            printf("{门派活动}");
            break;
        case eSTC_Guild_Real_Union:
            printf("{门派联盟}");
            break;
        case eSTC_GuildAddNumber:
            printf("{门派增加额外人数}");
            break;
        case eSTC_GuildWarehouse:
            printf("{门派仓库}");
            break;
        case eSTC_TrialLevel:
            printf("{高难度属性副本试炼}");
            break;
        case eSTC_GuildSkill:
            printf("{门派技能}");
            break;
        case eSTC_Twin_Tower:
            printf("{双塔奇兵}");
            break;
        case eSTC_Avatar_Enchant:
            printf("{时装附魔}");
            break;
        case eSTC_TeamRacing_Watch:
            printf("{观战}");
            break;
        case eSTC_Guild_BnWar:
            printf("{上古战场}");
            break;
        case eSTC_PartnerTrialLevel:
            printf("{高难度副本试炼}");
            break;
        case eSTC_Bowl:
            printf("{门派活动}");
            break;
        case eSTC_Liveness:
            printf("{活跃度相关}");
            break;
        case eSTC_Online_Act:
            printf("{限时活动相关}");
            break;
        case eSTC_RPTask:
            printf("{系统红包任务相关}");
            break;
        case eSTC_Match:
            printf("{匹配相关}");
            break;
        case eSTC_TeamVote:
            printf("{队伍内投票}");
            break;
        case eSTC_ActivityCopy:
            printf("{活动副本相关}");
            break;
        case eSTC_ActivityPvp:
            printf("{活动pvp相关}");
            break;
        case eSTC_PvpFight:
            printf("{pvp战斗相关}");
            break;
        case eSTC_NoviceCopy:
            printf("{新手本}");
            break;
        case eSTC_Master:
            printf("{师徒}");
            break;
        case eSTC_IntoArea:
            printf("{eSTC_IntoArea}");
            break;
        case eSTC_OutArea:
            printf("{eSTC_OutArea}");
            break;
        case eSTC_GuildGodLight:
            printf("{公会神光}");
            break;
        case eSTC_LogNormal:
            printf("{eSTC_LogNormal}");
            break;
        case eSTC_AllXX:
            printf("{全民寻仙}");
            break;
        case eSTC_TimeSync:
            printf("{同步时间}");
            break;
        case eSTC_KillHonor:
            printf("{战场击杀荣誉}");
            break;
        case eSTC_ActivityStaging:
            printf("{活动集结}");
            break;
        case eSTC_AreaMusic:
            printf("{区域音乐}");
            break;
        case eSTC_PVPGod:
            printf("{斗神坛}");
            break;
        case eSTC_Guild_family:
            printf("{门派家族}");
            break;
        case eSTC_MasterMate:
            printf("{师徒门派活动}");
            break;
        case eSTC_NeedLogin:
            printf("{需要重新登录}");
            break;
        case eSTC_onlineBundleResetTimer:
            printf("{在线礼包重置时间}");
            break;
        case STC_Guild_Damage_Statistics:
            printf("{STC_Guild_Damage_Statistics}");
            break;
        case eSTC_Dancing:
            printf("{跳舞}");
            break;
        case eSTC_beginDancing:
            printf("{开始跳舞}");
            break;
        case eSTC_stopDancing:
            printf("{跳舞结束}");
            break;
        case eSTC_setDancingGesture:
            printf("{跳舞动作}");
            break;
        case eSTC_dancingErrorMsg:
            printf("{跳舞错误消息}");
            break;
        case eSTC_dancingFlyTo:
            printf("{叫本地自己主动发一次flyto}");
            break;
        case eSTC_GetShaYunRankValue:
            printf("{向客户端发送杀运排行榜}");
            break;
        case eSTC_RidePlayer:
            printf("{背人请求}");
            break;
        case eSTC_ConfuseBattle:
            printf("{虫虫大乱斗}");
            break;
        case eSTC_CloneBattle:
            printf("{eSTC_CloneBattle}");
            break;
        case eSTC_Accompany:
            printf("{陪伴帮助}");
            break;
        case eSTC_TaskFinishedPop:
            printf("{弹出任务面板}");
            break;
        case eSTC_LevelLock:
            printf("{等级锁}");
            break;
        case eSTC_Levelfly:
            printf("{等级直升活动}");
            break;
        case eSTC_GoToBN:
            printf("{请求跨服}");
            break;
        case eSTC_LeaveBN:
            printf("{请求返回}");
            break;
        case eSTC_ACCT_GET_OPENID:
            printf("{根据openid获取玩家数据}");
            break;
        case eSTC_TX_Friend_Gift:
            printf("{给好友送心}");
            break;
        case eSTC_TX_Friend_GetList:
            printf("{获取好友openid列表}");
            break;
        case eSTC_TX_Friend_Award:
            printf("{自己的好友数量达到多少个领取奖励}");
            break;
        case eSTC_TX_Daily_Share:
            printf("{每日大图分享}");
            break;
        case eSTC_PAY_GET:
            printf("{接入支付，查询}");
            break;
        case eSTC_PAY_SET:
            printf("{接入支付，购买}");
            break;
        case eSTC_PAY_CANCEL:
            printf("{接入支付，取消}");
            break;
        case eSTC_PAY_PRESENT:
            printf("{接入支付，赠送}");
            break;
        case eSTC_Misc:
            printf("{eSTC_Misc}");
            break;
        case eSTC_Grow_Fund:
            printf("{成长基金}");
            break;
        case eSTC_Licai_Card:
            printf("{周卡月卡}");
            break;
        case eSTC_QQVip_RedDot:
            printf("{QQ会员红点}");
            break;
        case eSTC_MsdkBtn_Control_Res:
            printf("{NSDK按钮反馈消息}");
            break;
        case eSTC_Change_Name:
            printf("{改名}");
            break;
        case eSTC_Couple_Dance:
            printf("{双人跳舞}");
            break;
        case eSTC_ChgCoolDown:
            printf("{改变CD}");
            break;
        case eSTC_Team_Racing:
            printf("{eSTC_Team_Racing}");
            break;
        case eSTC_War_Team:
            printf("{eSTC_War_Team}");
            break;
        case eSTC_War_Team_Fight:
            printf("{eSTC_War_Team_Fight}");
            break;
        case eSTC_New_Licai_Card:
            printf("{新月卡}");
            break;
        case eSTC_AvatarDye:
            printf("{时装解锁染色}");
            break;
        case eSTC_Wedding:
            printf("{婚礼}");
            break;
        case eSTC_WarTeam_Flag:
            printf("{eSTC_WarTeam_Flag}");
            break;
        case eSTC_WarTeam_Member_Flag:
            printf("{eSTC_WarTeam_Member_Flag}");
            break;
        case eSTC_Voip:
            printf("{实时语音}");
            break;
        case eSTC_Move_RetCode:
            printf("{移动回包测试}");
            break;
        case eSTC_KillingActInfo:
            printf("{杀劫活动开启或关闭}");
            break;
        case eSTC_KillingActPanleInfo:
            printf("{杀劫活动界面信息}");
            break;
        case eSTC_KillingActOpenInfo:
            printf("{杀劫活动个人开启或关闭}");
            break;
        case eSTC_KillingActScnInfo:
            printf("{通知客户端杀劫活动场景信息}");
            break;
        case eSTC_KillingActCount:
            printf("{购买成功后返回客户端杀劫次数}");
            break;
        case eSTC_SwitchTriGroup:
            printf("{eSTC_SwitchTriGroup}");
            break;
        case eSTC_LuckyBag:
            printf("{福袋}");
            break;
        case eSTC_Friend_List_WX:
            printf("{微信好友列表}");
            break;
        case eSTC_Friend_List_QQ:
            printf("{QQ好友列表}");
            break;
        case eSTC_LuckyBag_AutoSend:
            printf("{福袋自动发放}");
            break;
        case eSTC_DPSDamage:
            printf("{dps详细}");
            break;
        case eSTC_Answer_ReturnTime:
            printf("{春节答题题号发送}");
            break;
        case eSTC_Lottery:
            printf("{海外十连抽}");
            break;
        case eSTC_LotteryStore:
            printf("{海外积分商城}");
            break;
        case eSTC_dice_sendinfo:
            printf("{骰子活动信息发送}");
            break;
        case eSTC_Season_Box:
            printf("{四时仙盒信息发送}");
            break;
        case eSTC_Patface:
            printf("{海外拍脸}");
            break;
        case eSTC_Activity_Misc:
            printf("{一些杂乱的活动或者需求很简单的协议}");
            break;
        case eSTC_HeroStatue:
            printf("{宁海县雕像}");
            break;
        case eSTC_VipOnlineNotice:
            printf("{vip上线提醒}");
            break;
        case eSTC_RushXianjie:
            printf("{冲仙阶活动}");
            break;
        case eSTC_ArenaContest:
            printf("{擂台赛}");
            break;
        case eSTC_SetPos:
            printf("{eSTC_SetPos}");
            break;
        case eSTC_SignIn:
            printf("{每日签到}");
            break;
        case eSTC_LoveEvent:
            printf("{520情缘活动}");
            break;
        case eSTC_LoveBoatEvent:
            printf("{520情缘小船}");
            break;
        case eSTC_LoveBoatEvent_Island:
            printf("{情缘岛小船}");
            break;
        case eSTC_mopup_OneClick:
            printf("{使用一键扫荡道具}");
            break;
        case eSTC_Corps:
            printf("{战队赛创建战队}");
            break;
        case eSTC_FireWorks:
            printf("{烟花大会}");
            break;
        case eSTC_HateList:
            printf("{eSTC_HateList}");
            break;
        case eSTC_SecretBook:
            printf("{秘籍}");
            break;
        case eSTC_sendRacingTeamInfo:
            printf("{发送消息给战队赛竞猜界面}");
            break;
        case eSTC_NewAnswer:
            printf("{新答题活动}");
            break;
        case eSTC_herorank:
            printf("{英雄榜}");
            break;
        case eSTC_SuitCollect:
            printf("{套装手机}");
            break;
        case eSTC_Warcraft_Gift:
            printf("{仙府争霸}");
            break;
        case eSTC_RedPacket_Statue:
            printf("{宁海县雕像红包}");
            break;
        case eSTC_SyncNpcPos:
            printf("{小地图npc位置同步}");
            break;
        case eSTC_simpleexchange:
            printf("{简单兑换}");
            break;
        case eSTC_Ancient_BattleField:
            printf("{上古战场}");
            break;
        case eSTC_pet_car_equip:
            printf("{骑宠装备}");
            break;
        case eSTC_ancientBattleField:
            printf("{上古战场竞技服消息}");
            break;
        case eSTC_Copy_Wasteland:
            printf("{开荒模式}");
            break;
        case eSTC_OldPlayerReturn:
            printf("{老玩家回归}");
            break;
        case eSTC_MiniGame:
            printf("{迷你游戏}");
            break;
        case eSTC_RidePet_Collect:
            printf("{骑宠手机}");
            break;
        case eSTC_Scn_Answer:
            printf("{场景答题活动}");
            break;
        case eSTC_GlobalLimitBuying:
            printf("{全服抢购}");
            break;
        case eSTC_GlobalLimitOYToBuy:
            printf("{eSTC_GlobalLimitOYToBuy}");
            break;
        case eSTC_RidePet_Soul:
            printf("{骑宠御灵}");
            break;
        case eSTC_MultiBattle:
            printf("{无战力多人活动}");
            break;
        case eSTC_ZhaoCaiMao:
            printf("{eSTC_ZhaoCaiMao}");
            break;
        case eSTC_RMB_Bowl:
            printf("{rmb聚宝盆}");
            break;
        case eSTC_Contest_PVP:
            printf("{竞赛pvp}");
            break;
        case eSTC_DevilPVP:
            printf("{魔域城pvp活动}");
            break;
        case eSTC_OYToBuy:
            printf("{一元购}");
            break;
        case eSTC_NewZone_BackFlow:
            printf("{新区绑定老角色福利活动}");
            break;
        case eSTC_Scry:
            printf("{卦象}");
            break;
        case eSTC_Chat_FaceTipOpen:
            printf("{付费表情包}");
            break;
        case eSTC_XianJie_Battle:
            printf("{天宫仙位积分赛}");
            break;
        case eSTC_UI_LotteryPendant:
            printf("{娃娃挂件}");
            break;
        case eSTC_personalGuessMsg:
            printf("{巅峰赛竞猜相关消息}");
            break;
        case eSTC_GetSuperRInfo:
            printf("{获取超R玩家会员等级信息}");
            break;
        case eSTC_Complaint:
            printf("{举报投诉}");
            break;
        case eSTC_Lottery_new:
            printf("{新须弥纳宝盒}");
            break;
        case eSTC_Screen_Shot:
            printf("{拍照道具激活}");
            break;
        case eSTC_TempleMatch:
            printf("{天宫赛相关信息}");
            break;
        case eSTC_Love_Match:
            printf("{情缘匹配}");
            break;
        case eSTC_New_TotalCharge:
            printf("{新累计充值活动}");
            break;
        case eSTC_Flea_Market:
            printf("{跳蚤市场}");
            break;
        case eSTC_New_Bid:
            printf("{eSTC_New_Bid}");
            break;
        case eSTC_Partner:
            printf("{伙伴}");
            break;
        case eSTC_Tdbk:
            printf("{天帝宝库}");
            break;
        case eSTC_FireworksParty:
            printf("{烟花大会}");
            break;
        case eSTC_BirthDay:
            printf("{生辰返利}");
            break;
        case eSTC_AnswerMatch:
            printf("{竞技答题}(2 same{翻牌子})");
            break;
            //case eSTC_Flop:
        case eSTC_Alchemy:
            printf("{炼丹}");
            break;
        case eSTC_Online_Quest:
            printf("{在线任务}");
            break;
        case eSTC_Family_Chess:
            printf("{五子棋}");
            break;
        case eSTC_New_Share:
            printf("{拉新活动}");
            break;
        case eSTC_Other_Book:
            printf("{异闻录}");
            break;
        case eSTC_UI_Debts:
            printf("{欠账}");
            break;
        case eSTC_Bounty:
            printf("{eSTC_Bounty}");
            break;
        case eSTC_ItemCrit:
            printf("{道具暴击}");
            break;
        case eSTC_NewServer:
            printf("{新服活动}");
            break;
        case eSTC_Player_Cancellation:
            printf("{注销}");
            break;
        case eSTC_UI_Ghost:
            printf("{残影}");
            break;
        case eSTC_Send_Openid:
            printf("{通知某个openid发送客户端日志到服务器}");
            break;
        case eSTC_Span_KillMonster:
            printf("{跨服杀怪}");
            break;
        case eSTC_imprint:
            printf("{装备雕刻系统}");
            break;
        case eSTC_Spring_activity:
            printf("{春游活动}");
            break;
        case eSTC_Practice:
            printf("{穴位修炼}");
            break;
        case eSTC_Weekend_Race_Speed:
            printf("{周末竞速}");
            break;
        case eSTC_Five_Elements:
            printf("{五行}");
            break;
        case eSTC_Copy_GreatSecret:
            printf("{eSTC_Copy_GreatSecret}");
            break;
        case eSTC_respectGod:
            printf("{敬天宝囊}");
            break;
        case eSTC_PVPGod_Robot:
            printf("{须弥幻境}(2 same)");
            break;
            //case eSTC_UI_Xmhj:
        case eSTC_Universe:
            printf("{eSTC_Universe}");
            break;
        case eSTC_HateTips:
            printf("{仇恨}");
            break;
        case eSTC_SuperPowers:
            printf("{神通}");
            break;
        case eSTC_UI_Aerocraft:
            printf("{趣味飞行器}");
            break;
        case eSTC_TcgCard:
            printf("{集换卡牌}");
            break;
        case eSTC_TcgCardData:
            printf("{集换卡牌数据}");
            break;
        case eSTC_Devildom:
            printf("{魔界裂缝}");
            break;
        case eSTC_OptionalGift:
            printf("{自选礼包}");
            break;
        case eSTC_TreasureHunt:
            printf("{跨服寻宝}");
            break;
        case eSTC_Love_Chess:
            printf("{eSTC_Love_Chess}");
            break;
        case eSTC_NewLoop_Quest:
            printf("{eSTC_NewLoop_Quest}");
            break;
        case eSTC_Holy_Spirit:
            printf("{eSTC_Holy_Spirit}");
            break;
        case eSTC_VipRechargeAward:
            printf("{eSTC_VipRechargeAward}");
            break;
        case eSTC_Seal_Monster:
            printf("{封妖玩法}");
            break;
        case eSTC_DivineWeapon:
            printf("{神兵系统}");
            break;
        case eSTC_WestWalk:
            printf("{西行玩法}");
            break;
        case eSTC_ReturnShop:
            printf("{eSTC_ReturnShop}");
            break;
        case eSTC_RentPet:
            printf("{eSTC_RentPet}");
            break;
        case eSTC_Copy_Growth:
            printf("{副本成长}");
            break;
        case eSTC_ScnObj_SyncHp2:
            printf("{血量溢出}");
            break;
        case eSTC_Ribbon:
            printf("{飘带}");
            break;
        case eSTC_Xianyue_Chess:
            printf("{仙乐台对弈}");
            break;
        case eSTC_Guild_Chess:
            printf("{门派对弈}");
            break;
        case eSTC_PVP_30v30:
            printf("{跨服战场30v30}");
            break;
        case eSTC_New_Server_Item:
            printf("{获取新服活动礼包道具}");
            break;
        case eSTC_New_Server_Buy:
            printf("{新服活动购买}");
            break;
        case eSTC_New_Server_Time:
            printf("{新服活动时间}");
            break;
        case eSTC_New_Server_Receive:
            printf("{新服嘉年华领取}");
            break;
        case eSTC_Carnival_Liveness_Receive:
            printf("{新服嘉年华活跃度领取}");
            break;
        default:
            printf("{unknown cmd code}");
            break;
    }
}
