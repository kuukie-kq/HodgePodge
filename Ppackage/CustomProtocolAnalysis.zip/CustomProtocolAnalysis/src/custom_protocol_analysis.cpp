//
// Created by kuu-kie on 2022/7/8.
//

#include "custom_protocol_analysis.h"

void data_request_analysis(u1_int* data, int len) {
    // display
    #ifdef DISPLAY7
    printf("[request package]");
    #endif // DISPLAY7

    if (len < NUMBER_ELEVEN) { throw DATA_TOO_SMALL; }
    // >.<
    for(;len >= NUMBER_ELEVEN;) {
        u4_int datalen;
        read_data(data, len, datalen, sizeof(datalen));
        byte mask;
        read_data(data, len, mask, sizeof(mask));

        if ((mask & MASK_ENCRYPT) != NUMBER_ZERO) {
            SDDCCF->gxai_down(MASK_ENCRYPT, data, datalen);
        }
        u4_int crc;
        read_data(data, len, crc, sizeof(crc));
        u2_int cmd;
        read_data(data, len, cmd, sizeof(cmd));
        int cmd14 = cmd & FIRST_14;
        int fmt2 = cmd >> LAST_2;
        // display
        #ifdef DISPLAY5
        printf("\n\tdatalen=%u(-6=data packet length)\tmask:0x%x\tcrc=%u\n",
			datalen, mask, crc);
        #endif // DISPLAY5

        if (crc != CRC_NUMBER)
        #ifdef THROW_11
        { printf("\tcrc number not magic ! maybe init\n"); return; }
        #else
        { throw DATA_CRC_ERROR; }
        #endif // THROW_11

        if ((mask & MASK_COMPRESS) != NUMBER_ZERO) {
            if (SDDCCF->compress_byte != nullptr) { delete SDDCCF->compress_byte; }
            if (SDDCCF->compress_len == nullptr) { SDDCCF->compress_len = (int*)malloc(sizeof(SDDCCF->compress_len)); }
            SDDCCF->compress_byte = (u1_int*)malloc(MAX_COMPRESS_LENGTH);
            *SDDCCF->compress_len = MAX_COMPRESS_LENGTH;

            SDDCCF->gxai_uncompress(SDDCCF->compress_byte, SDDCCF->compress_len, data, datalen);
            // display
            #ifdef DISPLAY7
            display_client_to_server(cmd14);
            #endif // DISPLAY7

            process_package(cmd14, fmt2, SDDCCF->compress_byte, *SDDCCF->compress_len);
        }
        else {
            // display
            #ifdef DISPLAY7
            display_client_to_server(cmd14);
            #endif // DISPLAY7

            process_package(cmd14, fmt2, data, datalen - NUMBER_SIX);
        }

        data = data + datalen - NUMBER_SIX;
        len = len - datalen + NUMBER_SIX;
    }
    if (len != NUMBER_ZERO) { throw PACKAGE_HAVE_NO_DATA; }
}

void data_response_analysis(u1_int* data, int len) {
    // display
    #ifdef DISPLAY7
    printf("[response package]");
    #endif // DISPLAY7

    if (len < NUMBER_NINE) { throw DATA_TOO_SMALL; }
    // >.<
    for (;len >= NUMBER_NINE;) {
        u4_int datalen;
        read_data(data, len, datalen, sizeof(datalen));
        byte mask;
        read_data(data, len, mask, sizeof(mask));

        if ((mask & MASK_ENCRYPT) != NUMBER_ZERO) {
            SDD->gxai_down(MASK_ENCRYPT, data, datalen);
        }
        u4_int crc;
        read_data(data, len, crc, sizeof(crc));
        // display
        #ifdef DISPLAY5
        printf("\n\tdatalen=%u(-4=data packet length)\tmask:0x%x\tcrc=%u\n",
			datalen, mask, crc);
        #endif // DISPLAY5

        if (crc != CRC_NUMBER)
        #ifdef THROW_11
        { printf("\tcrc number not magic ! maybe init\n"); return; }
        #else
        { throw DATA_CRC_ERROR; }
        #endif // THROW_11

        if ((mask & MASK_COMPRESS) != NUMBER_ZERO) {
            if (SDD->compress_byte != nullptr) { delete SDD->compress_byte; }
            if (SDD->compress_len == nullptr) { SDD->compress_len = (int*)malloc(sizeof(SDD->compress_len)); }
            SDD->compress_byte = (u1_int*)malloc(MAX_COMPRESS_LENGTH);
            *SDD->compress_len = MAX_COMPRESS_LENGTH;
            // debug

            SDD->gxai_uncompress(SDD->compress_byte, SDD->compress_len, data, datalen - NUMBER_FOUR);
            data_package(SDD->compress_byte, *SDD->compress_len);
        }
        else {
            data_package(data, datalen - NUMBER_FOUR);
        }

        data = data + datalen - NUMBER_FOUR;
        len = len - datalen + NUMBER_FOUR;
    }
    if (len != NUMBER_ZERO) { throw PACKAGE_HAVE_NO_DATA; }
}

void data_package(u1_int* data, int len) {
    for (; len > NUMBER_FOUR;) {
        u4_int data_len;
        read_data(data, len, data_len, sizeof(data_len));

        if (data_len < (u4_int)NUMBER_TWO || data_len > (u4_int)len) { throw DATA_PACKAGE_LENGTH_FAILED; }

        u2_int cmd;
        read_data(data, len, cmd, sizeof(cmd));
        u1_int* data_data = (u1_int*)malloc(data_len - sizeof(cmd));
        read_data(data, len, data_data, data_len - sizeof(cmd));

        int cmd14 = cmd & FIRST_14;
        int fmt2 = cmd >> LAST_2;
        // display
        #ifdef DISPLAY6
        printf("len=%d(count+2cmd)\tcmd=0x%x\t数据格式:%u %u\n",
			data_len, cmd, cmd14, fmt2);
        #endif // DISPLAY6

        // display
        #ifdef DISPLAY7
        display_server_to_client(cmd14);
        #endif // DISPLAY7

        process_package(cmd14, fmt2, data_data, data_len - sizeof(cmd));
        free(data_data);
    }
    if (len != NUMBER_ZERO) { throw PACKAGE_HAVE_NO_DATA; }
}

void process_package(int cmd, int fmt, u1_int* data, int size) {
    // pass
    #ifdef DISPLAY7
    if (fmt == NUMBER_ONE) {
        printf("[cmd=%5u]data json size(%u) : ", cmd, size);
        for (int i = NUMBER_ZERO; i < size; i++) {
            printf("%c", *(data + i));
        }
        printf("\tEOF\n");
    } else {
        printf("[cmd=%5u]data method size(%u)\tEND\n", cmd, size);
    }
    #endif // DISPLAY7
}
