//
// Created by kuu-kie on 2022/7/8.
// 对于数据链路层，网络层，传输层协议进行简单解析
//

#ifndef CUSTOMPROTOCOLANALYSIS_GLOBAL_PROTOCOL_ANALYSIS_H
#define CUSTOMPROTOCOLANALYSIS_GLOBAL_PROTOCOL_ANALYSIS_H

#include "cache_protocol_analysis.h"

extern void ether_analysis(const void* packet, int length);
extern void internet_analysis(const void* packet, int length);
extern void transport_analysis(const void* packet, int length);

#endif //CUSTOMPROTOCOLANALYSIS_GLOBAL_PROTOCOL_ANALYSIS_H
