//
// Created by kuu-kie on 2022/7/8.
// 读取pcap文件的函数
//

#ifndef CUSTOMPROTOCOLANALYSIS_PCAP_FILE_ANALYSIS_H
#define CUSTOMPROTOCOLANALYSIS_PCAP_FILE_ANALYSIS_H

#include "global_protocol_analysis.h"

extern int read_analysis(const char* file);

#endif //CUSTOMPROTOCOLANALYSIS_PCAP_FILE_ANALYSIS_H
