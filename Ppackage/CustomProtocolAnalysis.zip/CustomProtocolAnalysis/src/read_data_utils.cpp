//
// Created by kuu-kie on 2022/7/8.
// 其中通过u1_int*&read为比较通用的做法，可以读任何数据，但是需要自行做类型转换
//

#include "read_data_utils.h"

int read_data(u1_int*& data, int& len, u4_int& read, const int read_len) {
    if (len >= read_len && read_len > NUMBER_ZERO) {
        read = *(u4_int*)data;
        data = data + read_len;
        len = len - read_len;
        return 0;
    }
    else { throw DATA_LENGTH_READ_FAILED; }
}

int read_data(u1_int*& data, int& len, u2_int& read, const int read_len) {
    if (len >= read_len && read_len > NUMBER_ZERO) {
        read = *(u2_int*)data;
        data = data + read_len;
        len = len - read_len;
        return 0;
    }
    else { throw DATA_LENGTH_READ_FAILED; }
}

int read_data(u1_int*& data, int& len, u1_int& read, const int read_len) {
    if (len >= read_len && read_len > NUMBER_ZERO) {
        read = *(u1_int*)data;
        data = data + read_len;
        len = len - read_len;
        return 0;
    }
    else { throw DATA_LENGTH_READ_FAILED; }
}

int read_data(u1_int*& data, int& len, u1_int*& read, const int read_len) {
    if (len >= read_len && read_len > NUMBER_ZERO) {
        u1_int* read_data = read;
        for (int i = 0; i < read_len; i++) {
            *read_data = *data;
            data++;
            read_data++;
        }
        len = len - read_len;
        return 0;
    }
    else { throw DATA_LENGTH_READ_FAILED; }
}
