//
// Created by kuu-kie on 2022/7/8.
//

#include "cache_protocol_analysis.h"

int analysis() {
    for (int i = NUMBER_ZERO; !SDD->bcs.empty(); i++) {
        bool flag_response = SDD->bcs.front();
        std::chrono::nanoseconds ns = SDD->timestamp.front();
        std::chrono::time_point<std::chrono::system_clock, std::chrono::nanoseconds> ns_tp = std::chrono::time_point<std::chrono::system_clock, std::chrono::nanoseconds>(ns);
        std::time_t ns_tt = std::chrono::system_clock::to_time_t(ns_tp);
        std::tm* ns_tm = std::localtime(&ns_tt);
        // debug 对于chrono库的使用 这里无业务逻辑，处理方式i==7，是业务中登录成功后需要做的一个操作
        printf("[%4d]%02d时%02d分%02d秒%03d毫秒%03d微秒%03d纳秒", i + NUMBER_ONE, ns_tm->tm_hour, ns_tm->tm_min, ns_tm->tm_sec, ns.count() % NANO_FROM_SECOND / NANO_FROM_MILLISECOND, ns.count() % NANO_FROM_MILLISECOND / NANO_FROM_MICROSECOND, ns.count() % NANO_FROM_MICROSECOND);

        int port = SDD->port.front();
        if (port == MY_SERVER_UDP_PORT && SDD->last_port != MY_SERVER_UDP_PORT) {
            // 重新连接或首次进入
            SDD->gaxi_init(CLIENT_START);
            SDDCCF->gaxi_init(CLIENT_START);
            SDD->last_port = MY_SERVER_UDP_PORT;
        }
        if (port == MY_SERVER_TCP_PORT && SDD->last_port != MY_SERVER_TCP_PORT) {
            // 连完CAAFS转连CLS
            SDD->gaxi_init(CLIENT_CONNECT);
            SDDCCF->gaxi_init(CLIENT_CONNECT);
            SDD->last_port = MY_SERVER_TCP_PORT;
        }

        if (flag_response) {
            u1_int* buffer = SDD->buf.front();
            int count = SDD->cnt.front();
            data_response_analysis(buffer, count);
            SDD->buf.pop();
            SDD->cnt.pop();
            delete buffer;
        } else {
            u1_int* buffer = SDDCCF->buf.front();
            int count = SDDCCF->cnt.front();
            data_request_analysis(buffer, count);
            SDDCCF->buf.pop();
            SDDCCF->cnt.pop();
            delete buffer;
        }
        SDD->port.pop();
        SDD->timestamp.pop();
        SDD->bcs.pop();
    }
    return 0;
}

void special_not_analysis(const tcp_header* const tcp, const void* const packet, int length) {
    if ((tcp->flags & SECOND_TCP_SYN) == SECOND_TCP_SYN) { return; }
    if (length == 0) { return; }
    class ether_padding {
    public:
        u1_int pad1;
        u1_int pad2;
        u1_int pad3;
        u1_int pad4;
        u1_int pad5;
        u1_int pad6;
        bool padding_data() {
            return pad1 == 0 && pad2 == 0 && pad3 == 0 && pad4 == 0 && pad5 == 0 && pad6 == 0;
        }
        int data_length_unpadding() {
            int count = 0;
            if (pad1 != 0) { count++; }
            if (pad2 != 0) { count++; }
            if (pad3 != 0) { count++; }
            if (pad4 != 0) { count++; }
            if (pad5 != 0) { count++; }
            if (pad6 != 0) { count++; }
            return count;
        }
    };
    if (length == 6) { ether_padding* padding = (ether_padding*)packet; if (padding->padding_data()) return; if ((tcp->flags & SECOND_TCP_PSH) != SECOND_TCP_PSH) throw NOT_DATA_NOT_PADDING; else { printf("warning debug data but exist padding size(%d,6)\n", padding->data_length_unpadding()); length = padding->data_length_unpadding(); } }

    if (ntohs(tcp->src_port) == MY_SERVER_TCP_PORT || ntohs(tcp->src_port) == MY_SERVER_UDP_PORT) {
        if ((tcp->flags & SECOND_TCK_ACK) == SECOND_TCK_ACK) {
            int max_length = MTU_PACKET_LENGTH - IPV4_FIXED_HEAD_LENGTH - TCP_FIXED_HEAD_LENGTH;
            if (length > max_length) {
                if (length > 1464) { throw LENGTH_MORETHEN_MAX; }
                printf("warning debug data length %4d , + 40为链路层帧大小\n", length);
            }
            if (length == max_length) {
                u1_int *last_data = SDD->gcs;
                if (last_data != nullptr && SDD->gss != NUMBER_ZERO) {
                    u4_int last_length = SDD->gss;
                    SDD->gcs = (u1_int *) malloc(last_length + length);
                    SDD->gss = (u4_int) (last_length + length);
                    for (int i = NUMBER_ZERO; (u4_int) i < last_length; i++) {
                        *(SDD->gcs + i) = *(last_data + i);
                    }
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *(SDD->gcs + last_length + i) = *((u1_int *) packet + i);
                    }
                    delete last_data;
                } else {
                    if (!(last_data == nullptr && SDD->gss == NUMBER_ZERO)) { throw STATIC_MEMORE_ERROR; }
                    SDD->gcs = (u1_int *) malloc(length);
                    SDD->gss = (u4_int) length;
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *(SDD->gcs + i) = *((u1_int *) packet + i);
                    }
                }
                // 分组包，后续还有内容
                return;
            }

            if ((tcp->flags & SECOND_TCP_PSH) == SECOND_TCP_PSH) {
                std::chrono::nanoseconds ns = std::chrono::duration_cast<std::chrono::nanoseconds>
                        (std::chrono::nanoseconds((long long) SDD->tss * NANO_FROM_SECOND +
                                                  (long long) SDD->tsm * NANO_FROM_MICROSECOND));
                SDD->timestamp.push(ns);
                if (SDD->gss == NUMBER_ZERO) {
                    u1_int *buffer = (u1_int *) malloc(length);
                    u1_int *bf = buffer;
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *bf++ = *((u1_int *) packet + i);
                    }

                    // 条件提前，这里的条件可以删掉
//                    if (ntohs(tcp->src_port) == MY_SERVER_TCP_PORT || ntohs(tcp->src_port) == MY_SERVER_UDP_PORT) {
                        SDD->port.push(ntohs(tcp->src_port));
                        SDD->bcs.push(true);
                        SDD->buf.push(buffer);
                        SDD->cnt.push(length);
//                    } else {
//                        SDD->port.push(ntohs(tcp->des_port));
//                        SDD->bcs.push(false);
//                        SDDCCF->buf.push(buffer);
//                        SDDCCF->cnt.push(length);
//                    }
                } else {
                    u1_int *buffer = (u1_int *) malloc(SDD->gss + length);
                    for (int i = NUMBER_ZERO; (u4_int) i < SDD->gss; i++) {
                        *(buffer + i) = *(SDD->gcs + i);
                    }
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *(buffer + SDD->gss + i) = *((u1_int *) packet + i);
                    }

                    // 条件提前，这里的条件可以删掉
//                    if (ntohs(tcp->src_port) == MY_SERVER_TCP_PORT || ntohs(tcp->src_port) == MY_SERVER_UDP_PORT) {
                        SDD->port.push(ntohs(tcp->src_port));
                        SDD->bcs.push(true);
                        SDD->buf.push(buffer);
                        SDD->cnt.push(SDD->gss + length);
//                    } else {
//                        SDD->port.push(ntohs(tcp->des_port));
//                        SDD->bcs.push(false);
//                        SDDCCF->buf.push(buffer);
//                        SDDCCF->cnt.push(SDD->gss + length);
//                    }

                    delete SDD->gcs;
                    SDD->gcs = nullptr;
                    SDD->gss = (u4_int) NUMBER_ZERO;
                }
            } else { throw NOT_SYN_FIN_BUT_ACK; }
        } else { throw NOT_ACK_BUT_DATA; }
    } else {
        if ((tcp->flags & SECOND_TCK_ACK) == SECOND_TCK_ACK) {
            int max_length = MTU_PACKET_LENGTH - IPV4_FIXED_HEAD_LENGTH - TCP_FIXED_HEAD_LENGTH;
            if (length > max_length) {
                if (length > 1464) { throw LENGTH_MORETHEN_MAX; }
                printf("warning debug data length %4d , + 40为链路层帧大小\n", length);
            }
            if (length == max_length) {
                u1_int *last_data = SDDCCF->gcs;
                if (last_data != nullptr && SDDCCF->gss != NUMBER_ZERO) {
                    u4_int last_length = SDDCCF->gss;
                    SDDCCF->gcs = (u1_int *) malloc(last_length + length);
                    SDDCCF->gss = (u4_int) (last_length + length);
                    for (int i = NUMBER_ZERO; (u4_int) i < last_length; i++) {
                        *(SDDCCF->gcs + i) = *(last_data + i);
                    }
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *(SDDCCF->gcs + last_length + i) = *((u1_int *) packet + i);
                    }
                    delete last_data;
                } else {
                    if (!(last_data == nullptr && SDDCCF->gss == NUMBER_ZERO)) { throw STATIC_MEMORE_ERROR; }
                    SDDCCF->gcs = (u1_int *) malloc(length);
                    SDDCCF->gss = (u4_int) length;
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *(SDDCCF->gcs + i) = *((u1_int *) packet + i);
                    }
                }
                // 分组包，后续还有内容
                return;
            }

            if ((tcp->flags & SECOND_TCP_PSH) == SECOND_TCP_PSH) {
                std::chrono::nanoseconds ns = std::chrono::duration_cast<std::chrono::nanoseconds>
                        (std::chrono::nanoseconds((long long) SDD->tss * NANO_FROM_SECOND +
                                                  (long long) SDD->tsm * NANO_FROM_MICROSECOND));
                SDD->timestamp.push(ns);
                if (SDDCCF->gss == NUMBER_ZERO) {
                    u1_int *buffer = (u1_int *) malloc(length);
                    u1_int *bf = buffer;
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *bf++ = *((u1_int *) packet + i);
                    }

                    // 条件提前，这里的条件可以删掉
//                    if (ntohs(tcp->src_port) == MY_SERVER_TCP_PORT || ntohs(tcp->src_port) == MY_SERVER_UDP_PORT) {
//                        SDD->port.push(ntohs(tcp->src_port));
//                        SDD->bcs.push(true);
//                        SDD->buf.push(buffer);
//                        SDD->cnt.push(length);
//                    } else {
                        SDD->port.push(ntohs(tcp->des_port));
                        SDD->bcs.push(false);
                        SDDCCF->buf.push(buffer);
                        SDDCCF->cnt.push(length);
//                    }
                } else {
                    u1_int *buffer = (u1_int *) malloc(SDDCCF->gss + length);
                    for (int i = NUMBER_ZERO; (u4_int) i < SDDCCF->gss; i++) {
                        *(buffer + i) = *(SDDCCF->gcs + i);
                    }
                    for (int i = NUMBER_ZERO; i < length; i++) {
                        *(buffer + SDDCCF->gss + i) = *((u1_int *) packet + i);
                    }

                    // 条件提前，这里的条件可以删掉
//                    if (ntohs(tcp->src_port) == MY_SERVER_TCP_PORT || ntohs(tcp->src_port) == MY_SERVER_UDP_PORT) {
//                        SDD->port.push(ntohs(tcp->src_port));
//                        SDD->bcs.push(true);
//                        SDD->buf.push(buffer);
//                        SDD->cnt.push(SDDCCF->gss + length);
//                    } else {
                        SDD->port.push(ntohs(tcp->des_port));
                        SDD->bcs.push(false);
                        SDDCCF->buf.push(buffer);
                        SDDCCF->cnt.push(SDDCCF->gss + length);
//                    }

                    delete SDDCCF->gcs;
                    SDDCCF->gcs = nullptr;
                    SDDCCF->gss = (u4_int) NUMBER_ZERO;
                }
            } else { throw NOT_SYN_FIN_BUT_ACK; }
        } else { throw NOT_ACK_BUT_DATA; }
    }
}
