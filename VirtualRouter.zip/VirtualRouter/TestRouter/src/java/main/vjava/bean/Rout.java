package main.vjava.bean;

public class Rout {
    private int routId;
    private String routName;
    private String routAddress;

    public int getRoutId() {
        return routId;
    }

    public void setRoutId(int routId) {
        this.routId = routId;
    }

    public String getRoutName() {
        return routName;
    }

    public void setRoutName(String routName) {
        this.routName = routName;
    }

    public String getRoutAddress() {
        return routAddress;
    }

    public void setRoutAddress(String routAddress) {
        this.routAddress = routAddress;
    }
}
