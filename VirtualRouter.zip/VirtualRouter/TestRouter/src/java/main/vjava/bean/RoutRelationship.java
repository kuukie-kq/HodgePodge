package main.vjava.bean;

public class RoutRelationship {
    private int routShipId;
    private int routId;
    private int routingId;

    public int getRoutShipId() {
        return routShipId;
    }

    public void setRoutShipId(int routShipId) {
        this.routShipId = routShipId;
    }

    public int getRoutId() {
        return routId;
    }

    public void setRoutId(int routId) {
        this.routId = routId;
    }

    public int getRoutingId() {
        return routingId;
    }

    public void setRoutingId(int routingId) {
        this.routingId = routingId;
    }
}
