package main.vjava.bean;

public class RoutingRelationship {
    private int routingShipId;
    private int routingIdf;
    private int routingIdl;

    public int getRoutingShipId() {
        return routingShipId;
    }

    public void setRoutingShipId(int routingShipId) {
        this.routingShipId = routingShipId;
    }

    public int getRoutingIdf() {
        return routingIdf;
    }

    public void setRoutingIdf(int routingIdf) {
        this.routingIdf = routingIdf;
    }

    public int getRoutingIdl() {
        return routingIdl;
    }

    public void setRoutingIdl(int routingIdl) {
        this.routingIdl = routingIdl;
    }
}
