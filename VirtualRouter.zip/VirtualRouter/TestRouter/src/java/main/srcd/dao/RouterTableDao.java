package main.srcd.dao;

import main.srcd.bean.RouterTable;

import java.util.List;

public class RouterTableDao {
    public List<RouterTable> lookupRouterTableGetRouterTables() {
        return null;
    }

    public void lookRouterTable() {
    }
}
