package main.srcd.dao;

import main.srcd.bean.Router;

import java.util.List;

public class RouterDao{
    public List<Router> lookupRouterGetRouters() {
        return null;
    }

    public void lookRouter() {

    }
}
