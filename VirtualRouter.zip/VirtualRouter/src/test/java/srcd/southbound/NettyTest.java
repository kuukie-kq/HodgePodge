package srcd.southbound;

import versionOne.srcd.southbound.router.NettyRouter;

public class NettyTest {
    public static void main(String[] args) {
        NettyRouter nettyRouter = new NettyRouter(2);
        nettyRouter.run();
    }
}
