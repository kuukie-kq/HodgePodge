package com.bigdatacase.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bigdatacase.dal.ItemCategoryProvinceDal;
import com.bigdatacase.po.ItemCategoryProvince;

import net.sf.json.JSONArray;

/**
 * Servlet implementation class LayuiSelectItemCategory
 */
@WebServlet("/lsic")
public class LayuiSelectItemCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LayuiSelectItemCategory() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String itemCategory=new String(request.getParameter("itemCategory").getBytes("ISO8859-1"),"UTF-8");
		int flag=0;
        if(itemCategory.length()>0) {
        	flag=Integer.parseInt(itemCategory);
        }
        ItemCategoryProvinceDal icpd=new ItemCategoryProvinceDal();
		List<ItemCategoryProvince> icpl=icpd.getProvinceByItemCategory(flag);
		
		JSONArray jsonArray = JSONArray.fromObject(icpl);
		
		PrintWriter out = response.getWriter();
		out.print(jsonArray);
	}

}
