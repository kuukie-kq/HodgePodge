package com.bigdatacase.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bigdatacase.dal.ProvinceAccessCountDal;
import com.bigdatacase.po.ProvinceAccessCount;

import net.sf.json.JSONArray;

/**
 * Servlet implementation class IndexInitialization
 */
@WebServlet("/index")
public class IndexInitialization extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexInitialization() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProvinceAccessCountDal pacd=new ProvinceAccessCountDal();
		List<ProvinceAccessCount> pacl=pacd.getCountByDateOrderProvince();
		
		if(request.getSession().getAttribute("index")==null) {
			int i=0;
			request.getSession().setAttribute("index", i);
		} else {
			int i=Integer.parseInt(request.getSession().getAttribute("index").toString());
			i++;
			if(i==5) i=0;
			request.getSession().setAttribute("index", i);
		}
		
		JSONArray jsonArray = JSONArray.fromObject(pacl);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().println(jsonArray);
		
//		request.setAttribute("PACL", pacl);
//		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
//		rd.forward(request, response);
	}

}
