package com.bigdatacase.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bigdatacase.dal.ItemCategoryProvinceDal;
import com.bigdatacase.po.ItemCategoryProvince;

/**
 * Servlet implementation class ProvinceItemCategoryServlet
 */
@WebServlet("/pics")
public class ProvinceItemCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProvinceItemCategoryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String province=new String(request.getParameter("province").getBytes("ISO8859-1"),"UTF-8");
		ItemCategoryProvinceDal icpd=new ItemCategoryProvinceDal();
		List<ItemCategoryProvince> picl=icpd.getItemCategoryByProvince(province);
		
		request.setAttribute("PICL", picl);
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
	}

}
