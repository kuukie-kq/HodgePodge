package com.bigdatacase.servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bigdatacase.dal.ItemCategoryProvinceDal;
import com.bigdatacase.po.ItemCategoryProvince;

/**
 * Servlet implementation class ItemCategoryProvinceServlet
 */
@WebServlet("/icps")
public class ItemCategoryProvinceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ItemCategoryProvinceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		ItemCategoryProvinceDal icpd=new ItemCategoryProvinceDal();
//		List<ItemCategoryProvince> icpl=icpd.getProvinceByItemCategory(657);
//		
//		request.setAttribute("ICPL", icpl);
//		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
//		rd.forward(request, response);
		
		//=====test=====//
		Enumeration paramNames = request.getParameterNames();
		while(paramNames.hasMoreElements()) {
			String paramName = (String)paramNames.nextElement();
			String[] paramValues=request.getParameterValues(paramName);
			if (paramValues.length == 1) {
				
				ItemCategoryProvinceDal icpd=new ItemCategoryProvinceDal();
//				List<ItemCategoryProvince> icpl=icpd.getProvinceByItemCategory(Integer.parseInt(paramValues[0]));
				List<ItemCategoryProvince> icpl=icpd.getProvinceAsMybatis(Integer.parseInt(paramValues[0]));
				
				request.setAttribute("ICPL", icpl);
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
				rd.forward(request, response);
			}
		}
	}

}
