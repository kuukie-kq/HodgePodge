package com.bigdatacase.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bigdatacase.dal.ProvinceAccessCountDal;
import com.bigdatacase.po.ProvinceAccessCount;

import net.sf.json.JSONArray;

/**
 * Servlet implementation class TestJsonServlet
 */
@WebServlet("/TestJsonServlet")
public class TestJsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestJsonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProvinceAccessCountDal pacd=new ProvinceAccessCountDal();
		List<ProvinceAccessCount> pacl=pacd.getCountByDate("1");
		
		JSONArray jsonArray = JSONArray.fromObject(pacl);
		//�����ݵı���
		//response.setCharacterEncoding("UTF-8");
		//����ҳ����뷽ʽʹ��utf-8
		//response.setHeader("content-type", "text/html;charset=utf-8");
		//��õ�API
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().println(jsonArray);
	}

}
