package com.bigdatacase.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLAPI {
	static final String DRIVER="com.mysql.jdbc.Driver";
	static final String DB="jdbc:mysql://localhost/dblab";
	static final String USER="root";
	static final String PASSWD="root";
	
	static Connection conn=null;
	static Statement stmt=null;
	static ResultSet rs=null;
	//����MySQL����
	public static void mysqlInit() throws Exception {
		Class.forName(DRIVER);
		System.out.println("Connecting to a selected database...");
		conn=DriverManager.getConnection(DB,USER,PASSWD);
		stmt=conn.createStatement();
	}
	//�ر�MySQL����
	public static void mysqlClose() throws SQLException {
		if(rs!=null)
			rs.close();
		if(stmt!=null)
			stmt.close();
		if(conn!=null)
			conn.close();
	}
	//����
	public static void mysqlUpdate(String sql) {
		try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��ѯ
	public static void mysqlSelect(String sql) {
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//���ؽ��
	public static ResultSet getRs() {
		return rs;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
