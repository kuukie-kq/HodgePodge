package com.bigdatacase.test;

import java.util.List;

import com.bigdatacase.dal.ItemCategoryProvinceDal;
import com.bigdatacase.po.ItemCategoryProvince;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ItemCategoryProvinceDal icpd=new ItemCategoryProvinceDal();
		List<ItemCategoryProvince> ll=icpd.getItemCategoryByProvince("ɽ��");
		for(ItemCategoryProvince p:ll) {
			System.out.println(p.getId()+"\t"+p.getItemCategory()+"\t"+p.getProvince()+"\t"+p.getAmount());
		}
	}

}
