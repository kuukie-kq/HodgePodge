package com.bigdatacase.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bigdatacase.dal.ItemCategoryProvinceDal;
import com.bigdatacase.po.ItemCategoryProvince;

@Controller
@RequestMapping(value="/bigdatacontroller")
public class SpringMVCController {
	@RequestMapping("/controllertest.action")
	public ModelAndView controllertest(@RequestParam(value="itemCategory")String category) {
		ModelAndView mav = new ModelAndView("index");
		ItemCategoryProvinceDal icpd = new ItemCategoryProvinceDal();
		//List<TtemCategoryProvince> ll=icpd.getItemByCategory(Integer.parseInt(category));
		List<ItemCategoryProvince> icpl=icpd.getProvinceAsMybatis(Integer.parseInt(category));
		//��ģ�Ͷ�������������
		mav.addObject("ICPL",icpl);
		//�����߼���ͼ��
		mav.setViewName("index");
		//����ModelAndView����
		return mav;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
