package com.bigdatacase.po;

public class UserAccessCount {
	private String accessDate;
	private int accessCount;
	/**
	 * @return the accessDate
	 */
	public String getAccessDate() {
		return accessDate;
	}

	/**
	 * @param accessDate the accessDate to set
	 */
	public void setAccessDate(String accessDate) {
		this.accessDate = accessDate;
	}

	/**
	 * @return the accessCount
	 */
	public int getAccessCount() {
		return accessCount;
	}

	/**
	 * @param accessCount the accessCount to set
	 */
	public void setAccessCount(int accessCount) {
		this.accessCount = accessCount;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
