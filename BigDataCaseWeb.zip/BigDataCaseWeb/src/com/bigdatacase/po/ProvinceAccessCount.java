package com.bigdatacase.po;

public class ProvinceAccessCount {
	private String province;
	private int novemberCount;
	private int decemberCount;

	/**
	 * @return the province
	 */
	public String getProvince() {
		return province;
	}


	/**
	 * @param province the province to set
	 */
	public void setProvince(String province) {
		this.province = province;
	}


	/**
	 * @return the novemberCount
	 */
	public int getNovemberCount() {
		return novemberCount;
	}


	/**
	 * @param novemberCount the novemberCount to set
	 */
	public void setNovemberCount(int novemberCount) {
		this.novemberCount = novemberCount;
	}


	/**
	 * @return the decemberCount
	 */
	public int getDecemberCount() {
		return decemberCount;
	}


	/**
	 * @param decemberCount the decemberCount to set
	 */
	public void setDecemberCount(int decemberCount) {
		this.decemberCount = decemberCount;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
