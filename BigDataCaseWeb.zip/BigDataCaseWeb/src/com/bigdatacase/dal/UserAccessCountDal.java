package com.bigdatacase.dal;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bigdatacase.po.UserAccessCount;
import com.bigdatacase.util.MySQLAPI;

public class UserAccessCountDal {
	public List<UserAccessCount> getCountByDate(String date) {
		List<UserAccessCount> uacl=new ArrayList<UserAccessCount>();
		String sql="SELECT visit_date,COUNT(*) from user_action WHERE visit_date>'"+date+"-1' AND visit_date<'"+date+"-31' GROUP BY visit_date ORDER BY visit_date";
		try {
			MySQLAPI.mysqlInit();
			MySQLAPI.mysqlSelect(sql);
			ResultSet rs=MySQLAPI.getRs();
			while(rs.next()) {
				UserAccessCount u=new UserAccessCount();
				u.setAccessDate(rs.getString(1));
				u.setAccessCount(rs.getInt(2));
				uacl.add(u);
			}
			MySQLAPI.mysqlClose();
			return uacl;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
