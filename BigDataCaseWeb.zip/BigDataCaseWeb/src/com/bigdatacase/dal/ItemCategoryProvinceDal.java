package com.bigdatacase.dal;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.bigdatacase.po.ItemCategoryProvince;
import com.bigdatacase.util.MySQLAPI;
import com.bigdatacase.util.MybatisUtils;

public class ItemCategoryProvinceDal {
	public List<ItemCategoryProvince> getItemCategoryByProvince(String province) {
		List<ItemCategoryProvince> icpl=new ArrayList<ItemCategoryProvince>();
		String sql="select * from Item_Category_Province where province='"+province+"'";
		try {
			MySQLAPI.mysqlInit();
			MySQLAPI.mysqlSelect(sql);
			ResultSet rs=MySQLAPI.getRs();
			while(rs.next()) {
				ItemCategoryProvince p=new ItemCategoryProvince();
				p.setId(rs.getInt(1));
				p.setItemCategory(rs.getString(2));
				p.setProvince(rs.getString(3));
				p.setAmount(rs.getInt(4));
				icpl.add(p);
			}
			MySQLAPI.mysqlClose();
			return icpl;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public List<ItemCategoryProvince> getProvinceByItemCategory(int itemCategory) {
		List<ItemCategoryProvince> icpl=new ArrayList<ItemCategoryProvince>();
		String sql="select * from Item_Category_Province where item_category="+itemCategory;
		try {
			MySQLAPI.mysqlInit();
			MySQLAPI.mysqlSelect(sql);
			ResultSet rs=MySQLAPI.getRs();
			while(rs.next()) {
				ItemCategoryProvince p=new ItemCategoryProvince();
				p.setId(rs.getInt(1));
				p.setItemCategory(rs.getString(2));
				p.setProvince(rs.getString(3));
				p.setAmount(rs.getInt(4));
				icpl.add(p);
			}
			MySQLAPI.mysqlClose();
			return icpl;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public List<ItemCategoryProvince> getProvinceAsMybatis(int itemCategory) {
		SqlSession session=MybatisUtils.getSession();
		List<ItemCategoryProvince> ll=session.selectList("com.bigdatacase.mapper.itemCategory.getItemByCategory", itemCategory);
		return ll;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
}
