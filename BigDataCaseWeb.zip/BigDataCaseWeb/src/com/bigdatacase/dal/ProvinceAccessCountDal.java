package com.bigdatacase.dal;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bigdatacase.po.ProvinceAccessCount;
import com.bigdatacase.util.MySQLAPI;

public class ProvinceAccessCountDal {
	public List<ProvinceAccessCount> getCountByDateOrderProvince() {
		List<ProvinceAccessCount> pacl=new ArrayList<ProvinceAccessCount>();
		String sql="SELECT b.province,b.november,c.december FROM (SELECT province,SUM(amount) AS november FROM (SELECT province,visit_date,COUNT(*) AS amount FROM `user_action` WHERE visit_date<'2014-12-01' GROUP BY province,visit_date ORDER BY province) a GROUP BY province) b , (SELECT province,SUM(amount) AS december FROM (SELECT province,visit_date,COUNT(*) AS amount FROM `user_action` WHERE visit_date>='2014-12-01' GROUP BY province,visit_date ORDER BY province) a GROUP BY province) c WHERE b.province=c.province";
		try {
			MySQLAPI.mysqlInit();
			MySQLAPI.mysqlSelect(sql);
			ResultSet rs=MySQLAPI.getRs();
			while(rs.next()) {
				ProvinceAccessCount p=new ProvinceAccessCount();
				p.setProvince(rs.getString(1));
				p.setNovemberCount(rs.getInt(2));
				p.setDecemberCount(rs.getInt(3));
				pacl.add(p);
			}
			MySQLAPI.mysqlClose();
			return pacl;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<ProvinceAccessCount> getCountByDate(String day) {
		List<ProvinceAccessCount> pacl=new ArrayList<ProvinceAccessCount>();
		String sql="SELECT b.province,b.november,c.december FROM (SELECT province,SUM(amount) AS november FROM (SELECT province,visit_date,COUNT(*) AS amount FROM `user_action` WHERE visit_date<'2014-12-01' GROUP BY province,visit_date ORDER BY province) a GROUP BY province) b , (SELECT province,SUM(amount) AS december FROM (SELECT province,visit_date,COUNT(*) AS amount FROM `user_action` WHERE visit_date>='2014-12-01' GROUP BY province,visit_date ORDER BY province) a GROUP BY province) c WHERE b.province=c.province";
		try {
			MySQLAPI.mysqlInit();
			MySQLAPI.mysqlSelect(sql);
			ResultSet rs=MySQLAPI.getRs();
			while(rs.next()) {
				ProvinceAccessCount p=new ProvinceAccessCount();
				p.setProvince(rs.getString(1));
				p.setNovemberCount(rs.getInt(2));
				p.setDecemberCount(rs.getInt(3));
				pacl.add(p);
			}
			MySQLAPI.mysqlClose();
			return pacl;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
