/**
 * 
 */
layui.define('request',function(exports){
	var request=layui.request;
	var module={
		itemCategoryTypeAddSave(itemCategoryData){
			return request.post({
				url:'',
				data:itemCategoryData
			})
		},
		//根据学生ID获得学员信息
		getItemCategoryById(){
			return request.get({
				url:''
			})
		},
		//学生编辑提交
		itemCategoryEditSave(itemCategoryData){
			return request.put({
				url:'',
				data:itemCategoryData
			})
		},
		//学员删除提交
		itemCategoryDeleteSave(){
			return request.delete({
				url:''
			})
		}
	}
	exports('itemCategory',module)
});