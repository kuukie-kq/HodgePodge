#include <iostream>
#include <json.h>

int main() {
    std::cout << "Hello, World!" << std::endl;
    #if ENVIRONMENT < 1
    std::cout << "Hello World お帰りなさい" << std::endl;
    #else
    system("chcp 65001");
    #endif
    test_system_json_run();
    return 0;
}
