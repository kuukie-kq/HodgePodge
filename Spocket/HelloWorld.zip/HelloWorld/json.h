#ifndef KO_KO_JSON_H
#define KO_KO_JSON_H
// ====  ====
#include "system.h"
// ====  ====
namespace sys {
    enum {
        QUEUE_KO = 23u,
        STACK_KO = 24u,
        INT_KO = 21601,
        STRING_KO = 21609,
        MAP_NODE_KO = 21610,
        MAP_KO = 21611,
        ARRAY_NODE_KO = 21612,
        ARRAY_KO = 21613,
    };

    Object *new_default_instance(u4int type);

    int analysis(const std::string &json_string, void* json_object);

    class LinkedNode { //NOLINT
    private:
        friend class Stack;

        friend class Queue;

        friend class Map;

        friend int analysis(const std::string &json_string, void* json_object);

        Object *value;
        LinkedNode *next;
    public:
        explicit LinkedNode(Object *value = new Object()) : value(value) { next = nullptr; }

        ~LinkedNode() {
            delete next;
            delete value;
        }
    };

    class Stack : public Object {
    private:
        friend int analysis(const std::string &json_string, void* json_object);

        LinkedNode *head;
        u4int type;
    public:
        explicit Stack(u4int type = OBJECT_KO) : type(type) { head = nullptr; }

        ~Stack() override { delete head; }

        s4int s_insert(Object *value) {
            auto *node = new LinkedNode(value);
            node->next = head;
            head = node;
            return 1;
        }

        Object *s_delete() {
            if (head == nullptr) { return nullptr; }
            LinkedNode *node = head;
            head = node->next;
            node->next = nullptr;
            auto *v = node->value;
            auto *r = new_default_instance(type);
            v->clone(reinterpret_cast<Hickey *&>(r));
            delete node;
            return r;
        }

        u4int sign() const override { return STACK_KO; }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            auto *h = head;
            for (int i = 0; h != nullptr; i++) {
                if (i != 0) { out->append(","); }
                h->value->serialize(out);
                h = h->next;
            }
            return 1;
        }
    };

    class Queue : public Object {
    private:
        friend class Map;
        friend class Array;
        LinkedNode *head;
        u4int type;
    public:
        explicit Queue(u4int type = OBJECT_KO) : type(type) { head = nullptr; }

        ~Queue() override { delete head; }

        s4int q_insert(Object *value) {
            if (head == nullptr) {
                head = new LinkedNode(value);
                return 1;
            }
            LinkedNode *last = head;
            for (; last->next != nullptr; last = last->next) {}
            last->next = new LinkedNode(value);
            return 1;
        }

        Object *q_delete() {
            if (head == nullptr) { return nullptr; }
            LinkedNode *node = head;
            head = node->next;
            node->next = nullptr;
            auto *v = node->value;
            auto *r = new_default_instance(type);
            v->clone(reinterpret_cast<Hickey *&>(r));
            delete node;
            return r;
        }

        u4int sign() const override { return QUEUE_KO; }

        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign()) { return 0; }
            if (this == target) { return 0; }
            delete target;
            target = new Queue(type);
            for (LinkedNode *node = head; node != nullptr; node = node->next) {
                auto *v = new_default_instance(node->value->sign());
                node->value->clone(reinterpret_cast<Hickey *&>(v));
                ((Queue *) target)->q_insert(v);
            }
            return 1;
        }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            auto *h = head;
            for (int i = 0; h != nullptr; i++) {
                if (i != 0) { out->append(","); }
                h->value->serialize(out);
                h = h->next;
            }
            return 1;
        }
    };

    class Int : public Object {
    private:
        s4int i;
    public:
        explicit Int(int i = 0) : i(i) {}

        ~Int() override = default;

        u4int sign() const override { return INT_KO; }

        bool equals(const Hickey *const target) const override {
            return sign() == target->sign() ? i == ((Int *) target)->i : false;
        } //NOLINT
        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign()) { return 0; }
            if (this == target) { return 0; }
            delete target;
            target = new Int(i);
            return 1;
        }

        s4int hash() const override { return i; }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            out->append("%d", i);
            return 1;
        }
    };

    class String : public Object {
    private:
        std::string *s;
    public:
        explicit String(const char *c = "") { s = new std::string(c); }

        ~String() override { delete s; }

        u4int sign() const override { return STRING_KO; }

        bool equals(const Hickey *const target) const override {
            return sign() == target->sign() ? *s == *((String *) target)->s : false;
        } //NOLINT
        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign()) { return 0; }
            if (this == target) { return 0; }
            delete target;
            target = new String(s->c_str());
            return 1;
        }

        s4int hash() const override { return Util::u()->hash_code(s->c_str()); }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            out->append("\"%s\"", s->c_str());
            return 1;
        }
    };

    class KeyValueNode : public Object {
    private:
        friend class Map;

        Object *key;
        Object *value;
    public:
        explicit KeyValueNode(Object *key = new Object(), Object *value = new Object()) : key(key), value(value) {}

        ~KeyValueNode() override {
            delete value;
            delete key;
        }

        u4int sign() const override { return MAP_NODE_KO; }

        bool equals(const Hickey *const target) const override {
            return sign() == target->sign() ? key->equals(((KeyValueNode *) target)->key) &&
                                              value->equals(((KeyValueNode *) target)->value) : false;
        } //NOLINT
        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign()) { return 0; }
            if (this == target) { return 0; }
            delete target;
            auto *k = new_default_instance(key->sign());
            auto *v = new_default_instance(value->sign());
            key->clone(reinterpret_cast<Hickey *&>(k));
            value->clone(reinterpret_cast<Hickey *&>(v));
            target = new KeyValueNode(k, v);
            return 1;
        }

        s4int hash() const override { return key->hash(); }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            key->serialize(out);
            out->append(":");
            value->serialize(out);
            return 1;
        }
    };

    class Map : public Object {
    private:
        Queue *item;
        RedBlackTree *index;
    public:
        Map() {
            item = new Queue(MAP_NODE_KO);
            index = new RedBlackTree(INT_KO);
        }

        ~Map() override {
            delete index;
            delete item;
        }

        s4int m_insert(String *k, Object *v) {
            item->q_insert(new KeyValueNode(k, v));
            index->rbt_insert(new Int(k->hash()));
            return 1;
        }

        u4int sign() const override { return MAP_KO; }

        bool equals(const Hickey *const target) const override { return false; } //NOLINT
        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign() && target->sign() != OBJECT_KO) { return 0; }
            if (this == target) { return 0; }
            delete target;
            target = new Map();
            auto* t = new Queue(MAP_NODE_KO);
            item->clone(reinterpret_cast<Hickey*&>(t));
            for(LinkedNode* tn = t->head; tn != nullptr; tn = tn->next) {
                ((Map*)target)->insert(tn->value);
                tn->value = nullptr;
            }
            delete t;
            return 1;
        }

        s4int hash() const override { return 0; }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            out->append("{");
            item->serialize(out);
            out->append("}");
            return 1;
        }

        s4int insert(Object *add_item) {
            if (add_item->sign() != MAP_NODE_KO) { return 0; }
            item->q_insert(add_item);
            index->rbt_insert(new Int(((KeyValueNode*)add_item)->key->hash()));
            return 1;
        }
    };

    class ArrayNode : public Object {
    private:
        Object *key;
        Object *value;
    public:
        explicit ArrayNode(Object *key = new Object(), Object *value = new Object()) : key(key), value(value) {}

        ~ArrayNode() override {
            delete value;
            delete key;
        }

        u4int sign() const override { return ARRAY_NODE_KO; }

        bool equals(const Hickey *const target) const override {
            return sign() == target->sign() ? key->equals(((ArrayNode *) target)->key) &&
                                              value->equals(((ArrayNode *) target)->value) : false;
        } //NOLINT
        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign()) { return 0; }
            if (this == target) { return 0; }
            delete target;
            auto *k = new_default_instance(key->sign());
            auto *v = new_default_instance(value->sign());
            key->clone(reinterpret_cast<Hickey *&>(k));
            value->clone(reinterpret_cast<Hickey *&>(v));
            target = new ArrayNode(k, v);
            return 0;
        }

        s4int hash() const override { return key->hash(); }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            value->serialize(out);
            return 1;
        }
    };

    class Array : public Object {
    private:
        Queue *item;
    public:
        Array() { item = new Queue(ARRAY_NODE_KO); }

        ~Array() override { delete item; }

        s4int a_insert(ArrayNode *v) {
            item->q_insert(v);
            return 1;
        }

        u4int sign() const override { return ARRAY_KO; }

        bool equals(const Hickey *const target) const override { return false; } //NOLINT
        s4int clone(Hickey *&target) const override {
            if (target == nullptr) { return 0; }
            if (sign() != target->sign() && target->sign() != OBJECT_KO) { return 0; }
            if (this == target) { return 0; }
            delete target;
            target = new Array();
            item->clone(reinterpret_cast<Hickey *&>(((Array *) target)->item));
            return 1;
        }

        s4int hash() const override { return 0; }

        s4int serialize(Hickey *sys) const override {
            if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
            auto *out = (SystemStream *) sys;
            out->append("[");
            item->serialize(out);
            out->append("]");
            return 1;
        }

        s4int insert(Object *add_item) {
            //if (add_item->sign() == 0) { return 0; }
            a_insert(new ArrayNode(new Int(add_item->sign()), add_item));
            return 1;
        }
    };
}
// ====  ====
#if KO_KO_SRC_H
namespace sys {
    Object* new_default_instance(u4int type) {
        switch (type) {
            case INT_KO:
                return new Int();
            case STRING_KO:
                return new String();
            case MAP_NODE_KO:
                return new KeyValueNode();
            case ARRAY_NODE_KO:
                return new ArrayNode();
            default:
                return new Object();
        }
    }

    int analysis(const std::string &json_string, void* json_object) {
        if (json_object == nullptr || !(((Object*)json_object)->sign() == ARRAY_KO || ((Object*)json_object)->sign() == MAP_KO)) { return 0; }
        //
        std::string::const_iterator cit = json_string.begin();
#ifdef __linux__
        if ('{' == *cit) {
            delete (Map*)json_object;
            json_object = nullptr;
            json_object = new Map();
        } else if ('[' == *cit) {
            delete (Map*)json_object;
            json_object = nullptr;
            json_object = new Array();
        }
#endif
        int level = 0;
        auto* stack = new Stack(STRING_KO);
        String* top = nullptr;
        void* object = json_object;
        auto* stack_object = new Stack(OBJECT_KO);
        auto* stack_string = new Stack(STRING_KO);
        stack_object->s_insert(reinterpret_cast<Object*>(json_object));
        stack_string->s_insert(new String("main"));
        bool mode_string = false;
        bool key_or_value = true;
        Object* str_kv[2];
        str_kv[0] = nullptr;
        str_kv[1] = nullptr;
        int type = INT_KO;
        std::string str;
        str.clear();
        //
        for(;cit != json_string.end();) {
            if (mode_string) { if ('"' == *cit) { mode_string = false; type = STRING_KO; } else { str.push_back(*cit); } } else {
                if (' ' == *cit) {} else if ('"' == *cit) {
                    mode_string = true;
                } else if (':' == *cit) {
                    if (!(key_or_value && type == STRING_KO)) { return 0; }
                    str_kv[0] = new String(str.c_str());
                    key_or_value = false;
                    str.clear();
                    type = INT_KO;
                } else if ('.' == *cit) {
                    if (type != INT_KO) { return 0; }
                    type = INT_KO; //Code_K::DOUBLE;
                    str.push_back(*cit);
                } else if (',' == *cit) {
                    if (str.empty() && key_or_value) {
                        auto* tmp_object = new Object();
                        str_kv[0] = new String();
                        if (stack_object->head->value->hash() == MAP_KO) {
                            delete tmp_object;
                            tmp_object = new Map();
                        } else if (stack_object->head->value->hash() == ARRAY_KO) {
                            delete tmp_object;
                            tmp_object = new Array();
                        }
                        stack_string->head->value->clone(reinterpret_cast<Hickey*&>(str_kv[0]));
                        stack_object->head->value->clone(reinterpret_cast<Hickey*&>(tmp_object));
                        stack_object->s_delete();
                        stack_string->s_delete();
                        if (String("a*i*o").equals(str_kv[0])) {
                            ((Array*)object)->insert(tmp_object);
                            delete str_kv[0];
                        } else {
                            ((Map*)object)->insert(new KeyValueNode(str_kv[0], tmp_object));
                        }
                        tmp_object = nullptr;
                    } else {
                        switch (type) {
                            case STRING_KO:
                                str_kv[1] = new String(str.c_str());
                                break;
                            case INT_KO:
                                str_kv[1] = new Int(atoi(str.c_str())); //NOLINT
                                break;
                            default:
                                return 0;
                        }
                        if (key_or_value) {
                            ((Array*)object)->insert(str_kv[1]);
                        } else {
                            ((Map*)object)->insert(new KeyValueNode(str_kv[0], str_kv[1]));
                        }
                    }
                    key_or_value = true;
                    str.clear();
                    type = INT_KO;
                    str_kv[0] = nullptr;
                    str_kv[1] = nullptr;
                } else if ('{' == *cit) {
                    level = level + 1;
                    if (level != 1 && !key_or_value) {
                        str.clear();
                        auto* lok = new Map();
                        stack_object->s_insert(lok);
                        object = lok;
                        stack_string->s_insert(str_kv[0]);
                        str_kv[0] = nullptr;
                        str_kv[1] = nullptr;
                        key_or_value = true;
                    } else if (top != nullptr && ((String*)stack->head->value)->equals(top)) {
                        //
                        str.clear();
                        auto* lok = new Map();
                        stack_object->s_insert(lok);
                        object = lok;
                        stack_string->s_insert(new String("a*i*o"));
                        str_kv[0] = nullptr;
                        str_kv[1] = nullptr;
                        key_or_value = true;
                    }
                    std::string s = std::to_string(level);
                    s.append("<{>");
                    stack->s_insert(new String(s.c_str()));
                    top = (String*)stack->head->value;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                } else if ('}' == *cit) {
                    std::string s = std::to_string(level);
                    s.append("<{>");
                    if (str.empty() && key_or_value) {
                        auto* tmp_object = new Object();
                        str_kv[0] = new String();
                        stack_string->head->value->clone(reinterpret_cast<Hickey*&>(str_kv[0]));
                        stack_object->head->value->clone(reinterpret_cast<Hickey*&>(tmp_object));
                        stack_object->s_delete();
                        stack_string->s_delete();
                        ((Map*)object)->insert(new KeyValueNode(str_kv[0],tmp_object));
                    } else {
                        switch (type) {
                            case STRING_KO:
                                str_kv[1] = new String(str.c_str());
                                break;
                            case INT_KO:
                                str_kv[1] = new Int(atoi(str.c_str())); //NOLINT
                                break;
                            default:
                                return 0;
                        }
                        if (key_or_value) {
                            ((Array*)object)->insert(str_kv[1]);
                        } else {
                            ((Map*)object)->insert(new KeyValueNode(str_kv[0], str_kv[1]));
                        }
                    }
                    key_or_value = true;
                    str.clear();
                    type = INT_KO;
                    str_kv[0] = nullptr;
                    str_kv[1] = nullptr;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                    level = level - 1;
                    stack->s_delete();
                    if (level != 0) { top = (String*)stack->head->value; }
                    if (level == 0) { if ((cit + 1) != json_string.end()) { return 0; } } else {
                        auto* ito = stack_object->head->next->value;
                        //if(ito->sign() != MAP_KO) { return 0; }
                        object = ito;
                    }
                } else if ('[' == *cit) {
                    level = level + 1;
                    if (level != 1 && !key_or_value) {
                        str.clear();
                        auto* lok = new Array();
                        stack_object->s_insert(lok);
                        object = lok;
                        stack_string->s_insert(str_kv[0]);
                        str_kv[0] = nullptr;
                        str_kv[1] = nullptr;
                        key_or_value = true;
                    }
                    std::string s = std::to_string(level);
                    s.append("<[>");
                    stack->s_insert(new String(s.c_str()));
                    top = (String*)stack->head->value;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                } else if (']' == *cit) {
                    std::string s = std::to_string(level);
                    s.append("<[>");
                    if (str.empty() && key_or_value) {
                        auto* tmp_object = new Object();
                        str_kv[0] = new String();
                        stack_string->head->value->clone(reinterpret_cast<Hickey*&>(str_kv[0]));
                        stack_object->head->value->clone(reinterpret_cast<Hickey*&>(tmp_object));
                        stack_object->s_delete();
                        stack_string->s_delete();
                        ((Array*)object)->insert(tmp_object);
                        delete str_kv[0];
                    } else {
                        switch (type) {
                            case STRING_KO:
                                str_kv[1] = new String(str.c_str());
                                break;
                            case INT_KO:
                                str_kv[1] = new Int(atoi(str.c_str())); //NOLINT
                                break;
                            default:
                                return 0;
                        }
                        if (key_or_value) {
                            ((Array*)object)->insert(str_kv[1]);
                        } else {
                            ((Map*)object)->insert(new KeyValueNode(str_kv[0], str_kv[1]));
                        }
                    }
                    key_or_value = true;
                    str.clear();
                    type = INT_KO;
                    str_kv[0] = nullptr;
                    str_kv[1] = nullptr;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                    level = level - 1;
                    stack->s_delete();
                    if (level != 0) { top = (String*)stack->head->value; }
                    if (level == 0) { if ((cit + 1) != json_string.end()) { return 0; } } else {
                        auto* ito = stack_object->head->next->value;
                        //if(ito->sign() != ARRAY_KO) { return 0; }
                        object = ito;
                    }
                } else {
                    str.push_back(*cit);
                }
            }
            cit++;
        }
        //
        delete stack;
        top = nullptr;
        object = nullptr;
        str_kv[0] = nullptr;
        str_kv[1] = nullptr;
        stack_object = nullptr;
        stack_string = nullptr;
        return 1;
    }
}
#if KO_KO_TEST_H
int test_system_json_run() {
    {
        auto *map = new sys::Map();
        map->m_insert(new sys::String("id"), new sys::Int(1));
        map->m_insert(new sys::String("name"), new sys::String("alice"));
        auto *mate = new sys::Map();
        mate->m_insert(new sys::String("number"), new sys::Int(2));
        auto *array = new sys::Array();
        auto *ma1 = new sys::Map();
        ma1->m_insert(new sys::String("id"), new sys::Int(2));
        ma1->m_insert(new sys::String("name"), new sys::String("one"));
        array->insert(ma1);
        auto *ma2 = new sys::Map();
        ma2->m_insert(new sys::String("id"), new sys::Int(3));
        ma2->m_insert(new sys::String("name"), new sys::String("two"));
        ma2->m_insert(new sys::String("message"), new sys::String("hello"));
        array->insert(ma2);
        mate->insert(new sys::KeyValueNode(new sys::String("array"), array));
        map->m_insert(new sys::String("mate"), mate);
        auto *out = new sys::SystemStream(1u, 1u);
        map->serialize(out);
        out->end();
        delete out;
        delete map;
    }
    {
        auto* out = new sys::SystemStream(1u,1u);
        auto* json = new sys::Map();

        //sys::analysis("{\"id\":1,\"name\":\"alice\",\"message\":{\"result\":1,\"error\":{\"code\":1001}}}",json); //NOLINT
        //sys::analysis("{\"number\":3,\"name\":[\"alice\",\"mate\",\"array\"],\"result\":0}",json); //NOLINT
        sys::analysis("{\"id\":1,\"name\":\"alice\",\"mate\":{\"number\":2,\"array\":[{\"id\":2,\"name\":\"one\"},{\"id\":3,\"name\":\"two\",\"message\":\"hello\"}]}}",json); //NOLINT

        //auto* json_shadow = (sys::Array*)json;
        json->serialize(out);
        out->end();
        delete json;
        delete out;
    }
    return 1;
}
#endif

#endif
// ====  ====
#endif //KO_KO_JSON_H
