#include <iostream>
#include "json.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    test_system_json_run();
    return 0;
}
