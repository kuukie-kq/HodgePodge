#ifndef KO_KO_SYSTEM_H
#define KO_KO_SYSTEM_H
// ====  ====
#include "configuration.h"
// ====  ====
#include <iostream>
#include <sstream>
#include <cstdarg>
#include <chrono>
#include <string>
#include <vector>
#include <fstream>
// ====  ====
namespace sys {
    typedef unsigned char u1int; //NOLINT
    typedef char s1int; //NOLINT
    typedef unsigned short u2int; //NOLINT
    typedef short s2int; //NOLINT
    typedef unsigned int u4int; //NOLINT
    typedef int s4int; //NOLINT
    typedef unsigned long long u8int; //NOLINT
    typedef long long s8int; //NOLINT

    enum {
        SYSTEM_STREAM_KO = 12u,
        RED_BLACK_TREE_KO = 21u,
        OBJECT_KO = 3260681415u
    };

    class Hickey {
    private:
        Hickey& operator=(Hickey&);
        Hickey(Hickey&);
        Hickey& operator=(Hickey&&) noexcept;
        Hickey(Hickey&&) noexcept;
    protected:
        Hickey();
    public:
        virtual ~Hickey();
        virtual u4int sign() const;
        virtual bool equals(const Hickey* const target) const; //NOLINT
        virtual s4int clone(Hickey*& target) const;
        virtual s4int hash() const;
        virtual s4int serialize(Hickey* sys) const;
    };

    class TimeStamp {
    private:
        std::chrono::nanoseconds start_stamp = std::chrono::nanoseconds::zero();
    public:
        TimeStamp();
        ~TimeStamp();
        u8int time_line_passed();
        u8int time_start();
        static u8int time_now();
    };

    class Util final {
    private:
        Util();
        ~Util();
        const s4int k_ten = 1000;
        const s4int m_ten = 1000000;
        const s4int g_ten = 1000000000;
        const s4int ms_time = 60;
        const s4int hs_time = 3600;
        const s4int dh_time = 24;
        const s4int utc_e8 = 8;
        static Util* util;
    public:
        static Util* u();
        inline u4int hash_code(const char* key) const;
        inline std::vector<std::string> spilt(std::string str, const std::string& pattern) const;
        inline u4int time_nano(u8int stamp);
        inline u4int time_milli(u8int stamp);
        inline u4int time_micro(u8int stamp);
        inline u4int time_second(u8int stamp);
        inline u4int time_minute(u8int stamp);
        inline u4int time_hour(u8int stamp);
    };

    class SystemStream : public Hickey {
    protected:
        const s4int max_length = 1024;
        const s4int buffer_size = 1048575;
        std::stringstream* stream;
        std::stringstream* buffer;
        u4int on_or_off;
        u4int level;
        void upgrade(std::stringstream *sys, const char *format, ...) const;
        TimeStamp* timer;
        virtual void step() const;
        virtual void log() const;
        virtual void warning() const;
        virtual void error() const;
    public:
        explicit SystemStream(u4int ooo = 1u, u4int mode = 0);
        ~SystemStream() override;
        void clear();
        void start(u4int mode);
        void maybe(u4int mode);
        void append(const char *format, ...) const;
        void end();
        u4int sign() const override;
        bool equals(const Hickey *const target) const override; //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override;
        s4int serialize(Hickey *sys) const override;
    };

    class Object : public Hickey {
    public:
        Object();
        ~Object() override;
        u4int sign() const override;
        bool equals(const Hickey *const target) const override; //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override;
        s4int serialize(Hickey *sys) const override;
    };

    enum RedBlackColor { RED = 0, BLACK = 1 };

    class RedBlackNode final {
    private:
        friend class RedBlackTree;
        Object* value;
        RedBlackColor color;
        RedBlackNode* left;
        RedBlackNode* right;
        void* parent;
    public:
        explicit RedBlackNode(Object* value = new Object());
        ~RedBlackNode();
    };

    class RedBlackTree : public Hickey {
    private:
        void left_rotate(RedBlackNode* pivot);
        void right_rotate(RedBlackNode* pivot);
        RedBlackNode* parent_node(RedBlackNode* child) const;
        void fix_after_append(RedBlackNode* check);
        RedBlackNode* found(int value);
        RedBlackNode* successor(RedBlackNode* check) const;
        void fix_after_subtract(RedBlackNode* check);
        inline void pre_order(u4int index, const u4int offset, RedBlackNode* node, const u4int level, SystemStream* out) const; //NOLINT
        RedBlackNode* root;
        u4int type;
    public:
        explicit RedBlackTree(u4int type = OBJECT_KO);
        ~RedBlackTree() override;
        s4int rbt_insert(Object* value);
        s4int rbt_delete(s4int hash_value);
        Object* rbt_find(s4int hash_value);
        u4int sign() const override;
        s4int serialize(Hickey *sys) const override;
    };

}
// ====  ====
#if KO_KO_SRC_H
namespace sys {
    Hickey& Hickey::operator=(Hickey&) = default;

    Hickey::Hickey(Hickey&) = default;

    Hickey& Hickey::operator=(Hickey&&) noexcept = default;

    Hickey::Hickey(Hickey&&) noexcept = default;

    Hickey::Hickey() = default;

    Hickey::~Hickey() = default;

    u4int Hickey::sign() const {
        return 0;
    }

    bool Hickey::equals(const Hickey* const target) const {
        if (sign() == 0) { return false; }
        if (sign() != target->sign()) { return false; }
        return this == target;
    }

    s4int Hickey::clone(Hickey*& target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        return 0;
    }

    s4int Hickey::hash() const {
        return 0;
    }

    s4int Hickey::serialize(Hickey* sys) const {
        return 0;
    }

    // ====  ====

    TimeStamp::TimeStamp() {
        start_stamp = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch());
    }

    TimeStamp::~TimeStamp() {
        start_stamp = std::chrono::nanoseconds::zero();
    }

    u8int TimeStamp::time_line_passed() {
        std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch());
        u8int passed = now.count() - start_stamp.count();
        if (passed > 0) { return (passed); }
        return 0;
    }

    u8int TimeStamp::time_start() {
        return start_stamp.count();
    }

    u8int TimeStamp::time_now() {
        std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch());
        u8int passed = now.count();
        return passed;
    }

    // ====  ====

    Util::Util() = default;

    Util::~Util() { delete util; }

    Util* Util::u() { return util; }

    u4int Util::hash_code(const char* const key) const { //NOLINT
        u4int result;
        u1int* byte;
        for (result = 0, byte = (u1int*) key; *byte; byte++) {
            result = result * 31 + *byte;
        }
        return result;
    }

    std::vector<std::string> Util::spilt(std::string str, const std::string &pattern) const { //NOLINT
        std::string::size_type pos;
        std::vector<std::string> result;
        str += pattern;
        unsigned int size = str.size();
        for (unsigned int i = 0; i < size; i++) {
            pos = str.find(pattern, i);
            if (pos < size) {
                std::string s = str.substr(i, pos - i);
                result.push_back(s);
                i = pos + pattern.size() - 1;
            }
        }
        return result;
    }

    u4int Util::time_nano(u8int stamp) { //NOLINT
        return stamp % k_ten;
    }

    u4int Util::time_milli(u8int stamp) { //NOLINT
        return stamp / k_ten % k_ten;
    }

    u4int Util::time_micro(u8int stamp) { //NOLINT
        return stamp / m_ten % k_ten;
    }

    u4int Util::time_second(u8int stamp) { //NOLINT
        return stamp / g_ten % ms_time;
    }

    u4int Util::time_minute(u8int stamp) { //NOLINT
        return stamp / g_ten / ms_time % ms_time;
    }

    u4int Util::time_hour(u8int stamp) { //NOLINT
        return ((stamp / g_ten / hs_time % dh_time) + utc_e8) % dh_time;
    }

    Util* Util::util = new Util(); //NOLINT

    // ====  ====

    void SystemStream::upgrade(std::stringstream *sys, const char *format, ...) const {
        if (level & on_or_off) {
            char *buff = (char *) malloc(max_length);
            va_list args;
            va_start(args, format);
            int length = vsnprintf(buff, max_length, format, args);
            (length >= max_length) ? *sys << length << "- format and args too long" : *sys << buff;
            va_end(args);
            delete buff;
        }
    }

    void SystemStream::step() const {
        if (buffer->rdbuf()->in_avail() > buffer_size) {
            std::cout << buffer->str();
            buffer->clear();
            buffer->str("");
        }
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, "<- [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] <\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
    }

    void SystemStream::log() const {
        if (buffer->rdbuf()->in_avail() > 0) {
            std::cout << buffer->str();
            buffer->clear();
            buffer->str("");
        }
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, "<* [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] >\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
        std::cout << buffer->str();
        buffer->clear();
        buffer->str("");
    }

    void SystemStream::warning() const {
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, ">- [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] <\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
        std::cout << buffer->str();
        buffer->clear();
        buffer->str("");
    }

    void SystemStream::error() const {
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, ">* [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] <\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
        std::cerr << buffer->str();
        buffer->clear();
        buffer->str("");
    }

    SystemStream::SystemStream(u4int ooo, u4int mode) : on_or_off(ooo), level(mode) {
        stream = new std::stringstream();
        buffer = new std::stringstream();
        timer = new TimeStamp();
    }

    SystemStream::~SystemStream() {
        delete timer;
        delete buffer;
        delete stream;
    }

    void SystemStream::clear() {
        stream->clear();
        stream->str("");
        level = 0;
    }

    void SystemStream::start(u4int mode) {
        if (stream->rdbuf()->in_avail() > 0) { clear(); }
        level = mode;
    }

    void SystemStream::maybe(u4int mode) {
        level = mode;
    }

    void SystemStream::append(const char *format, ...) const {
        if (level & on_or_off) {
            char *buff = (char *) malloc(max_length);
            va_list args;
            va_start(args, format);
            int length = vsnprintf(buff, max_length, format, args);
            (length >= max_length) ? *stream << length << "- format and args too long" : *stream << buff;
            va_end(args);
            delete buff;
        }
    }

    void SystemStream::end() {
        if (level == 0) return;
        bool error_on = (level & 1u) & (on_or_off & 1u);
        bool warning_on = (level & 2u) & (on_or_off & 2u);
        bool log_on = (level & 4u) & (on_or_off & 4u);
        bool step_on = (level & 8u) & (on_or_off & 8u);
        if (error_on) {
            error();
        } else if (warning_on) {
            warning();
        } else if (log_on) {
            log();
        } else if (step_on) {
            step();
        }
        clear();
    }

    u4int SystemStream::sign() const {
        return SYSTEM_STREAM_KO;
    }

    bool SystemStream::equals(const Hickey *const target) const {
        if (sign() == 0) { return false; }
        if (sign() != target->sign()) { return false; }
        return ((SystemStream*)target)->stream->str() == stream->str() && ((SystemStream*)target)->buffer->str() == buffer->str();
    }

    s4int SystemStream::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new SystemStream(on_or_off, level);
        *((SystemStream*)target)->stream << stream->str();
        *((SystemStream*)target)->buffer << buffer->str();
        return 0;
    }

    s4int SystemStream::hash() const {
        return static_cast<s4int>(timer->time_start());
    }

    s4int SystemStream::serialize(Hickey *sys) const {
        return 0;
    }

    // ====  ====

    Object::Object() = default;

    Object::~Object() = default;

    u4int Object::sign() const {
        return OBJECT_KO;
    }

    bool Object::equals(const Hickey* const target) const {
        if (sign() == 0) { return false; }
        if (sign() != target->sign()) { return false; }
        return this == target;
    }

    s4int Object::clone(Hickey*& target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        return 0;
    }

    s4int Object::hash() const {
        return 0;
    }

    s4int Object::serialize(Hickey* sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto* out = (SystemStream*)sys;
        out->append("ond");
        return 1;
    }

    // ====  ====

    RedBlackNode::RedBlackNode(Object *value) : value(value) {
        color = RedBlackColor::RED;
        left = nullptr;
        right = nullptr;
        parent = nullptr;
    }

    RedBlackNode::~RedBlackNode() {
        delete right;
        delete left;
        delete value;
    }

    // ====  ====

    void RedBlackTree::left_rotate(RedBlackNode *pivot) {
        RedBlackNode* right = pivot->right;
        pivot->right = right->left;
        if (right->left != nullptr) {
            right->left->parent = pivot;
        }
        right->parent = pivot->parent;
        if (pivot->parent == nullptr) {
            root = right;
        } else if (parent_node(pivot)->left == pivot) {
            parent_node(pivot)->left = right;
        } else {
            parent_node(pivot)->right = right;
        }
        right->left = pivot;
        pivot->parent = right;
    }

    void RedBlackTree::right_rotate(RedBlackNode *pivot) {
        RedBlackNode* left = pivot->left;
        pivot->left = left->right;
        if (left->right != nullptr) {
            left->right->parent = pivot;
        }
        left->parent = pivot->parent;
        if (pivot->parent == nullptr) {
            root = left;
        } else if (parent_node(pivot)->left == pivot) {
            parent_node(pivot)->left = left;
        } else {
            parent_node(pivot)->right = left;
        }
        left->right = pivot;
        pivot->parent = left;
    }

    RedBlackNode * RedBlackTree::parent_node(RedBlackNode *child) const { //NOLINT
        if(child == nullptr) { return nullptr; }
        return (RedBlackNode*)child->parent;
    }

    void RedBlackTree::fix_after_append(RedBlackNode *check) {
        for (; check != nullptr && root != check && parent_node(check)->color == RED;) {
            if (parent_node(check) == parent_node(parent_node(check))->left) {
                RedBlackNode* uncle = parent_node(parent_node(check))->right;
                if (uncle != nullptr && uncle->color == RED) {
                    uncle->color = BLACK;
                    parent_node(check)->color = BLACK;
                    check = parent_node(parent_node(check));
                    check->color = RED;
                } else {
                    if (check == parent_node(check)->right) {
                        check = parent_node(check);
                        left_rotate(check);
                    }
                    parent_node(check)->color = BLACK;
                    parent_node(parent_node(check))->color = RED;
                    right_rotate(parent_node(parent_node(check)));
                }
            } else {
                RedBlackNode* uncle = parent_node(parent_node(check))->left;
                if (uncle != nullptr && uncle->color == RED) {
                    uncle->color = BLACK;
                    parent_node(check)->color = BLACK;
                    check = parent_node(parent_node(check));
                    check->color = RED;
                } else {
                    if (check == parent_node(check)->left) {
                        check = parent_node(check);
                        right_rotate(check);
                    }
                    parent_node(check)->color = BLACK;
                    parent_node(parent_node(check))->color = RED;
                    left_rotate(parent_node(parent_node(check)));
                }
            }
        }
        root->color = BLACK;
    }

    RedBlackNode * RedBlackTree::found(int value) {
        RedBlackNode* current = root;
        for (; current != nullptr;) {
            if (current->value->hash() > value) {
                current = current->left;
            } else if (current->value->hash() < value) {
                current = current->right;
            } else {
                break;
            }
        }
        return current;
    }

    RedBlackNode * RedBlackTree::successor(RedBlackNode *check) const { //NOLINT
        RedBlackNode* most_left = check->right;
        for (; most_left != nullptr && most_left->left != nullptr;) {
            most_left = most_left->left;
        }
        return most_left;
    }

    void RedBlackTree::fix_after_subtract(RedBlackNode *check) {
        for (; check != root && BLACK == check->color;) {
            if (check == parent_node(check)->left) {
                RedBlackNode* sister = parent_node(check)->right;
                if (RED == sister->color) {
                    sister->color = BLACK;
                    parent_node(check)->color = RED;
                    left_rotate(parent_node(check));
                    sister = parent_node(check)->right;
                }
                if ((sister->left == nullptr || BLACK == sister->left->color) &&
                    (sister->right == nullptr || BLACK == sister->right->color)) {
                    sister->color = RED;
                    check = parent_node(check);
                } else {
                    if (sister->right == nullptr || BLACK == sister->right->color) {
                        sister->left->color = BLACK;
                        sister->color = RED;
                        right_rotate(sister);
                        sister = parent_node(check)->right;
                    }
                    sister->color = parent_node(check)->color;
                    parent_node(check)->color = BLACK;
                    if (sister->right != nullptr)
                        sister->right->color = BLACK;
                    left_rotate(parent_node(check));
                    check = root;
                }
            } else {
                RedBlackNode* sister = parent_node(check)->left;
                if (RED == sister->color) {
                    sister->color = BLACK;
                    parent_node(check)->color = RED;
                    right_rotate(parent_node(check));
                    sister = parent_node(check)->left;
                }
                if ((sister->left == nullptr || BLACK == sister->left->color) &&
                    (sister->right == nullptr || BLACK == sister->right->color)) {
                    sister->color = RED;
                    check = parent_node(check);
                } else {
                    if (sister->left == nullptr || BLACK == sister->left->color) {
                        sister->right->color = BLACK;
                        sister->color = RED;
                        left_rotate(sister);
                        sister = parent_node(check)->left;
                    }
                    sister->color = parent_node(check)->color;
                    if (sister->left != nullptr)
                        sister->left->color = BLACK;
                    parent_node(check)->color = BLACK;
                    right_rotate(parent_node(check));
                    check = root;
                }
            }
        }
        check->color = BLACK;
    }

    void RedBlackTree::pre_order(u4int index, const u4int offset, RedBlackNode *node, const u4int level, SystemStream *out) const {
        if (node == nullptr) { return; }
        index = index * 2 + offset;

        out->append("{\"array_index\":%4u,\"level\":%2u,\"color\":%s,\"value\":", index, level, node->color ? "black" : "r e d"); //NOLINT
        node->value->serialize(out);
        out->append("}\n");

        pre_order(index, 1, node->left, level + 1, out);
        pre_order(index, 2, node->right, level + 1, out);
    }

    RedBlackTree::RedBlackTree(u4int type) : type(type) {
        root = nullptr;
    }

    RedBlackTree::~RedBlackTree() { delete root; }

    s4int RedBlackTree::rbt_insert(Object *value) {
        if(value->sign() != type) { if (type == OBJECT_KO) { return -1; } return 0; }
        auto* new_node = new RedBlackNode(value);
        if (root == nullptr) {
            new_node->color = BLACK;
            root = new_node;
        }

        RedBlackNode* current = root;
        RedBlackNode* temp = current;
        for (; current != nullptr;) {
            temp = current;
            if (current->value->hash() > value->hash()) {
                current = current->left;
            } else if (current->value->hash() < value->hash()) {
                current = current->right;
            } else {
                return 0;
            }
        }

        if (temp->value->hash() > value->hash()) {
            temp->left = new_node;
        } else {
            temp->right = new_node;
        }
        new_node->parent = temp;
        fix_after_append(new_node);
        return 1;
    }

    s4int RedBlackTree::rbt_delete(s4int hash_value) {
        RedBlackNode* delete_node = found(hash_value);
        if (delete_node == nullptr) { return 0; }
        if (delete_node->left != nullptr && delete_node->right != nullptr) {
            RedBlackNode* temp = successor(delete_node);
            temp->value->clone(reinterpret_cast<Hickey*&>(delete_node->value));
            delete_node = temp;
        }
        RedBlackNode* replacement = delete_node->left == nullptr ? delete_node->right : delete_node->left;
        if (replacement == nullptr) {
            if (delete_node->parent == nullptr) {
                root = nullptr;
            } else {
                if (BLACK == delete_node->color) {
                    fix_after_subtract(delete_node);
                }
                if (delete_node == parent_node(delete_node)->left) {
                    parent_node(delete_node)->left = nullptr;
                } else {
                    parent_node(delete_node)->right = nullptr;
                }
                delete_node->parent = nullptr;
            }
        } else {
            replacement->color = BLACK;
            replacement->parent = parent_node(delete_node);
            if (delete_node->parent == nullptr) {
                root = replacement;
            } else if (delete_node == parent_node(delete_node)->left) {
                parent_node(delete_node)->left = replacement;
            } else {
                parent_node(delete_node)->right = replacement;
            }
            delete_node->parent = nullptr;
            delete_node->left = nullptr;
            delete_node->right = nullptr;
        }

        delete delete_node;
        return 1;
    }

    Object * RedBlackTree::rbt_find(s4int hash_value) {
        RedBlackNode* new_node = found(hash_value);
        if (new_node == nullptr) { return nullptr; }
        return new_node->value;
    }

    u4int RedBlackTree::sign() const {
        return RED_BLACK_TREE_KO;
    }

    s4int RedBlackTree::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto* out = (SystemStream*)sys;
        pre_order(0u,0u,root,1u,out);
        return 1;
    }
}
// ====  ====
#if KO_KO_TEST_H
#endif

#endif
// ====  ====
#endif //KO_KO_SYSTEM_H
