#include <iostream>
#include "music.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    run();
    return 0;
}
