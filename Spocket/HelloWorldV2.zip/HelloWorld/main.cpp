#include <iostream>
#include "music.h"

class A {
public:
    int a;
    A() : a(1) {}
    virtual ~A() = default;
    virtual int foo1() { return 1; }
};

class B : virtual public A {
public:
    B() = default;
    ~B() override = default;
    virtual int foo2() { return 10; }
    int foo1() override { return a + 10; }
};

class C : virtual public A {
public:
    C() = default;
    ~C() override = default;
    virtual int foo3() { return 11; }
    int foo1() override { return a + 11; }
};

class D : public B, public C {
public:
    int d;
    D() : d(100) {}
    ~D() override = default;
    int foo1() override { return a; }
    int foo2() override { return B::foo1(); }
    int foo3() override { return C::foo1(); }
};

#define OF(argument) argument

extern int test OF((int t));

int test (int t) {
    auto* tt = new D();
    tt->a = 35;
    tt->a = 64;
    tt->d = 13;
    int it = sizeof(D);

    it = tt->foo1();
    it = tt->foo2();
    it = tt->foo3();

    delete tt;

    return t;
}

int main() {
    std::cout << "Hello, World!" << std::endl;
    run();

    test(1);

    return 0;
}
