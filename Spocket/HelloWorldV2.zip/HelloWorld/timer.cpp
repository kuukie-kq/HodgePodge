#include "system.h"
#include "timer.h"
// ====  ====
#if not KO_KO_SRC_H
namespace tim {
    // ====  ====
    Timer::node::node()  : conduct(nullptr), sign(0u), time(0u), next(nullptr), front(nullptr) {}
    // ====  ====
    Timer::header::header() : longtime(0u), next(nullptr), sub(nullptr) {}
    // ====  ====
    void Timer::in_it() {
        loop = (header*)malloc(sizeof(header) * size);
        if (loop == nullptr) { return; }
        for (int i = 0; i < size; i++) {
            header* leader = loop + i;
            header* h = loop + ((i + 1) % size);
            leader->longtime = (kok::u8int)0u - 1;
            leader->next = h;
            leader->sub = nullptr;
        }
        time = kok::TimeStamp::time_now();
        current = loop;
    }

    void Timer::un_it() {
        current = nullptr;
        time = 0u;
        free(loop);
        loop = nullptr;
    }

    kok::s4int Timer::tick() {
        if (current == nullptr) { return 0; }
        kok::u8int now = kok::TimeStamp::time_now();
        if (current->longtime > now && current->longtime - now > threshold) { current = current->next; return 2; }
        for(node* n = current->sub; n != nullptr;) {
            if (n->time > now && n->time - now > threshold) { n = n->next; continue; }
            if (n->time > now) {
                n = n->next;
            } else {
                node* use = n;
                if (n->front == nullptr && n == current->sub) {
                    current->sub = use->next;
                    if (use->next != nullptr) {
                        current->sub->front = nullptr;
                        use->next = nullptr;
                    }
                    n = current->sub;
                } else {
                    use->front->next = use->next;
                    n = use->next;
                    if (use->next != nullptr) {
                        use->next->front = use->front;
                        use->next = nullptr;
                    }
                    use->front = nullptr;
                }
                if (use->front != nullptr || use->next != nullptr) {
                    continue;
                }
                use->conduct(use->sign);
                free(use);
            }
        }
        current = current->next;
        return 1;
    }

    kok::s4int Timer::bind(kok::u8int stamp, Dispose option, kok::u2int args) {
        kok::u4int index = (stamp / kok::Util::u()->g_ten) % size;
        header* leader = loop + index;
        auto* n = (node*)malloc(sizeof(node));
        if (n == nullptr) { return 0; }
        n->next = leader->sub;
        n->front = nullptr;
        n->sign = args;
        n->conduct = option;
        n->time = stamp;
        if (leader->sub != nullptr) { leader->sub->front = n; }
        leader->sub = n;
        if (leader->longtime > stamp) { leader->longtime = stamp; }
        return 1;
    }

    Timer::Timer() : size(12), threshold(5 * kok::Util::u()->g_ten), practice(2000 * kok::Util::u()->k_ten) {
        loop = nullptr;
        current = nullptr;
        time = 0u;
    }

    void Timer::start() {
        for(;;) {
            if (tick() == 0) { break; }
            #if ENVIRONMENT == 0
            nanosleep(practice);
            #endif
            std::this_thread::sleep_for(std::chrono::nanoseconds(practice));
        }
    }

    void Timer::later(kok::u4int length, const char c, Dispose option, kok::u2int args) {
        kok::u8int stamp = 0u;
        switch (c) {
            case 'n':
                stamp = length;
                break;
            case 'u':
                stamp = (kok::u8int)length * kok::Util::u()->k_ten;
                break;
            case 'm':
                stamp = (kok::u8int)length * kok::Util::u()->m_ten;
                break;
            case 's':
                stamp = (kok::u8int)length * kok::Util::u()->g_ten;
                break;
            case '6':
                stamp = (kok::u8int)length * kok::Util::u()->g_ten;
                stamp = stamp * kok::Util::u()->ms_time;
                break;
            case 'H':
                stamp = (kok::u8int)length * kok::Util::u()->g_ten;
                stamp = stamp * kok::Util::u()->hs_time;
                break;
            case 'D':
                stamp = (kok::u8int)length * kok::Util::u()->g_ten * kok::Util::u()->hs_time;
                stamp = stamp * kok::Util::u()->dh_time;
                break;
            case 'W':
            case 'M':
            case 'q':
            case 'h':
            case 'Y':
            default:
                stamp = (kok::u8int)length * kok::Util::u()->m_ten;
        }
        time = kok::TimeStamp::time_now();
        bind(stamp + time, option, args);
    }

    void Timer::moment(kok::u8int stamp, Dispose option, kok::u2int args) {
        time = kok::TimeStamp::time_now();
        if (stamp < time) {
            bind(time, option, args);
        } else {
            bind(stamp, option, args);
        }
    }
    // ====  ====
}
#if KO_KO_TEST_H
tim::Timer* tt = nullptr;

kok::s4int test_one(kok::u2int args) {
    auto* out = new kok::KO_CLASS_NAME(SystemStream)(1u, 1u);
    out->append(">%s<%d", __FUNCTION__, args);
    out->end();
    delete out;
    if (tt != nullptr) { tt->later(1, '6', test_one, 111); }
    if (tt != nullptr) { tt->later(1, '6', test_one, 111); }
    return 1;
}

kok::s4int test_three(kok::u2int args) {
    auto* out = new kok::KO_CLASS_NAME(SystemStream)(1u, 1u);
    out->append(">%s<%d", __FUNCTION__, args);
    out->end();
    delete out;
    if (tt != nullptr) { tt->later(20, 'm', test_three, 3); }
    return 1;
}

kok::s4int test_two(kok::u2int args) {
    auto* out = new kok::KO_CLASS_NAME(SystemStream)(1u, 1u);
    out->append(">%s<%d", __FUNCTION__, args);
    out->end();
    delete out;
    if (tt != nullptr) { tt->later(5, 's', test_one, 222); }
    if (tt != nullptr) { tt->later(20, 'm', test_three, 333); }
    return 1;
}

namespace tim {
    kok::s4int last(kok::u2int args) {
        auto *out = new kok::KO_CLASS_NAME(SystemStream)(1u, 1u);
        out->append(">%s<%d", __FUNCTION__, args);
        out->end();
        delete out;
        if (tt != nullptr) { tt->current->next = nullptr; }
        return 1;
    }
}

int test_timer_run() {
    tt = new tim::Timer();
    {
        tt->in_it();
        auto* t = new kok::KO_CLASS_NAME(SystemStream)(1u,1u);
        t->end();
        delete t;
        tt->later(10, 's', test_two, 2);
        tt->moment(1668671400000000000, tim::last, 10001);
        tt->start();
        tt->un_it();
    }
    delete tt;
    return 0;
}
#endif

#endif
