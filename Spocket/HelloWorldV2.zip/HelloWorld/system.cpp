#include "system.h"
// ====  ====
#if not KO_KO_SRC_H
namespace kok {
    // ====  ====
    TimeStamp::TimeStamp() {
        start_stamp = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch());
    }

    TimeStamp::~TimeStamp() {
        start_stamp = std::chrono::nanoseconds::zero();
    }

    u8int TimeStamp::time_line_passed() {
        std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch());
        u8int passed = now.count() - start_stamp.count();
        if (passed > 0) { return (passed); }
        return 0;
    }

    u8int TimeStamp::time_start() {
        return start_stamp.count();
    }

    u8int TimeStamp::time_now() {
        std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch());
        u8int passed = now.count();
        return passed;
    }

    // ====  ====

    Util::Util() = default;

    Util::~Util() { delete util; }

    Util* Util::u() { return util; }

    u4int Util::hash_code(const char* const key) const { //NOLINT
        u4int result;
        u1int* byte;
        for (result = 0, byte = (u1int*) key; *byte; byte++) {
            result = result * 31 + *byte;
        }
        return result;
    }

    std::vector<std::string> Util::spilt(std::string str, const std::string &pattern) const { //NOLINT
        std::string::size_type pos;
        std::vector<std::string> result;
        str += pattern;
        unsigned int size = str.size();
        for (unsigned int i = 0; i < size; i++) {
            pos = str.find(pattern, i);
            if (pos < size) {
                std::string s = str.substr(i, pos - i);
                result.push_back(s);
                i = pos + pattern.size() - 1;
            }
        }
        return result;
    }

    u4int Util::time_nano(u8int stamp) { //NOLINT
        return stamp % k_ten;
    }

    u4int Util::time_milli(u8int stamp) { //NOLINT
        return stamp / k_ten % k_ten;
    }

    u4int Util::time_micro(u8int stamp) { //NOLINT
        return stamp / m_ten % k_ten;
    }

    u4int Util::time_second(u8int stamp) { //NOLINT
        return stamp / g_ten % ms_time;
    }

    u4int Util::time_minute(u8int stamp) { //NOLINT
        return stamp / g_ten / ms_time % ms_time;
    }

    u4int Util::time_hour(u8int stamp) { //NOLINT
        return ((stamp / g_ten / hs_time % dh_time) + utc_e8) % dh_time;
    }

    Util* Util::util = new Util(); //NOLINT

    // ====  ====

    void KO_CLASS_NAME(SystemStream)::upgrade(std::stringstream *sys, const char *format, ...) const {
        if (level & on_or_off) {
            char *buff = (char *) malloc(max_length);
            va_list args;
            va_start(args, format);
            int length = vsnprintf(buff, max_length, format, args);
            (length >= max_length) ? *sys << length << "- format and args too long" : *sys << buff;
            va_end(args);
            free(buff);
        }
    }

    void KO_CLASS_NAME(SystemStream)::step() const {
        if (buffer->rdbuf()->in_avail() > buffer_size) {
            std::cout << buffer->str();
            buffer->clear();
            buffer->str("");
        }
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, "<- [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] <\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
    }

    void KO_CLASS_NAME(SystemStream)::log() const {
        if (buffer->rdbuf()->in_avail() > 0) {
            std::cout << buffer->str();
            buffer->clear();
            buffer->str("");
        }
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, "<* [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] >\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
        std::cout << buffer->str();
        buffer->clear();
        buffer->str("");
    }

    void KO_CLASS_NAME(SystemStream)::warning() const {
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, ">- [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] <\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
        std::cout << buffer->str();
        buffer->clear();
        buffer->str("");
    }

    void KO_CLASS_NAME(SystemStream)::error() const {
        u8int tmp = TimeStamp::time_now();
        upgrade(buffer, ">* [%02d:%02d:%02d %03dms%03dus%03dns]", Util::u()->time_hour(tmp), Util::u()->time_minute(tmp), Util::u()->time_second(tmp), Util::u()->time_micro(tmp), Util::u()->time_milli(tmp), Util::u()->time_nano(tmp));
        *buffer << stream->str();
        u8int stamp = timer->time_line_passed();
        upgrade(buffer,"[%d s %d ms %d us %d ns] <\n", stamp / 1000000000, Util::u()->time_micro(stamp), Util::u()->time_milli(stamp), Util::u()->time_nano(stamp));
        std::cerr << buffer->str();
        buffer->clear();
        buffer->str("");
    }

    KO_CLASS_NAME(SystemStream)::KO_CLASS_NAME(SystemStream)() {
        on_or_off = 1u;
        level = 0;
        stream = new std::stringstream();
        buffer = new std::stringstream();
        timer = new TimeStamp();
    }

    KO_CLASS_NAME(SystemStream)::KO_CLASS_NAME(SystemStream)(u4int ooo, u4int mode) : on_or_off(ooo), level(mode) {
        stream = new std::stringstream();
        buffer = new std::stringstream();
        timer = new TimeStamp();
    }

    KO_CLASS_NAME(SystemStream)::~KO_CLASS_NAME(SystemStream)() {
        delete timer;
        delete buffer;
        delete stream;
    }

    void KO_CLASS_NAME(SystemStream)::clear() {
        stream->clear();
        stream->str("");
        level = 0;
    }

    void KO_CLASS_NAME(SystemStream)::start(u4int mode) {
        if (stream->rdbuf()->in_avail() > 0) { clear(); }
        level = mode;
    }

    void KO_CLASS_NAME(SystemStream)::maybe(u4int mode) {
        level = mode;
    }

    void KO_CLASS_NAME(SystemStream)::append(const char *format, ...) const {
        if (level & on_or_off) {
            char *buff = (char *) malloc(max_length);
            va_list args;
            va_start(args, format);
            int length = vsnprintf(buff, max_length, format, args);
            (length >= max_length) ? *stream << length << "- format and args too long" : *stream << buff;
            va_end(args);
            free(buff);
        }
    }

    void KO_CLASS_NAME(SystemStream)::end() {
        if (level == 0) return;
        bool error_on = (level & 1u) & (on_or_off & 1u);
        bool warning_on = (level & 2u) & (on_or_off & 2u);
        bool log_on = (level & 4u) & (on_or_off & 4u);
        bool step_on = (level & 8u) & (on_or_off & 8u);
        if (error_on) {
            error();
        } else if (warning_on) {
            warning();
        } else if (log_on) {
            log();
        } else if (step_on) {
            step();
        }
        clear();
    }

    u4int KO_CLASS_NAME(SystemStream)::sign() const {
        return Util::SystemStream;
    }

    bool KO_CLASS_NAME(SystemStream)::equals(const KO_CLASS_NAME(Hickey) *const target) const {
        if (sign() == 0) { return false; }
        if (sign() != target->sign()) { return false; }
        return ((KO_CLASS_NAME(SystemStream)*)target)->stream->str() == stream->str() && ((KO_CLASS_NAME(SystemStream)*)target)->buffer->str() == buffer->str();
    }

    s4int KO_CLASS_NAME(SystemStream)::clone(KO_CLASS_NAME(Hickey) *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new KO_CLASS_NAME(SystemStream)(on_or_off, level);
        *((KO_CLASS_NAME(SystemStream)*)target)->stream << stream->str();
        *((KO_CLASS_NAME(SystemStream)*)target)->buffer << buffer->str();
        return 0;
    }

    s4int KO_CLASS_NAME(SystemStream)::hash() const {
        return static_cast<s4int>(timer->time_start());
    }

    s4int KO_CLASS_NAME(SystemStream)::serialize(KO_CLASS_NAME(Hickey) *sys) const {
        return 0;
    }

    // ====  ====

    KO_CLASS_NAME(Object)::KO_CLASS_NAME(Object)() = default;

    KO_CLASS_NAME(Object)::~KO_CLASS_NAME(Object)() = default;

    DEFAULT_OBJECT_SIGN(KO_CLASS_NAME(Object))

    DEFAULT_OBJECT_EQUALS(KO_CLASS_NAME(Object))

    DEFAULT_OBJECT_CLONE(KO_CLASS_NAME(Object))

    DEFAULT_OBJECT_HASH(KO_CLASS_NAME(Object))

    DEFAULT_OBJECT_SERIALIZE(KO_CLASS_NAME(Object))

    // ====  ====

    RedBlackNode::RedBlackNode(KO_CLASS_NAME(Object) *value) : value(value) {
        color = RED;
        left = nullptr;
        right = nullptr;
        parent = nullptr;
        delete_pointer = true;
    }

    RedBlackNode::~RedBlackNode() {
        delete right;
        delete left;
        if (delete_pointer) { delete value; }
    }

    // ====  ====

    void KO_CLASS_NAME(RedBlackTree)::left_rotate(RedBlackNode *pivot) {
        RedBlackNode* right = pivot->right;
        pivot->right = right->left;
        if (right->left != nullptr) {
            right->left->parent = pivot;
        }
        right->parent = pivot->parent;
        if (pivot->parent == nullptr) {
            root = right;
        } else if (parent_node(pivot)->left == pivot) {
            parent_node(pivot)->left = right;
        } else {
            parent_node(pivot)->right = right;
        }
        right->left = pivot;
        pivot->parent = right;
    }

    void KO_CLASS_NAME(RedBlackTree)::right_rotate(RedBlackNode *pivot) {
        RedBlackNode* left = pivot->left;
        pivot->left = left->right;
        if (left->right != nullptr) {
            left->right->parent = pivot;
        }
        left->parent = pivot->parent;
        if (pivot->parent == nullptr) {
            root = left;
        } else if (parent_node(pivot)->left == pivot) {
            parent_node(pivot)->left = left;
        } else {
            parent_node(pivot)->right = left;
        }
        left->right = pivot;
        pivot->parent = left;
    }

    RedBlackNode * KO_CLASS_NAME(RedBlackTree)::parent_node(RedBlackNode *child) const { //NOLINT
        if(child == nullptr) { return nullptr; }
        return (RedBlackNode*)child->parent;
    }

    void KO_CLASS_NAME(RedBlackTree)::fix_after_append(RedBlackNode *check) {
        for (; check != nullptr && root != check && parent_node(check)->color == RED;) {
            if (parent_node(check) == parent_node(parent_node(check))->left) {
                RedBlackNode* uncle = parent_node(parent_node(check))->right;
                if (uncle != nullptr && uncle->color == RED) {
                    uncle->color = BLACK;
                    parent_node(check)->color = BLACK;
                    check = parent_node(parent_node(check));
                    check->color = RED;
                } else {
                    if (check == parent_node(check)->right) {
                        check = parent_node(check);
                        left_rotate(check);
                    }
                    parent_node(check)->color = BLACK;
                    parent_node(parent_node(check))->color = RED;
                    right_rotate(parent_node(parent_node(check)));
                }
            } else {
                RedBlackNode* uncle = parent_node(parent_node(check))->left;
                if (uncle != nullptr && uncle->color == RED) {
                    uncle->color = BLACK;
                    parent_node(check)->color = BLACK;
                    check = parent_node(parent_node(check));
                    check->color = RED;
                } else {
                    if (check == parent_node(check)->left) {
                        check = parent_node(check);
                        right_rotate(check);
                    }
                    parent_node(check)->color = BLACK;
                    parent_node(parent_node(check))->color = RED;
                    left_rotate(parent_node(parent_node(check)));
                }
            }
        }
        root->color = BLACK;
    }

    RedBlackNode * KO_CLASS_NAME(RedBlackTree)::found(int value) {
        RedBlackNode* current = root;
        for (; current != nullptr;) {
            if (current->value->hash() > value) {
                current = current->left;
            } else if (current->value->hash() < value) {
                current = current->right;
            } else {
                break;
            }
        }
        return current;
    }

    RedBlackNode * KO_CLASS_NAME(RedBlackTree)::successor(RedBlackNode *check) const { //NOLINT
        RedBlackNode* most_left = check->right;
        for (; most_left != nullptr && most_left->left != nullptr;) {
            most_left = most_left->left;
        }
        return most_left;
    }

    void KO_CLASS_NAME(RedBlackTree)::fix_after_subtract(RedBlackNode *check) {
        for (; check != root && BLACK == check->color;) {
            if (check == parent_node(check)->left) {
                RedBlackNode* sister = parent_node(check)->right;
                if (RED == sister->color) {
                    sister->color = BLACK;
                    parent_node(check)->color = RED;
                    left_rotate(parent_node(check));
                    sister = parent_node(check)->right;
                }
                if ((sister->left == nullptr || BLACK == sister->left->color) &&
                    (sister->right == nullptr || BLACK == sister->right->color)) {
                    sister->color = RED;
                    check = parent_node(check);
                } else {
                    if (sister->right == nullptr || BLACK == sister->right->color) {
                        sister->left->color = BLACK;
                        sister->color = RED;
                        right_rotate(sister);
                        sister = parent_node(check)->right;
                    }
                    sister->color = parent_node(check)->color;
                    parent_node(check)->color = BLACK;
                    if (sister->right != nullptr)
                        sister->right->color = BLACK;
                    left_rotate(parent_node(check));
                    check = root;
                }
            } else {
                RedBlackNode* sister = parent_node(check)->left;
                if (RED == sister->color) {
                    sister->color = BLACK;
                    parent_node(check)->color = RED;
                    right_rotate(parent_node(check));
                    sister = parent_node(check)->left;
                }
                if ((sister->left == nullptr || BLACK == sister->left->color) &&
                    (sister->right == nullptr || BLACK == sister->right->color)) {
                    sister->color = RED;
                    check = parent_node(check);
                } else {
                    if (sister->left == nullptr || BLACK == sister->left->color) {
                        sister->right->color = BLACK;
                        sister->color = RED;
                        left_rotate(sister);
                        sister = parent_node(check)->left;
                    }
                    sister->color = parent_node(check)->color;
                    if (sister->left != nullptr)
                        sister->left->color = BLACK;
                    parent_node(check)->color = BLACK;
                    right_rotate(parent_node(check));
                    check = root;
                }
            }
        }
        check->color = BLACK;
    }

    void KO_CLASS_NAME(RedBlackTree)::pre_order(u4int index, const u4int offset, RedBlackNode *node, const u4int level, KO_CLASS_NAME(SystemStream) *out) const {
        if (node == nullptr) { return; }
        index = index * 2 + offset;

        out->append("{\"array_index\":%4u,\"level\":%2u,\"color\":%s,\"value\":", index, level, node->color ? "black" : "r e d"); //NOLINT
        node->value->serialize(out);
        out->append("}\n");

        pre_order(index, 1, node->left, level + 1, out);
        pre_order(index, 2, node->right, level + 1, out);
    }

    KO_CLASS_NAME(RedBlackTree)::KO_CLASS_NAME(RedBlackTree)() {
        type = Util::Object;
        root = nullptr;
        node_pointer = true;
    }

    KO_CLASS_NAME(RedBlackTree)::KO_CLASS_NAME(RedBlackTree)(u4int type, bool d) : type(type), node_pointer(d) {
        root = nullptr;
    }

    KO_CLASS_NAME(RedBlackTree)::~KO_CLASS_NAME(RedBlackTree)() { delete root; }

    s4int KO_CLASS_NAME(RedBlackTree)::rbt_insert(KO_CLASS_NAME(Object) *value) {
        if(value->sign() != type) { if (type == Util::Object) { return -1; } return 0; }
        auto* new_node = new RedBlackNode(value);
        new_node->delete_pointer = node_pointer;
        if (root == nullptr) {
            new_node->color = BLACK;
            root = new_node;
        }

        RedBlackNode* current = root;
        RedBlackNode* temp = current;
        for (; current != nullptr;) {
            temp = current;
            if (current->value->hash() > value->hash()) {
                current = current->left;
            } else if (current->value->hash() < value->hash()) {
                current = current->right;
            } else {
                return 0;
            }
        }

        if (temp->value->hash() > value->hash()) {
            temp->left = new_node;
        } else {
            temp->right = new_node;
        }
        new_node->parent = temp;
        fix_after_append(new_node);
        return 1;
    }

    s4int KO_CLASS_NAME(RedBlackTree)::rbt_delete(s4int hash_value) {
        RedBlackNode* delete_node = found(hash_value);
        if (delete_node == nullptr) { return 0; }
        if (delete_node->left != nullptr && delete_node->right != nullptr) {
            RedBlackNode* temp = successor(delete_node);
            temp->value->clone(reinterpret_cast<KO_CLASS_NAME(Hickey)*&>(delete_node->value));
            delete_node = temp;
        }
        RedBlackNode* replacement = delete_node->left == nullptr ? delete_node->right : delete_node->left;
        if (replacement == nullptr) {
            if (delete_node->parent == nullptr) {
                root = nullptr;
            } else {
                if (BLACK == delete_node->color) {
                    fix_after_subtract(delete_node);
                }
                if (delete_node == parent_node(delete_node)->left) {
                    parent_node(delete_node)->left = nullptr;
                } else {
                    parent_node(delete_node)->right = nullptr;
                }
                delete_node->parent = nullptr;
            }
        } else {
            replacement->color = BLACK;
            replacement->parent = parent_node(delete_node);
            if (delete_node->parent == nullptr) {
                root = replacement;
            } else if (delete_node == parent_node(delete_node)->left) {
                parent_node(delete_node)->left = replacement;
            } else {
                parent_node(delete_node)->right = replacement;
            }
            delete_node->parent = nullptr;
            delete_node->left = nullptr;
            delete_node->right = nullptr;
        }

        delete delete_node;
        return 1;
    }

    KO_CLASS_NAME(Object) * KO_CLASS_NAME(RedBlackTree)::rbt_find(s4int hash_value) {
        RedBlackNode* new_node = found(hash_value);
        if (new_node == nullptr) { return nullptr; }
        return new_node->value;
    }

    u4int KO_CLASS_NAME(RedBlackTree)::sign() const { return Util::RedBlackTree; }

    bool KO_CLASS_NAME(RedBlackTree)::equals(const KO_CLASS_NAME(Hickey) *const target) const { return false; }

    s4int KO_CLASS_NAME(RedBlackTree)::clone(KO_CLASS_NAME(Hickey) *&target) const { return 0; }

    DEFAULT_OBJECT_HASH(KO_CLASS_NAME(RedBlackTree))

    s4int KO_CLASS_NAME(RedBlackTree)::serialize(KO_CLASS_NAME(Hickey) *sys) const {
        if (sys->sign() != Util::SystemStream) { return 0; }
        auto* out = (KO_CLASS_NAME(SystemStream)*)sys;
        pre_order(0u,0u,root,1u,out);
        return 1;
    }

    // ====  ====

    DataNode::DataNode(KO_CLASS_NAME(Object) *value) : value(value) {
        front = nullptr;
        next = nullptr;
        delete_pointer = true;
    }

    DataNode::~DataNode() {
        delete next;
        if (delete_pointer) { delete value; }
    }

    // ====  ====

    KO_CLASS_NAME(UnidirectList)::KO_CLASS_NAME(UnidirectList)() {
        type = Util::Object;
        node_pointer = true;
        head = new DataNode();
    }

    KO_CLASS_NAME(UnidirectList)::~KO_CLASS_NAME(UnidirectList)() { delete head; }

    DEFAULT_OBJECT_SIGN(KO_CLASS_NAME(UnidirectList))

    DEFAULT_OBJECT_EQUALS(KO_CLASS_NAME(UnidirectList))

    DEFAULT_OBJECT_CLONE(KO_CLASS_NAME(UnidirectList))

    DEFAULT_OBJECT_HASH(KO_CLASS_NAME(UnidirectList))

    DEFAULT_OBJECT_SERIALIZE(KO_CLASS_NAME(UnidirectList))

    KO_CLASS_NAME(UnidirectList)::KO_CLASS_NAME(UnidirectList)(u4int type, bool d) : type(type), node_pointer(d) {
        head = new DataNode();
    }

    s4int KO_CLASS_NAME(UnidirectList)::ul_insert(KO_CLASS_NAME(Object) *value) {
        if (value->sign() != type) { if (type == Util::Object) { return -1; } return 0; }
        DataNode* t = head;
        for (; t->next != nullptr; t = t->next) {}
        t->next = new DataNode(value);
        t->next->delete_pointer = node_pointer;
        return 1;
    }

    s4int KO_CLASS_NAME(UnidirectList)::ul_delete(KO_CLASS_NAME(Object) *value) {
        if (value->sign() != type) { if (type == Util::Object) { return -1; } return 0; }
        DataNode* node = nullptr;
        for (DataNode* t = head; t->next != nullptr; t = t->next) {
            if (t->value->equals(value)) {
                node = t;
                break;
            }
        }
        if (node == nullptr) { return -2; }
        DataNode* front = head;
        for (; front->next != node; front = front->next) {}
        front->next = node->next;
        node->next = nullptr;
        delete node;
        return 1;
    }

    // ====  ====

    KO_CLASS_NAME(BidirectList)::KO_CLASS_NAME(BidirectList)() {
        type = Util::Object;
        node_pointer = true;
        head = new DataNode();
        tail = head;
    }

    KO_CLASS_NAME(BidirectList)::~KO_CLASS_NAME(BidirectList)() { tail = nullptr; delete head; }

    DEFAULT_OBJECT_SIGN(KO_CLASS_NAME(BidirectList))

    DEFAULT_OBJECT_EQUALS(KO_CLASS_NAME(BidirectList))

    DEFAULT_OBJECT_CLONE(KO_CLASS_NAME(BidirectList))

    DEFAULT_OBJECT_HASH(KO_CLASS_NAME(BidirectList))

    DEFAULT_OBJECT_SERIALIZE(KO_CLASS_NAME(BidirectList))

    KO_CLASS_NAME(BidirectList)::KO_CLASS_NAME(BidirectList)(u4int type, bool d) : type(type), node_pointer(d) {
        head = new DataNode();
        tail = head;
    }

    s4int KO_CLASS_NAME(BidirectList)::bl_insert(KO_CLASS_NAME(Object) *value) {
        if (value->sign() != type) { if (type == Util::Object) { return -1; } return 0; }
        DataNode* tf = tail;
        auto* node = new DataNode(value);
        tf->next = node;
        tail = node;
        tail->front = tf;
        return 1;
    }

    s4int KO_CLASS_NAME(BidirectList)::bl_delete(KO_CLASS_NAME(Object) *value) {
        if (value->sign() != type) { if (type == Util::Object) { return -1; } return 0; }
        DataNode* node = head;
        for (; node->next != nullptr; node = node->next) {
            if (node->value->equals(value)) {
                break;
            }
        }
        if (node == tail) {
            if (!node->value->equals(value)) { return -2; }
            node->front->next = nullptr;
            node->front = nullptr;
        }
        node->next->front = node->front;
        node->front = nullptr;
        node->next->front->next = node->next;
        node->next = nullptr;
        delete node;
        return 1;
    }

    // ====  ====
}
#endif
// ====  ====
