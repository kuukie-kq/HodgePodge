#ifndef KO_KO_MUSIC_H
#define KO_KO_MUSIC_H

#include "configuration.h"

#if KO_KO_TEST_H
int run();
#endif

#endif //KO_KO_MUSIC_H
