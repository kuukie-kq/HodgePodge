#ifndef KO_KO_JSON_H
#define KO_KO_JSON_H
// ====  ====
#include "system.h"
using namespace kok;
// ====  ====
namespace sys {
    enum {
        QUEUE_KO = 23u,
        STACK_KO = 24u,
        INT_KO = 21601,
        STRING_KO = 21609,
        MAP_NODE_KO = 21610,
        MAP_KO = 21611,
        ARRAY_NODE_KO = 21612,
        ARRAY_KO = 21613,
    };

    KO_CLASS_NAME(Object) *new_default_instance(u4int type);

    int analysis(const std::string &json_string, void*& json_object);

    class LinkedNode { //NOLINT
    private:
        friend class Stack;
        friend class Queue;
        friend class Map;
        friend class Array;
        friend int analysis(const std::string &json_string, void*& json_object);

        KO_CLASS_NAME(Object) *value;
        LinkedNode *next;
    public:
        explicit LinkedNode(KO_CLASS_NAME(Object) *value = new KO_CLASS_NAME(Object)());
        ~LinkedNode();
    };

    class Stack KO_CLASS_INHERIT(Object) {
    private:
        friend int analysis(const std::string &json_string, void*& json_object);
        LinkedNode *head;
        u4int type;
    public:
        explicit Stack(u4int type = Util::Object);
        ~Stack() override;
        s4int s_insert(KO_CLASS_NAME(Object) *value);
        KO_CLASS_NAME(Object) *s_delete();
        KO_CLASS_OVERRIDE
    };

    class Queue KO_CLASS_INHERIT(Object) {
    private:
        friend class Map;
        friend class Array;
        LinkedNode *head;
        u4int type;
    public:
        explicit Queue(u4int type = Util::Object);
        ~Queue() override;
        s4int q_insert(KO_CLASS_NAME(Object) *value);
        KO_CLASS_NAME(Object) *q_delete();
        KO_CLASS_OVERRIDE
    };

    class Int KO_CLASS_INHERIT(Object) {
    private:
        s4int i;
    public:
        explicit Int(int i = 0);
        ~Int() override = default;
        KO_CLASS_OVERRIDE
    };

    class String KO_CLASS_INHERIT(Object) {
    private:
        std::string *s;
    public:
        explicit String(const char *c = "");
        ~String() override;
        KO_CLASS_OVERRIDE
    };

    class MapNode KO_CLASS_INHERIT(Object) {
    private:
        friend class Map;
        friend class JsonObject;
        KO_CLASS_NAME(Object) *key;
        KO_CLASS_NAME(Object) *value;
    public:
        explicit MapNode(KO_CLASS_NAME(Object) *key = new KO_CLASS_NAME(Object)(), KO_CLASS_NAME(Object) *value = new KO_CLASS_NAME(Object)());
        ~MapNode() override;
        KO_CLASS_OVERRIDE
    };

    class Map KO_CLASS_INHERIT(Object) {
    private:
        Queue *item;
        KO_CLASS_NAME(RedBlackTree) *index;
        static const s4int MAP_REDBLACKTREE_NODE = 114514;
        class MRBTN final KO_CLASS_INHERIT(Object) {
        public:
            int hash_code;
            void* value_node;
            explicit MRBTN(int hash_code = 0, MapNode* value_node = nullptr);
            ~MRBTN() override;
            KO_CLASS_OVERRIDE
        };
    public:
        Map();
        ~Map() override;
        s4int m_insert(String *k, KO_CLASS_NAME(Object) *v);
        s4int m_delete(s4int hash_value);
        KO_CLASS_NAME(Object)* m_find(s4int hash_value);
        KO_CLASS_OVERRIDE
        s4int insert(KO_CLASS_NAME(Object) *add_item);
    };

    class ArrayNode KO_CLASS_INHERIT(Object) {
    private:
        friend class Array;
        friend class JsonObject;
        KO_CLASS_NAME(Object) *key;
        KO_CLASS_NAME(Object) *value;
    public:
        explicit ArrayNode(KO_CLASS_NAME(Object) *key = new KO_CLASS_NAME(Object)(), KO_CLASS_NAME(Object) *value = new KO_CLASS_NAME(Object)());
        ~ArrayNode() override;
        KO_CLASS_OVERRIDE
    };

    class Array KO_CLASS_INHERIT(Object) {
    private:
        Queue *item;
        static const s4int MAX_LENGTH = 1024;
        class ALN final {
        public:
            ArrayNode** array;
            ALN() { array = new ArrayNode*[MAX_LENGTH](); }
            ~ALN() { delete[] array; }
        };
        s4int size;
        ALN* index;
    public:
        Array();
        ~Array() override;
        s4int a_insert(ArrayNode *v);
        s4int a_delete(s4int fifo_index);
        KO_CLASS_NAME(Object)* a_find(s4int fifo_index);
        KO_CLASS_OVERRIDE
        s4int insert(KO_CLASS_NAME(Object) *add_item);
    };
}
// ====  ====
#if KO_KO_TEST_H
DECLARE_INTERFACE_FUNCTION int test_system_json_run();
#endif
// ====  ====
#endif //KO_KO_JSON_H
