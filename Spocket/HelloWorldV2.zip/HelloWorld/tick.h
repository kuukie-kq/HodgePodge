#ifndef KO_KO_TICK_H
#define KO_KO_TICK_H

#include <thread>

#define LOCK_PREFIX "lock;"
#define __sync_bool_compare_and_swap(mem,oldval,newval) ({ \
    __typeof (*mem) ret; \
    __asm __volatile (LOCK_PREFIX "cmpxchgl %2, %1;sete %%al;movzbl %%al,%%eax" \
    : "=a" (ret), "=m" (*mem) \
    : "r" (newval), "m" (*mem), "a" (oldval) \
    :"memory"); \
    ret; \
})

#include "system.h"
#include "json.h"
using namespace kok;

DECLARE_INTERFACE_FUNCTION void binding();
DECLARE_INTERFACE_FUNCTION void release();
DECLARE_INTERFACE_FUNCTION void all_tick();

class MessageQueue;

class TickNode final KO_CLASS_INHERIT(Object) {
public:
    class Tick {
    public:
        u4int type;
        union {
            struct {
                s4int uid;
                s1int uc4[4];
                u8int time;
            } one;
            struct {
                s8int uuid;
                u8int time;
            } two;
        } data{};
        Tick();
    };
    using Function = int (*)(Tick*);
    static const u4int s = 10010;
private:
    Tick* t;
    Function fun;
public:
    TickNode();
    ~TickNode() override;
    void tick();
    void set(Tick* m, Function f);
    KO_CLASS_OVERRIDE
};

class MessageQueue final {
private:
    sys::Queue* queue;
    s4int size;
public:
    MessageQueue();
    ~MessageQueue();
    void add();
    void append(TickNode* tn);
    void set();
    void get(TickNode*& t);
};

#endif //KO_KO_TICK_H
