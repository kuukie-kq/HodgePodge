#ifndef KO_KO_TIMER_H
#define KO_KO_TIMER_H
// ====  ====
#include <cstdlib>
#include <thread>
#include "configuration.h"
// ====  ====
namespace tim {
    class Timer {
    public:
        using Dispose = kok::s4int (*)(kok::u2int);
    private:
        struct node {
            Dispose conduct;
            kok::u2int sign;
            kok::u8int time;
            kok::s4int rotation;
            node* next;
            node* front;
            node();
        };
        struct header {
            kok::u8int longtime;
            header* next;
            node* sub;
            header();
        };
        header* loop;
        header* current;
        kok::u8int time;
        const kok::s4int size;
        const kok::s8int threshold;
        const kok::u4int theory;
        const kok::u4int practice;
        kok::s4int tick();
        kok::s4int bind(kok::u8int stamp, Dispose option, kok::u2int args);
        friend kok::s4int last(kok::u2int args);
    public:
        void in_it();
        void un_it();
        Timer();
        void start();
        void later(kok::u4int length, const char c, Dispose option, kok::u2int args); //NOLINT
        void moment(kok::u8int stamp, Dispose option, kok::u2int args);
    };
}
// ====  ====
#if KO_KO_TEST_H
DECLARE_INTERFACE_FUNCTION int test_timer_run();
#endif
// ====  ====
#endif //KO_KO_TIMER_H
