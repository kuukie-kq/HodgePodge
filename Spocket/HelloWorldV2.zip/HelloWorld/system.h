#ifndef KO_KO_SYSTEM_H
#define KO_KO_SYSTEM_H
// ====  ====
#include "configuration.h"
// ====  ====
#include <iostream>
#include <sstream>
#include <cstdarg>
#include <chrono>
#include <string>
#include <vector>
#include <fstream>
// ====  ====
#define KO_DECLARE_CLASS_HEADER(name, base) class KO_CLASS_NAME(name) KO_CLASS_INHERIT(base)

#define KO_DECLARE_CLASS_DEFAULT(name) \
    KO_CLASS_OVERRIDE \
    KO_CLASS_STRUCT(name)

#define DECLARE_CLASS(name, base) \
    KO_DECLARE_CLASS_HEADER(name, base) { \
    public: \
    KO_DECLARE_CLASS_DEFAULT(name) \
    }

#define DEFAULT_OBJECT_SIGN(classname) \
    u4int classname::sign() const { return Util::Object; }

#define DEFAULT_OBJECT_EQUALS(classname) \
    bool classname::equals(const KO_CLASS_NAME(Hickey) *const target) const { \
        if (target->sign() != sign()) { return false; } \
        return this == target; \
    }

#define DEFAULT_OBJECT_CLONE(classname) \
    s4int classname::clone(KO_CLASS_NAME(Hickey) *&target) const { \
        if (target == nullptr) { return 0; } \
        if (target->sign() != sign()) { return 0; } \
        if (this == target) { target = nullptr; } \
        delete target; \
        target = new KO_CLASS_NAME(Object)(); \
        return 1; \
    }

#define DEFAULT_OBJECT_HASH(classname) \
    s4int classname::hash() const { return 1; }

#define DEFAULT_OBJECT_SERIALIZE(classname) \
    s4int classname::serialize(KO_CLASS_NAME(Hickey) *sys) const { return 0; }

#define DECLARE_INTERFACE_FUNCTION extern "C"
// ====  ====
namespace kok {
    class TimeStamp {
    private:
        std::chrono::nanoseconds start_stamp = std::chrono::nanoseconds::zero();
    public:
        TimeStamp();
        ~TimeStamp();
        u8int time_line_passed();
        u8int time_start();
        static u8int time_now();
    };

    class Util final {
    private:
        Util();
        ~Util();
        static Util* util;
    public:
        static Util* u();
        const s4int k_ten = 1000;
        const s4int m_ten = 1000000;
        const s4int g_ten = 1000000000;
        const s4int ms_time = 60;
        const s4int hs_time = 3600;
        const s4int dh_time = 24;
        const s4int utc_e8 = 8;
        u4int hash_code(const char* key) const;
        std::vector<std::string> spilt(std::string str, const std::string& pattern) const;
        inline u4int time_nano(u8int stamp);
        inline u4int time_milli(u8int stamp);
        inline u4int time_micro(u8int stamp);
        inline u4int time_second(u8int stamp);
        inline u4int time_minute(u8int stamp);
        inline u4int time_hour(u8int stamp);
        static const u4int Object = 3260681415u;
        static const u4int SystemStream = 12u;
        static const u4int RedBlackTree = 21u;
    };

    KO_DECLARE_CLASS_HEADER(SystemStream, Hickey) {
    protected:
        const s4int max_length = 1024;
        const s4int buffer_size = 1048575;
        std::stringstream* stream;
        std::stringstream* buffer;
        u4int on_or_off;
        u4int level;
        void upgrade(std::stringstream *sys, const char *format, ...) const;
        TimeStamp* timer;
        virtual void step() const;
        virtual void log() const;
        virtual void warning() const;
        virtual void error() const;
    public:
        KO_DECLARE_CLASS_DEFAULT(SystemStream)
        explicit KO_CLASS_NAME(SystemStream)(u4int ooo, u4int mode = 0u);
        void clear();
        void start(u4int mode);
        void maybe(u4int mode);
        void append(const char *format, ...) const;
        void end();
    };

    DECLARE_CLASS(Object, Hickey);

    enum RedBlackColor { RED = 0, BLACK = 1 };

    class RedBlackNode final {
    private:
        friend class KO_CLASS_NAME(RedBlackTree);
        KO_CLASS_NAME(Object)* value;
        RedBlackColor color;
        RedBlackNode* left;
        RedBlackNode* right;
        void* parent;
        bool delete_pointer;
    public:
        explicit RedBlackNode(KO_CLASS_NAME(Object)* value = new KO_CLASS_NAME(Object)());
        ~RedBlackNode();
    };

    KO_DECLARE_CLASS_HEADER(RedBlackTree, Hickey) {
    private:
        void left_rotate(RedBlackNode* pivot);
        void right_rotate(RedBlackNode* pivot);
        RedBlackNode* parent_node(RedBlackNode* child) const;
        void fix_after_append(RedBlackNode* check);
        RedBlackNode* found(int value);
        RedBlackNode* successor(RedBlackNode* check) const;
        void fix_after_subtract(RedBlackNode* check);
        void pre_order(u4int index, const u4int offset, RedBlackNode* node, const u4int level, KO_CLASS_NAME(SystemStream)* out) const; //NOLINT
        RedBlackNode* root;
        u4int type;
        bool node_pointer;
    public:
        KO_DECLARE_CLASS_DEFAULT(RedBlackTree)
        explicit KO_CLASS_NAME(RedBlackTree)(u4int type, bool d = true);
        s4int rbt_insert(KO_CLASS_NAME(Object)* value);
        s4int rbt_delete(s4int hash_value);
        KO_CLASS_NAME(Object)* rbt_find(s4int hash_value);
    };

    class DataNode final {
    private:
        friend class KO_CLASS_NAME(UnidirectList);
        friend class KO_CLASS_NAME(BidirectList);

        KO_CLASS_NAME(Object)* value;
        DataNode* front;
        DataNode* next;
        bool delete_pointer;
    public:
        explicit DataNode(KO_CLASS_NAME(Object)* value = new KO_CLASS_NAME(Object)());
        ~DataNode();
    };

    KO_DECLARE_CLASS_HEADER(UnidirectList, Object) {
    private:
        DataNode* head;
        u4int type;
        bool  node_pointer;
    public:
        KO_DECLARE_CLASS_DEFAULT(UnidirectList)
        explicit KO_CLASS_NAME(UnidirectList)(u4int type, bool d = true);
        s4int ul_insert(KO_CLASS_NAME(Object)* value);
        s4int ul_delete(KO_CLASS_NAME(Object)* value);
    };

    KO_DECLARE_CLASS_HEADER(BidirectList, Object) {
    private:
        DataNode* head;
        DataNode* tail;
        u4int type;
        bool  node_pointer;
    public:
        KO_DECLARE_CLASS_DEFAULT(BidirectList)
        explicit KO_CLASS_NAME(BidirectList)(u4int type, bool d = true);
        s4int bl_insert(KO_CLASS_NAME(Object)* value);
        s4int bl_delete(KO_CLASS_NAME(Object)* value);
    };
}
// ====  ====
#endif //KO_KO_SYSTEM_H