#include "tick.h"
// ====  ====
#if not KO_KO_SRC_H

int say(TickNode::Tick* t) {
    auto* out = new KO_CLASS_NAME(SystemStream)(1u, 1u);
    out->append("%d - %s", t->type, t->data.one.uc4);
    out->end();
    delete out;
    return 1;
}

int one_fun(TickNode::Tick* t) {
    auto* out = new KO_CLASS_NAME(SystemStream)(2u, 2u);
    out->append("%d - %d - %lld", t->type, t->data.one.uid, t->data.one.time);
    out->end();
    delete out;
    return 1;
}

int two_fun(TickNode::Tick* t) {
    auto* out = new KO_CLASS_NAME(SystemStream)(2u, 2u);
    out->append("%d - - %lld - - %lld", t->type, t->data.two.uuid, t->data.two.time);
    out->end();
    delete out;
    return 1;
}

MessageQueue* mq_message = nullptr;
s4int cas = 0;

void binding() {
    cas = 1;
    mq_message = new MessageQueue();
    auto* t = new TickNode::Tick();
    t->type = 11;
    t->data.one.uid = 1000;
    t->data.one.uc4[0] = 'h';
    t->data.one.uc4[1] = 'l';
    t->data.one.uc4[2] = 'o';
    t->data.one.uc4[3] = '\0';
    t->data.one.time = TimeStamp::time_now();
    auto* tn = new TickNode();
    tn->set(t, say);
    mq_message->append(tn);
}

void release() {
    cas = 0;
    delete mq_message;
}

void all_tick() {
    auto* timer = new kok::KO_CLASS_NAME(SystemStream)(1u, 1u);
    for (;;) {
        auto* tick_node = new TickNode();
        mq_message->get(tick_node);
        if (tick_node == nullptr) { break; }
        tick_node->tick();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
    }
    timer->end();
}

// ====  ====

TickNode::Tick::Tick() { type = 0; data = {}; }

TickNode::TickNode() { fun = nullptr; t = nullptr; }

TickNode::~TickNode() { delete t; }

void TickNode::tick() { if (fun(t) != 1) { auto* m = new Tick(); m->type = -1; m->data.one.uc4[0] = 'e'; m->data.one.uc4[1] = 'r'; m->data.one.uc4[2] = 'r'; m->data.one.uc4[3] = '\0';  auto* tn = new TickNode(); tn->set(m, say); mq_message->append(tn); } }

void TickNode::set(Tick *m, Function f) {
    t = m;
    fun = f;
}

u4int TickNode::sign() const { return s; }

DEFAULT_OBJECT_EQUALS(TickNode)

s4int TickNode::clone(KO_CLASS_NAME(Hickey) *&target) const {
    if (target == nullptr) { return 0; }
        if (target->sign() != sign() && target->sign() != Util::Object) { return 0; }
        if (this == target) { target = nullptr; }
        delete target;
        target = new TickNode();
        auto* tn = (TickNode*)target;
        tn->t = t;
        tn->fun = fun;
        return 1;
}

DEFAULT_OBJECT_HASH(TickNode)

DEFAULT_OBJECT_SERIALIZE(TickNode)

MessageQueue::MessageQueue() { queue = new sys::Queue(TickNode::s); size = 0; }

MessageQueue::~MessageQueue() { delete queue; }

void MessageQueue::add() {
    auto* t = new TickNode::Tick();
    t->type = 11;
    t->data.one.uid = 1001;
    t->data.one.time = TimeStamp::time_now() / Util::u()->g_ten * Util::u()->g_ten;
    auto* tn = new TickNode();
    tn->set(t, one_fun);
    queue->q_insert(tn);
    size ++;
}

void MessageQueue::append(TickNode *tn) {
    queue->q_insert(tn);
    size ++;
}

void MessageQueue::set() {
    auto* t = new TickNode::Tick();
    t->type = 12;
    u4int ha = Util::u()->hash_code("uuid-two-tick");
    u4int la = Util::u()->hash_code("test tick message");
    t->data.two.uuid = ((u8int)ha << 32u) + la;
    t->data.two.time = TimeStamp::time_now();
    auto* tn = new TickNode();
    tn->set(t, two_fun);
    queue->q_insert(tn);
    size ++;
}

void MessageQueue::get(TickNode *&t) {
    if (size != 0) {
        delete t;
        t = (TickNode*)queue->q_delete();
        size --;
    } else {
        t = nullptr;
    }
}

#endif
