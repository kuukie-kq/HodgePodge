#include "music.h"
#if not KO_KO_SRC_H
// ====  ====
#if ENVIRONMENT == 1
#include <iostream>
#include <Windows.h>
//#pragma comment(lib, "winmm.lib")

namespace msc {
    enum {
        REST = 0,
        x5CW = 108,
        x4BW = 107, x4AB = 106, x4AW = 105, x4GB = 104, x4GW = 103, x4FB = 102,
        x4FW = 101, x4EW = 100, x4DB = 99, x4DW = 98, x4CB = 97, x4CW = 96,
        x3BW = 95, x3AB = 94, x3AW = 93, x3GB = 92, x3GW = 91, x3FB = 90,
        x3FW = 89, x3EW = 88, x3DB = 87, x3DW = 86, x3CB = 85, x3CW = 84,
        x2BW = 83, x2AB = 82, x2AW = 81, x2GB = 80, x2GW = 79, x2FB = 78,
        x2FW = 77, x2EW = 76, x2DB = 75, x2DW = 74, x2CB = 73, x2CW = 72,
        x1BW = 71, x1AB = 70, x1AW = 69, x1GB = 68, x1GW = 67, x1FB = 66,
        x1FW = 65, x1EW = 64, x1DB = 63, x1DW = 62, x1CB = 61, x1CW = 60,
        x0BW = 59, x0AB = 58, x0AW = 57, x0GB = 56, x0GW = 55, x0FB = 54,
        x0FW = 53, x0EW = 52, x0DB = 51, x0DW = 50, x0CB = 49, x0CW = 48,
        X0BW = 47, X0AB = 46, X0AW = 45, X0GB = 44, X0GW = 43, X0FB = 42,
        X0FW = 41, X0EW = 40, X0DB = 39, X0DW = 38, X0CB = 37, X0CW = 36,
        X1BW = 35, X1AB = 34, X1AW = 33, X1GB = 32, X1GW = 31, X1FB = 30,
        X1FW = 29, X1EW = 28, X1DB = 27, X1DW = 26, X1CB = 25, X1CW = 24,
        X2BW = 23, X2AB = 22, X2AW = 21,
        BPM = 1001, ADD = 1002
    }; //NOLINT

    class Music {
    private:
        HMIDIOUT handle;
    public:
        Music() : handle(nullptr) {
            midiOutOpen(&handle, 0, 0, 0, CALLBACK_NULL);
        }
        ~Music() { midiOutClose(handle); }
        void done(kok::u4int voice) { midiOutShortMsg(handle, voice); }
    };
}

enum Voice
{
    L3 = msc::x0EW, L7 = msc::x0BW,
    M1 = msc::x1CW, M2 = msc::x1DW, M3 = msc::x1EW, M5 = msc::x1GW,
    LOW_SPEED = 500, MIDDLE_SPEED = 400, HIGH_SPEED = 300,
    _ = 0XFF
};


void Wind() {
    auto* m = new msc::Music();
    int volume = 0x7f;
    int voice;
    int sleep = 350;
    int wind[] = {
            L7,M1,M2,M3,L3
    };

    for (auto i : wind) {
        if (i == LOW_SPEED || i == HIGH_SPEED || i == MIDDLE_SPEED) {
            sleep = i;//Sleep(i/2);
            continue;
        }
        if (i == 0) { sleep = 0;continue; }
        if (i == 700) { Sleep(175);continue; }
        if (i == _) {
            Sleep(350);
            continue;
        }

        voice = (int)((unsigned int)volume << 16u) + (int)((unsigned int)i << 8u) + 0x90;
        m->done(voice);
        std::cout << voice << std::endl;
        Sleep(sleep);
    }
    delete m;
}

#if KO_KO_TEST_H
int run() { Wind(); return 1; }
#endif

#endif
// ====  ====
#endif
