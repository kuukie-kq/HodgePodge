#ifndef KO_KO_CONFIGURATION_H
#define KO_KO_CONFIGURATION_H

#ifdef __linux
#define ENVIRONMENT 0
#elif WIN32
#define ENVIRONMENT 1
#endif

#define KO_KO_SRC_H false

#define KO_KO_TEST_H true

#define _STR(y) #y
#define STR(x) _STR(x)

#define _CONTACT(i, j) i##j
#define CONTACT(x, y) _CONTACT(x, y)

#define KO_EXT Kok

#define KO_VERSION 0.0.1

#define KO_CLASS_NAME(name) CONTACT(KO_EXT, name)

namespace kok {
    typedef unsigned char u1int; //NOLINT
    typedef char s1int; //NOLINT
    typedef unsigned short u2int; //NOLINT
    typedef short s2int; //NOLINT
    typedef unsigned int u4int; //NOLINT
    typedef int s4int; //NOLINT
    typedef unsigned long long u8int; //NOLINT
    typedef long long s8int; //NOLINT

    class KO_CLASS_NAME(Hickey) {
    private:
        KO_CLASS_NAME(Hickey)& operator=(KO_CLASS_NAME(Hickey)&) = default;
        KO_CLASS_NAME(Hickey)(KO_CLASS_NAME(Hickey)&) = default;
        KO_CLASS_NAME(Hickey)& operator=(KO_CLASS_NAME(Hickey)&&) noexcept = default;
        KO_CLASS_NAME(Hickey)(KO_CLASS_NAME(Hickey)&&) noexcept = default;
    protected:
        KO_CLASS_NAME(Hickey)() = default;
    public:
        virtual ~KO_CLASS_NAME(Hickey)() = default;
        virtual u4int sign() const = 0;
        virtual bool equals(const KO_CLASS_NAME(Hickey)* const target) const = 0; //NOLINT
        virtual s4int clone(KO_CLASS_NAME(Hickey)*& target) const = 0;
        virtual s4int hash() const = 0;
        virtual s4int serialize(KO_CLASS_NAME(Hickey)* sys) const = 0;
    };
}

#define KO_CLASS_INHERIT(name) : public KO_CLASS_NAME(name)

#define EQUALS_OVERRIDE bool equals(const KO_CLASS_NAME(Hickey) *const target) const override; //NOLINT

#define KO_CLASS_OVERRIDE \
    u4int sign() const override; \
    EQUALS_OVERRIDE \
    s4int clone(KO_CLASS_NAME(Hickey) *&target) const override; \
    s4int hash() const override; \
    s4int serialize(KO_CLASS_NAME(Hickey) *sys) const override;

#define KO_CLASS_STRUCT(name) \
    KO_CLASS_NAME(name)(); \
    ~KO_CLASS_NAME(name)() override;

#endif //KO_KO_CONFIGURATION_H
