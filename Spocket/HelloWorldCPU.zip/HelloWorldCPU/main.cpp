#include <iostream>
#include "virtual_cpu.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    system("chcp 65001");
    kuu::cpu_run_main();
    return 0;
}
