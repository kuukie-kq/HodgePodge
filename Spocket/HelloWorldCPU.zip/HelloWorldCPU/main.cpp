#include <iostream>
#include "virtual_cpu.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    //system为执行脚本命令与exec区别
    //Windows默认代码页936 编码为GBK 说明简体中文 可能与系统语言有关 不是utf-8(65001)编码存在乱码问题
    system("chcp 65001");
    kuu::cpu_run_main();
    return 0;
}

//
//base user
//用户名，密码，号
//base menu
//提示，链接，号
//base view
//标题，内容，模式
//
