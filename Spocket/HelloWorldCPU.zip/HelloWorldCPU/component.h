//
// Created by kuu-kie on 2022/8/25.
//

#ifndef COMPONENT_H
#define COMPONENT_H

#include <iostream> //输入输出
#include <sstream> //输入输出缓冲
#include <cstdarg> //不定参数处理
#include <chrono> //时间戳
#include <string> //字符串类
#include <vector> //不定数组，字符串分割
#include <fstream> //读写文件

namespace kuu {
    //
    // sign使用
    // 基本 hickey    3260681415
    // system_stream    1
    class hickey {
    private:
        // 禁用拷贝构造函数
        hickey& operator=(hickey&) = default;
        hickey(hickey&) = default;
        // 禁用赋值运算符
        hickey& operator=(hickey&&) = default;
        hickey(hickey&&) = default;
    protected:
        // 禁用构造函数，也不算禁用，就是无法正常使用，防止产生实例
        // 不过，存在纯虚函数，就产生不了实例
        hickey() = default;
        inline bool check_conversion(const hickey* const target) const { return sign() == target->sign(); } // 方便使用，判断是否是同一种类
    public:
        virtual ~hickey() = default;
        virtual unsigned int sign() const { return 3260681415u; } // 类的签名//相当于java.getClass，由于类之间的关系问题，如果为static模板中还是无法直接使用
        virtual bool equals(const hickey* const target) const { return this == target; } // 判断两个对象是否相等//相当于java.equals
        virtual int clone(hickey*& target) const { return 0; } // 克隆出一个内容一样的不同内存，注意，使用深拷贝，另外注意参数的传递，可能会出现内存无法回收的情况（自己传自己）//相当于java.clone
        virtual int hash() const { return 0; } // 对象的标识或排序规则//相当于java.hashCode
        virtual int serialize(hickey* sys) const { return 0; } // 非规范的序列化//相当于java.toString
    };

    class system_stream : public hickey {
    private:
        class time_stamp {
        private:
            std::chrono::nanoseconds start_stamp = std::chrono::nanoseconds::zero();
        public:
            time_stamp() { start_stamp = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()); }
            ~time_stamp() { start_stamp = std::chrono::nanoseconds::zero(); }
            unsigned long long time_line_passed() { std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()); unsigned long long passed = now.count() - start_stamp.count(); if (passed > 0) { return (passed); } return 0; }
            unsigned long long time_start() { return start_stamp.count(); }
            static unsigned long long time_now() { std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()); unsigned long long passed = now.count(); return passed; }
        };
    protected:
        const static int MAX_LENGTH = 1024;
        const static int BUFFER_SIZE = 1048575; // 2^20 - 1
        void upgrade(std::stringstream* sys, const char *format, ...) const {
            if (level & on_or_off) {
                char *buff = (char *) malloc(MAX_LENGTH);
                va_list args;
                va_start(args, format);
                int length = vsnprintf(buff, MAX_LENGTH, format, args);
                (length >= MAX_LENGTH) ? *sys << length << "- format and args too long" : *sys << buff;
                va_end(args);
                delete buff;
            }
        }
        time_stamp* timer;
        unsigned int on_or_off;
        unsigned int level;
        static inline unsigned int time_nano(unsigned long long stamp) { unsigned int re = stamp % 1000; return re; }
        static inline unsigned int time_milli(unsigned long long stamp) { unsigned int re = stamp / 1000 % 1000; return re; }
        static inline unsigned int time_micro(unsigned long long stamp) { unsigned int re = stamp / 1000000 % 1000; return re; }
        static inline unsigned int time_second(unsigned long long stamp) { unsigned int re = stamp / 1000000000 % 60; return re; }
        static inline unsigned int time_minute(unsigned long long stamp) { unsigned int re = stamp / 1000000000 / 60 % 60; return re; }
        static inline unsigned int time_hour(unsigned long long stamp) { unsigned int re = stamp / 1000000000 / (60 * 60) % 24; return re + 8; }// UTC+8 (GMT)
        std::stringstream* stream;
        std::stringstream* buffer;
        virtual void step() const {
            if (buffer->rdbuf()->in_avail() > BUFFER_SIZE) {
                std::cout << buffer->str();
                buffer->clear();
                buffer->str("");
            }
            unsigned long long tmp = time_stamp::time_now();
            upgrade(buffer, "<-\t[%02d:%02d:%02d %03dms%03dus%03dns]", time_hour(tmp), time_minute(tmp), time_second(tmp), time_micro(tmp), time_milli(tmp), time_nano(tmp));
            *buffer << stream->str();
            upgrade(buffer," >\n");
        }
        virtual void log() const {
            if (buffer->rdbuf()->in_avail() > 0) {
                std::cout << buffer->str();
                buffer->clear();
                buffer->str("");
            }
            unsigned long long tmp = time_stamp::time_now();
            upgrade(buffer, "<*\t[%02d:%02d:%02d %03dms%03dus%03dns]", time_hour(tmp), time_minute(tmp), time_second(tmp), time_micro(tmp), time_milli(tmp), time_nano(tmp));
            *buffer << stream->str();
            upgrade(buffer," >\n");
            std::cout << buffer->str();
            buffer->clear();
            buffer->str("");
        }
        virtual void warning() const {
            unsigned long long tmp = time_stamp::time_now();
            upgrade(buffer, ">-\t[%02d:%02d:%02d %03dms%03dus%03dns]", time_hour(tmp), time_minute(tmp), time_second(tmp), time_micro(tmp), time_milli(tmp), time_nano(tmp));
            *buffer << stream->str();
            upgrade(buffer," <\n");
            std::cout << buffer->str();
            buffer->clear();
            buffer->str("");
        }
        virtual void error() const {
            unsigned long long tmp = time_stamp::time_now();
            upgrade(buffer, ">*\t[%02d:%02d:%02d %03dms%03dus%03dns]", time_hour(tmp), time_minute(tmp), time_second(tmp), time_micro(tmp), time_milli(tmp), time_nano(tmp));
            *buffer << stream->str();
            upgrade(buffer," <\n");
            std::cerr << buffer->str();
            buffer->clear();
            buffer->str("");
        }
    public:
        explicit system_stream(unsigned int ooo = 1u, unsigned int mode = 0) { stream = new std::stringstream(); buffer = new std::stringstream(); on_or_off = ooo; level = mode; timer = new time_stamp(); }
        ~system_stream() override { delete timer; delete stream; delete buffer; }
        int hash() const override { return static_cast<int>(timer->time_start()); }
        unsigned int sign() const override { return 1u; }
        bool equals(const hickey* target) const override { if (target->sign() != sign()) { return false; } return ((system_stream*)target)->stream->str() == stream->str() && ((system_stream*)target)->buffer->str() == buffer->str(); }
        int clone(hickey*& target) const override {
            if (target == nullptr) { return 0; }
            if (sign() == target->sign()) {
                if (target == this) {
                    // 由此可以看出，此clone只能复制一个模式相同的输出流，而流中的数据是没有的
                    target = new system_stream(on_or_off, level);
                    return 2;
                } else {
                    delete target;
                    target = new system_stream(on_or_off, level);
                    return 1;
                }
            } else { return 0; }
        }
        int serialize(hickey* sys) const override { return 0; }
        void clear() { stream->clear(); stream->str(""); level = 0; }
        void start(unsigned int mode) { if (stream->rdbuf()->in_avail() > 0) { clear(); } level = mode; }
        void maybe(unsigned int mode) { level = mode; }
        void append(const char *format, ...) const {
            if (level & on_or_off) {
                char *buff = (char *) malloc(MAX_LENGTH);
                va_list args;
                va_start(args, format);
                int length = vsnprintf(buff, MAX_LENGTH, format, args);
                (length >= MAX_LENGTH) ? *stream << length << "- format and args too long" : *stream << buff;
                va_end(args);
                delete buff;
            }
        }
        void end() {
            if (level == 0) return;
            bool error_on = (level & 1u) & (on_or_off & 1u);
            bool warning_on = (level & 2u) & (on_or_off & 2u);
            bool log_on = (level & 4u) & (on_or_off & 4u);
            bool step_on = (level & 8u) & (on_or_off & 8u);
            unsigned long stamp = timer->time_line_passed();
            append("\t%llu[%d s %d ms %d us %d ns]", stamp, stamp / 1000000000, time_micro(stamp), time_milli(stamp), time_nano(stamp));
            if (error_on) {
                error();
            } else if (warning_on) {
                warning();
            } else if (log_on) {
                log();
            } else if (step_on) {
                step();
            }
            clear();
        }
    };

    // 红黑树，需要实现hickey接口，且确保实现了hash sign serialize红黑树中的value既标识排序的字段需要用到
    template<class SERIAL>
    class red_black_tree final : public hickey {
    private:
        enum red_black { RED = 0, BLACK = 1};
        class node {
        public:
            hickey* value;
            red_black color;
            node* left;
            node* right;
            void* parent;
            explicit node(hickey* value = new SERIAL()) : value(value) {
                color = RED;
                left = nullptr;
                right = nullptr;
                parent = nullptr;
            }
            ~node() { delete left; delete right; delete value; }
        };
        void left_rotate(node* pivot) {
            node* right = pivot->right;
            pivot->right = right->left;
            if (right->left != nullptr) {
                right->left->parent = pivot;
            }
            right->parent = pivot->parent;
            if (pivot->parent == nullptr) {
                root = right;
            } else if (parent_node(pivot)->left == pivot) {
                parent_node(pivot)->left = right;
            } else {
                parent_node(pivot)->right = right;
            }
            right->left = pivot;
            pivot->parent = right;
        }
        void right_rotate(node* pivot) {
            node* left = pivot->left;
            pivot->left = left->right;
            if (left->right != nullptr) {
                left->right->parent = pivot;
            }
            left->parent = pivot->parent;
            if (pivot->parent == nullptr) {
                root = left;
            } else if (parent_node(pivot)->left == pivot) {
                parent_node(pivot)->left = left;
            } else {
                parent_node(pivot)->right = left;
            }
            left->right = pivot;
            pivot->parent = left;
        }
        node* parent_node(node* child) const { if(child == nullptr) { return nullptr; } return (node*)child->parent; }
        void fix_after_append(node* check) {
            for (; check != nullptr && root != check && parent_node(check)->color == RED;) {
                if (parent_node(check) == parent_node(parent_node(check))->left) {
                    node* uncle = parent_node(parent_node(check))->right;
                    if (uncle != nullptr && uncle->color == RED) {
                        uncle->color = BLACK;
                        parent_node(check)->color = BLACK;
                        check = parent_node(parent_node(check));
                        check->color = RED;
                    } else {
                        if (check == parent_node(check)->right) {
                            check = parent_node(check);
                            left_rotate(check);
                        }
                        parent_node(check)->color = BLACK;
                        parent_node(parent_node(check))->color = RED;
                        right_rotate(parent_node(parent_node(check)));
                    }
                } else {
                    node* uncle = parent_node(parent_node(check))->left;
                    if (uncle != nullptr && uncle->color == RED) {
                        uncle->color = BLACK;
                        parent_node(check)->color = BLACK;
                        check = parent_node(parent_node(check));
                        check->color = RED;
                    } else {
                        if (check == parent_node(check)->left) {
                            check = parent_node(check);
                            right_rotate(check);
                        }
                        parent_node(check)->color = BLACK;
                        parent_node(parent_node(check))->color = RED;
                        left_rotate(parent_node(parent_node(check)));
                    }
                }
            }
            root->color = BLACK;
        }
        node* found(int value) {
            node* current = root;
            for (; current != nullptr;) {
                if (current->value->hash() > value) {
                    current = current->left;
                } else if (current->value->hash() < value) {
                    current = current->right;
                } else {
                    break;
                }
            }
            return current;
        }
        node* successor(node* check) const {
            node* most_left = check->right;
            for (; most_left != nullptr && most_left->left != nullptr;) {
                most_left = most_left->left;
            }
            return most_left;
        }
        void fix_after_subtract(node* check) {
            for (; check != root && BLACK == check->color;) {
                if (check == parent_node(check)->left) {
                    node* sister = parent_node(check)->right;
                    if (RED == sister->color) {
                        sister->color = BLACK;
                        parent_node(check)->color = RED;
                        left_rotate(parent_node(check));
                        sister = parent_node(check)->right;
                    }
                    if ((sister->left == nullptr || BLACK == sister->left->color) &&
                        (sister->right == nullptr || BLACK == sister->right->color)) {
                        sister->color = RED;
                        check = parent_node(check);
                    } else {
                        if (sister->right == nullptr || BLACK == sister->right->color) {
                            sister->left->color = BLACK;
                            sister->color = RED;
                            right_rotate(sister);
                            sister = parent_node(check)->right;
                        }
                        sister->color = parent_node(check)->color;
                        parent_node(check)->color = BLACK;
                        if (sister->right != nullptr)
                            sister->right->color = BLACK;
                        left_rotate(parent_node(check));
                        check = root;
                    }
                } else {
                    node* sister = parent_node(check)->left;
                    if (RED == sister->color) {
                        sister->color = BLACK;
                        parent_node(check)->color = RED;
                        right_rotate(parent_node(check));
                        sister = parent_node(check)->left;
                    }
                    if ((sister->left == nullptr || BLACK == sister->left->color) &&
                        (sister->right == nullptr || BLACK == sister->right->color)) {
                        sister->color = RED;
                        check = parent_node(check);
                    } else {
                        if (sister->left == nullptr || BLACK == sister->left->color) {
                            sister->right->color = BLACK;
                            sister->color = RED;
                            left_rotate(sister);
                            sister = parent_node(check)->left;
                        }
                        sister->color = parent_node(check)->color;
                        if (sister->left != nullptr)
                            sister->left->color = BLACK;
                        parent_node(check)->color = BLACK;
                        right_rotate(parent_node(check));
                        check = root;
                    }
                }
            }
            check->color = BLACK;
        }
        inline void pre_order(unsigned int index, const unsigned int offset, node* node, const unsigned int level, system_stream* out) const {
            if (node == nullptr) { return; }
            // 树放入数组中，由两个指标表示下标
            // 一个是父节点的下标，一个是父节点的左子（1）还是右子（2）
            // 既，根节点默认0，0
            // 这样父节点的下标乘以2，再加上一个数，即为本节点在数组中的下标
            index = index * 2 + offset;

            out->append("[%4u]{level:%2u,\tcolor:%s\t,value:",
                        index, level, node->color ? "Black\0" : "Red\0");
            node->value->serialize(out);
            out->append("}\n");

            pre_order(index, 1, node->left, level + 1, out);
            pre_order(index, 2, node->right, level + 1, out);
        }
        node* root;
        inline bool template_check(hickey* const data) const { auto* s = new SERIAL(); return s->sign() == data->sign(); }
    public:
        red_black_tree() { root = nullptr; }
        ~red_black_tree() override { delete root; }
        void rb_insert(hickey* value) {
            if(!template_check(value)) { return; }
            auto* new_node = new node(value);
            if (root == nullptr) {
                new_node->color = BLACK;
                root = new_node;
            }

            node* current = root;
            node* temp = current;
            for (; current != nullptr;) {
                temp = current;
                if (current->value->hash() > value->hash()) {
                    current = current->left;
                } else if (current->value->hash() < value->hash()) {
                    current = current->right;
                } else {
                    return;
                }
            }

            if (temp->value->hash() > value->hash()) {
                temp->left = new_node;
            } else {
                temp->right = new_node;
            }
            new_node->parent = temp;
            fix_after_append(new_node);
        }
        void rb_delete(int hash_value) {
            node* delete_node = found(hash_value);
            if (delete_node == nullptr) { return; } //NOLINT 主要是消除抛出异常抛的是一个指针和类型没有继承标准库中的
            if (delete_node->left != nullptr && delete_node->right != nullptr) {
                node* temp = successor(delete_node);
                temp->value->clone(delete_node->value);
                delete_node = temp;
            }
            node* replacement = delete_node->left == nullptr ? delete_node->right : delete_node->left;
            if (replacement == nullptr) {
                if (delete_node->parent == nullptr) {
                    root = nullptr;
                } else {
                    if (BLACK == delete_node->color) {
                        fix_after_subtract(delete_node);
                    }
                    if (delete_node == parent_node(delete_node)->left) {
                        parent_node(delete_node)->left = nullptr;
                    } else {
                        parent_node(delete_node)->right = nullptr;
                    }
                    delete_node->parent = nullptr;
                }
            } else {
                replacement->color = BLACK;
                replacement->parent = parent_node(delete_node);
                if (delete_node->parent == nullptr) {
                    root = replacement;
                } else if (delete_node == parent_node(delete_node)->left) {
                    parent_node(delete_node)->left = replacement;
                } else {
                    parent_node(delete_node)->right = replacement;
                }
                delete_node->parent = nullptr;
                delete_node->left = nullptr;
                delete_node->right = nullptr;
            }
            // 注意此处将数据部分的内存进行了回收，不需要再手动删除find找到的指针
            delete delete_node;
        }
        SERIAL* find(int hash_value) {
            node* new_node = found(hash_value);
            if (new_node == nullptr) { return nullptr; } //NOLINT 主要是消除抛出异常抛的是一个指针和类型没有继承标准库中的
            return (SERIAL*)new_node->value;
        }
        void scanning() const {
            auto* out = new system_stream(15u);
            out->start(1u << 2u);
            out->append("\n");
            pre_order(0u, 0, root, 1u, out);
            out->end();
        }
        bool equals(const hickey* target) const override { return target == this; }
        int hash() const override { return 0; }
        int clone(hickey*& target) const override { return 0; }
        unsigned int sign() const override { return 0; }
        int serialize(hickey* sys) const override { return 0; }
    };

    class iterable : public hickey {
    protected:
        iterable() = default;
        class iterator {
        public:
            iterator() = default;
            virtual ~iterator() = default;
            virtual hickey* next() { return nullptr; }
            virtual bool last() { return true; }
        };
    public:
        virtual iterator* iter() const { return new iterator(); }
        ~iterable() override = default;
    };

    // 栈，需要实现hickey接口，且确保实现了sign serialize用于保证集合的特性
    template<class SERIAL>
    class stack final : public iterable {
    private:
        class node {
        public:
            hickey* value;
            node* next;
            explicit node(hickey* value = new SERIAL()) : value(value) { next = nullptr; }
            ~node() { delete next; delete value; }
        };
        node* head;
        class ite : public iterator {
        private:
            node* flow;
        public:
            hickey* next() override { flow = flow->next; return flow->value; }
            bool last() override { return flow->next == nullptr; }
            explicit ite(node* head) : flow(head) {}
            ~ite() override = default;
        };
        inline bool check_serialize(const hickey* const sys) const { auto* o = new system_stream(); return o->sign() == sys->sign(); }
    public:
        iterator* iter() const override { return new ite(head); }
        SERIAL* iter_replace(hickey* value) const { return (SERIAL*)value; } //NOLINT
        void push(hickey* value) { auto* v = new node(value); v->next = head->next; head->next = v; }
        void pop() { auto* v = head->next; head->next = v->next; v->next = nullptr; delete v; }
        stack() { head = new node(); }
        ~stack() override { delete head; }
        int hash() const override { return 0; }
        bool equals(const hickey* const target) const override { if(check_conversion(target)) { return this == target; } return false; }
        unsigned int sign() const override { return 0; }
        int clone(hickey*& target) const override {
            if(target == nullptr) { return 0; }
            if(check_conversion(target)) {
                if(this == target) {
                    target = new stack<SERIAL>();
                    auto* tst = new stack<SERIAL>();
                    for(node* tstn = head->next; tstn != nullptr; tstn = tstn->next) {
                        auto* tss = new SERIAL();
                        tstn->value->clone(reinterpret_cast<hickey*&>(tss));
                        tst->push(tss);
                    }
                    auto* tsti = tst->iter();
                    for(;!tsti->last();) {
                        auto* tss = new SERIAL();
                        iter_replace(tsti->next())->clone(reinterpret_cast<hickey*&>(tss));
                        ((stack<SERIAL>*)target)->push(tss);
                    }
                    delete tsti;
                    delete tst;
                    return 2;
                } else {
                    delete target;
                    target = new stack<SERIAL>();
                    auto* tst = new stack<SERIAL>();
                    for(node* tstn = head; tstn->next != nullptr; tstn = tstn->next) {
                        if(tstn == head) { continue; }
                        auto* tss = new SERIAL();
                        tstn->value->clone(reinterpret_cast<hickey*&>(tss));
                        tst->push(tss);
                    }
                    auto* tsti = tst->iter();
                    for(;!tsti->last();) {
                        auto* tss = new SERIAL();
                        iter_replace(tsti->next())->clone(reinterpret_cast<hickey*&>(tss));
                        ((stack<SERIAL>*)target)->push(tss);
                    }
                    delete tsti;
                    delete tst;
                    return 1;
                }
            } else { return 0; }
        }
        int serialize(hickey *sys) const override {
            if(check_serialize(sys)) {
                auto* out = (system_stream*)sys;
                out->append("\n[ ");
                iterator* ite = iter();
                for(;!ite->last();) {
                    hickey* u = ite->next();
                    if(!u->equals(head->next->value)) { out->append(", \n"); }
                    u->serialize(out);
                }
                out->append(" ]\n");
            }
            return 1;
        }
    };

    namespace {
        //
        // 对于一些很难受的警告可以使用注释 //NOLINT 来消除
        // 明知代码没有问题，规范上也说得过去
        //
        class utils final {
        private:
            utils() = default;
            ~utils() = default;
            utils& operator=(utils&)  = default;
            utils(const utils&) = default;
            utils& operator=(utils&&)  = default;
            utils(utils&&) = default;
            static utils* u;
        public:
            static utils* signal() { return u; }
            inline unsigned int hash_code(const char* key) const { //NOLINT
                unsigned int result;
                unsigned char* byte;
                for (result = 0, byte = (unsigned char*)key; *byte; byte++) {
                    result = result * 31 + *byte;
                }
                return result;
            }
            inline std::vector<std::string> spilt(std::string str, const std::string& pattern) const { //NOLINT
                std::string::size_type pos;
                std::vector<std::string> result;
                str += pattern;
                unsigned int size = str.size();
                for (unsigned int i = 0; i < size; i++) {
                    pos = str.find(pattern, i);
                    if (pos < size) {
                        std::string s = str.substr(i, pos - i);
                        result.push_back(s);
                        i = pos + pattern.size() - 1;
                    }
                }
                return result;
            }
            inline unsigned int encode(const char* key) const { //NOLINT
                // 由于数据大小的限制，27进制最大只能存7位
                // 4294967295
                // b28jpdl  标准编码数
                // 为下划线和26个字母，对应应用于类的标识，由于类名一般不短，需摘要部分
                // 固，保证全覆盖，key只能为6位，且不允许下划线开头
                unsigned int result;
                unsigned char* byte;
                for (result = 0, byte = (unsigned char*)key; *byte; byte++) {
                    if ((*byte - 96) > 0 && (*byte - 96) < 27 ) {
                        result = result * 27 + *byte - 96;
                    } else if (*byte == 95) {
                        result = result * 27;
                    } else {
                        return 0;
                    }
                }
                return result;
            }
            inline int decode(unsigned int secret, std::string* key) const { //NOLINT
                int stack[6];
                for (int& i : stack) { i = -1; }
                if (secret == 0) { return 0; }
                int s = 0;
                for(unsigned int i = secret; i > 0; i = i / 27) {
                    stack[s++] = static_cast<int>(i % 27u);
                }
                for(s--; s >= 0; s--) {
                    if(stack[s] == 0) {
                        key->append("_");
                    } else {
                        key->push_back(static_cast<char>(stack[s] + 96));
                    }
                }
                return 1;
            }
        };
        #ifdef COMPONENT_H
        #define UTL ({ utils::signal(); })
        utils* utils::u = new utils(); //NOLINT
        #endif //COMPONENT_H

        //用于测试用例一、二
        class user final : public hickey {
        private:
            int id;
            std::string* name;
            virtual inline bool check_serialize(const hickey* const sys) const { auto* o = new system_stream(); return o->sign() == sys->sign(); }
        public:
            explicit user(int id = 0, const char* n = "") : id(id) { name = new std::string(n); }
            ~user() override { delete name; }
            unsigned int sign() const override { return 0; }
            bool equals(const hickey* const target) const override { if(check_conversion(target)) { return ((user*)target)->id == id && *((user*)target)->name == *name; } return false; }
            int hash() const override { return id; }
            int clone(hickey*& target) const override { if(target == nullptr) { return 0; } if(check_conversion(target)) { if(this == target) { target = new user(id, name->c_str()); return 2; } else { delete target; target = new user(id, name->c_str()); return 1; } } else { return 0; } }
            int serialize(hickey* sys) const override { if(check_serialize(sys)) { auto* out = (system_stream*)sys; out->append("{ 'class-name' : 'user', 'class-member' : { 'id' : %d, 'name' : '%s' }, 'direction' : 'bean' }", id, name->c_str()); return 1; } return 0; }
        };
        //测试用例一，红黑树测试
        int test_tree() {
            auto* out = new system_stream(1u,1u);
            auto* tree = new red_black_tree<user>();
            tree->rb_insert(new user(1,"alice"));
            tree->rb_insert(new user(2));
            tree->rb_insert(new user(3));
            tree->rb_insert(new user(4));
            tree->rb_insert(new user(5));
            tree->rb_insert(new user(6));
            tree->rb_insert(new user(7));
            tree->rb_insert(new user(8));
            tree->rb_insert(new user(9));
            auto* u = tree->find(1);
            tree->rb_delete(9);
            tree->scanning();
            out->end();
            delete tree;
            u->hash();
            return 1;
        }
        //测试用例二，栈测试
        int test_stack() {
            auto* st = new stack<user>();
            st->push(new user(1,"alice"));
            st->push(new user(2));
            st->push(new user(3));
            st->push(new user(4));
            st->push(new user(5));
            st->pop();
            auto* out = new system_stream(1u,1u);
            st->serialize(out);
            out->end();
            stack<user>* sstt = st;
            //如果不实用clone，则会出现内存被释放的情况，有可能会有double free风险
            st->clone(reinterpret_cast<hickey*&>(sstt));
            out->maybe(1u);
            sstt->serialize(out);
            out->end();
            delete sstt;
            out->start(1u);
            st->serialize(out);
            out->end();
            delete st;
            delete out;
            return 1;
        }
        //用于测试用例三
        class file_stream final : public system_stream {
        private:
            std::ofstream* out_write;
            void warning() const override {
                if (out_write->is_open()) {
                    unsigned long long tmp = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
                    upgrade(buffer, ">-\t[%02d:%02d:%02d %03dms%03dus%03dns]", time_hour(tmp), time_minute(tmp), time_second(tmp), time_micro(tmp), time_milli(tmp), time_nano(tmp));
                    *buffer << stream->str();
                    upgrade(buffer, " <\n");
                    *out_write << buffer->str();
                    buffer->clear();
                    buffer->str("");
                }
            }
            void error() const override {
                if (out_write->is_open()) {
                    unsigned long long tmp = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
                    upgrade(buffer, ">*\t[%02d:%02d:%02d %03dms%03dus%03dns]", time_hour(tmp), time_minute(tmp), time_second(tmp), time_micro(tmp), time_milli(tmp), time_nano(tmp));
                    *buffer << stream->str();
                    upgrade(buffer, " <\n");
                    *out_write << buffer->str();
                    buffer->clear();
                    buffer->str("");
                }
            }
        public:
            explicit file_stream(unsigned int ooo = 1u, unsigned int mode = 0, const char* file = nullptr) : system_stream(ooo, mode) { if(file == nullptr) { out_write = new std::ofstream("../kuu/test.txt", std::ios::out); } else { out_write = new std::ofstream(file, std::ios::out); } }
            ~file_stream() override { out_write->close(); delete out_write; }
            unsigned int sign() const override { return 0; }
        };
        //测试用例三，文件流测试
        int test_file() {
            auto* fs = new file_stream(3u, 3u);
            fs->append("\nおはようございます，\n私は今日も頑張ってします，\nどうぞよろしくお願いいたします。\n");
            fs->end();
            fs->maybe(2u);
            fs->append("\n\n");
            fs->end();
            delete fs;
            return 1;
        }
    }

    int component_run_main() {
        test_tree();
        test_stack();
        test_file();
        return 0;
    }
}

#endif //COMPONENT_H
