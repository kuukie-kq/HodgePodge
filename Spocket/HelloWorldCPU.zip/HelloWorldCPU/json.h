//
// Created by Admin on 2022/9/6.
//

#ifndef COMPONENT_JSON_H
#define COMPONENT_JSON_H

#include "System.h"

namespace kuu {
    //
    // 对于一些很难受的警告可以使用注释 //NOLINT 来消除
    // 明知代码没有问题，规范上也说得过去
    //
    class utils final {
    private:
        utils() = default;

        ~utils() = default;

        utils &operator=(utils &) = default;

        utils(const utils &) = default;

        utils &operator=(utils &&) = default;

        utils(utils &&) = default;

        static utils *u;
    public:
        static utils *signal() { return u; }

        inline unsigned int hash_code(const char *key) const { //NOLINT
            unsigned int result;
            unsigned char *byte;
            for (result = 0, byte = (unsigned char *) key; *byte; byte++) {
                result = result * 31 + *byte;
            }
            return result;
        }

        inline std::vector<std::string> spilt(std::string str, const std::string &pattern) const { //NOLINT
            std::string::size_type pos;
            std::vector<std::string> result;
            str += pattern;
            unsigned int size = str.size();
            for (unsigned int i = 0; i < size; i++) {
                pos = str.find(pattern, i);
                if (pos < size) {
                    std::string s = str.substr(i, pos - i);
                    result.push_back(s);
                    i = pos + pattern.size() - 1;
                }
            }
            return result;
        }

        inline unsigned int encode(const char *key) const { //NOLINT
            // 由于数据大小的限制，27进制最大只能存7位
            // 4294967295
            // b28jpdl  标准编码数
            // 为下划线和26个字母，对应应用于类的标识，由于类名一般不短，需摘要部分
            // 固，保证全覆盖，key只能为6位，且不允许下划线开头
            unsigned int result;
            unsigned char *byte;
            for (result = 0, byte = (unsigned char *) key; *byte; byte++) {
                if ((*byte - 96) > 0 && (*byte - 96) < 27) {
                    result = result * 27 + *byte - 96;
                } else if (*byte == 95) {
                    result = result * 27;
                } else {
                    return 0;
                }
            }
            return result;
        }

        inline int decode(unsigned int secret, std::string *key) const { //NOLINT
            int stack[6];
            for (int &i : stack) { i = -1; }
            if (secret == 0) { return 0; }
            int s = 0;
            for (unsigned int i = secret; i > 0; i = i / 27) {
                stack[s++] = static_cast<int>(i % 27u);
            }
            for (s--; s >= 0; s--) {
                if (stack[s] == 0) {
                    key->append("_");
                } else {
                    key->push_back(static_cast<char>(stack[s] + 96));
                }
            }
            return 1;
        }
    };

    utils *utils::u = new utils(); //NOLINT
}

namespace sun {
    enum TypeCode {
        INT = 11u,
        DOUBLE = 15u,
        STRING = 18u,
        KV_OBJECT = 21u
    };

    bool stream_check(kuu::hickey* target) { return target->sign() == 1u; }
    kuu::system_stream* stream_replace(kuu::hickey* target) { return (kuu::system_stream*)target; }

    //
    // Type
    // 数据类型部分
    //

    class Int final : public kuu::hickey {
    private:
        int value;
    public:
        explicit Int(const int value = 0) : value(value) {}
        ~Int() override = default;
        void set(const int val) { value = val; }
        int get() const { return value; }
        unsigned int sign() const override { return TypeCode::INT; }
        int hash() const override { return value; }
        bool equals(const hickey* const target) const override { if(check_conversion(target)) { return value == ((Int*)target)->get(); } return false; }
        int clone(hickey*& target) const override { if(target != nullptr) { if(check_conversion(target)) { if(target == this) { target = new Int(value); return 2; } else { delete target; target = new Int(value); return 1; } } return 0; } return 0; }
        int serialize(hickey* sys) const override { if(!stream_check(sys)) return 0; auto* out = stream_replace(sys); out->append(" %d ", value); return 1; }
    };

    class Double final : public kuu::hickey {
    private:
        double value;
    public:
        explicit Double(const double value = 0) : value(value) {}
        ~Double() override = default;
        void set(const double val) { value = val; }
        double get() const { return value; }
        unsigned int sign() const override { return TypeCode::DOUBLE; }
        int hash() const override { return (int)value; }
        bool equals(const hickey* const target) const override { if(check_conversion(target)) { return value == ((Double*)target)->get(); } return false; }
        int clone(hickey*& target) const override { if(target != nullptr) { if(check_conversion(target)) { if(target == this) { target = new Double(value); return 2; } else { delete target; target = new Double(value); return 1; } } return 0; } return 0; }
        int serialize(hickey* sys) const override { if(!stream_check(sys)) return 0; auto* out = stream_replace(sys); out->append(" %f ", value); return 1; }
    };

    class String final : public kuu::hickey {
    private:
        std::string* value;
    public:
        explicit String(const char* val = "") { value = new std::string(val); }
        ~String() override { delete value; }
        void set(const char* val) { value->clear(); value->append(val); }
        std::string* get() const { return value; }
        unsigned int sign() const override { return TypeCode::STRING; }
        int hash() const override { return (int)kuu::utils::signal()->hash_code(value->c_str()); }
        bool equals(const hickey* const target) const override { if(check_conversion(target)) { return *value == *((String*)target)->get(); } return false; }
        int clone(hickey*& target) const override { if(target != nullptr) { if(check_conversion(target)) { if(target == this) { target = new String(value->c_str()); return 2; } else { delete target; target = new String(value->c_str()); return 1; } } return 0; } return 0; }
        int serialize(hickey* sys) const override { if(!stream_check(sys)) return 0; auto* out = stream_replace(sys); out->append(" \"%s\" ", value->c_str()); return 1; }
    };

    kuu::hickey* create_default(TypeCode sign) {
        switch (sign) {
            case INT:
                return new Int();
            case DOUBLE:
                return new Double();
            case STRING:
                return new String();
            default:
                return nullptr;
        }
    }

    class KVObject final : public kuu::hickey {
    private:
        String* key;
        kuu::hickey* value;
    public:
        explicit KVObject(const char* k = "", kuu::hickey* v = new Int()) : value(v) { key = new String(k); }
        ~KVObject() override { delete key; delete value; }
        unsigned int sign() const override { return TypeCode::KV_OBJECT; }
        int hash() const override { return (int)kuu::utils::signal()->hash_code(key->get()->c_str()); }
        bool equals(const hickey* const target) const override { if(check_conversion(target)) { return key->equals(((KVObject*)target)->key) && value->equals(((KVObject*)target)->value); } return false; }
        int clone(hickey*& target) const override { if(target != nullptr) { if(check_conversion(target)) { if(target == this) { auto* tmp = create_default(static_cast<TypeCode>(value->sign())); value->clone(tmp); target = new KVObject(key->get()->c_str(), tmp); return 2; } else { delete target; auto* tmp = create_default(static_cast<TypeCode>(value->sign())); value->clone(tmp); target = new KVObject(key->get()->c_str(), tmp); return 1; } } return 0; } return 0; }
        int serialize(hickey* sys) const override { if(!stream_check(sys)) return 0; auto* out = stream_replace(sys); key->serialize(out); out->append(" : "); value->serialize(out); return 1; }
    };

    template<class SERIAL>
    class List final : public kuu::iterable {
    private:
        class node {
        public:
            hickey* value;
            node* next;
            explicit node(hickey* value = new SERIAL()) : value(value) { next = nullptr; }
            ~node() { delete next; delete value; }
        };
        node* head;
        class ite : public iterator {
        private:
            node* flow;
        public:
            hickey* next() override { flow = flow->next; return flow->value; }
            bool last() override { return flow->next == nullptr; }
            explicit ite(node* head) : flow(head) {}
            ~ite() override = default;
        };
        bool array;
    public:
        iterator* iter() const override { return new ite(head); }
        SERIAL* iter_replace(hickey* value) const { return (SERIAL*)value; }
        void push(hickey* value) { if(value->sign() != head->value->sign()) return; auto* v = new node(value); node* h = head; for(;h->next != nullptr; h = h->next) {} h->next = v; }
        void pop() { auto* v = head->next; head->next = v->next; v->next = nullptr; delete v; }
        explicit List(bool array = false) : array(array) { head = new node(); }
        ~List() override { delete head; }
        int hash() const override { return 0; }
        bool equals(const hickey* const target) const override { if(check_conversion(target)) { return this == target; } return false; }
        unsigned int sign() const override { return 0; }
        int clone(hickey*& target) const override {
            if(target == nullptr) { return 0; }
            if(check_conversion(target)) {
                if(this == target) {
                    target = new List<SERIAL>();
                    auto* tsti = iter();
                    for(;!tsti->last();) {
                        auto* tss = new SERIAL();
                        iter_replace(tsti->next())->clone(reinterpret_cast<hickey*&>(tss));
                        ((List<SERIAL>*)target)->push(tss);
                    }
                    delete tsti;
                    return 2;
                } else {
                    delete target;
                    target = new List<SERIAL>();
                    auto* tsti = iter();
                    for(;!tsti->last();) {
                        auto* tss = new SERIAL();
                        iter_replace(tsti->next())->clone(reinterpret_cast<hickey*&>(tss));
                        ((List<SERIAL>*)target)->push(tss);
                    }
                    delete tsti;
                    return 1;
                }
            } else { return 0; }
        }
        int serialize(hickey *sys) const override {
            if(stream_check(sys)) {
                auto* out = stream_replace(sys);
                iterator* ite = iter();
                out->append("%c", array ? '[' : '{');
                for(;!ite->last();) {
                    hickey* u = ite->next();
                    if(!u->equals(head->next->value)) { out->append(", "); }
                    u->serialize(out);
                }
                out->append("%c", array ? ']' : '}');
            }
            return 1;
        }
    };

    class JsonObject final : public kuu::hickey {
    public:
        List<KVObject>* data;
        JsonObject() { data = new List<KVObject>(); }
        ~JsonObject() override { delete data; }
        int serialize(hickey *sys) const override {
            if (!stream_check(sys)) return 0;
            auto* out = stream_replace(sys);
            data->serialize(out);
            return 1;
        }
    };
}

int test_json() {
#ifdef _TEST_FILE
    test_system_main();
#endif
    auto* jo = new sun::JsonObject();
    jo->data->push(new sun::KVObject("class",new sun::String("JAVA")));
    jo->data->push(new sun::KVObject("version",new sun::Double(1.1)));
    auto* jo_ls = new sun::List<sun::String>(true);
    jo_ls->push(new sun::String("one"));
    jo_ls->push(new sun::String("two"));
    jo_ls->push(new sun::String("three"));
    jo->data->push(new sun::KVObject("param-name",jo_ls));
    auto* jo_li = new sun::List<sun::Int>(true);
    jo_li->push(new sun::Int(1));
    jo_li->push(new sun::Int(2));
    jo_li->push(new sun::Int(3));
    jo->data->push(new sun::KVObject("param",jo_li));

    auto* out = new kuu::system_stream(1u,1u);
    out->append("\n");
    jo->serialize(out);
    out->append("\n");
    out->end();

    delete out;
    delete jo;
    return 1;
}

#endif //COMPONENT_JSON_H
