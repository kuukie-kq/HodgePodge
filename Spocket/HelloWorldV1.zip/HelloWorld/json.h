#ifndef KO_KO_JSON_H
#define KO_KO_JSON_H
// ====  ====
#include "system.h"
// ====  ====
namespace sys {
    enum {
        QUEUE_KO = 23u,
        STACK_KO = 24u,
        INT_KO = 21601,
        STRING_KO = 21609,
        MAP_NODE_KO = 21610,
        MAP_KO = 21611,
        ARRAY_NODE_KO = 21612,
        ARRAY_KO = 21613,
    };

    Object *new_default_instance(u4int type);

    int analysis(const std::string &json_string, void*& json_object);

    class LinkedNode { //NOLINT
    private:
        friend class Stack;
        friend class Queue;
        friend class Map;
        friend class Array;
        friend int analysis(const std::string &json_string, void*& json_object);

        Object *value;
        LinkedNode *next;
    public:
        explicit LinkedNode(Object *value = new Object());
        ~LinkedNode();
    };

    class Stack : public Object {
    private:
        friend int analysis(const std::string &json_string, void*& json_object);
        LinkedNode *head;
        u4int type;
    public:
        explicit Stack(u4int type = OBJECT_KO);
        ~Stack() override;
        s4int s_insert(Object *value);
        Object *s_delete();
        u4int sign() const override;
        s4int serialize(Hickey *sys) const override;
    };

    class Queue : public Object {
    private:
        friend class Map;
        friend class Array;
        LinkedNode *head;
        u4int type;
    public:
        explicit Queue(u4int type = OBJECT_KO);
        ~Queue() override;
        s4int q_insert(Object *value);
        Object *q_delete();
        u4int sign() const override;
        s4int clone(Hickey *&target) const override;
        s4int serialize(Hickey *sys) const override;
    };

    class Int : public Object {
    private:
        s4int i;
    public:
        explicit Int(int i = 0);
        ~Int() override = default;
        u4int sign() const override;
        bool equals(const Hickey *const target) const override; //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override;
        s4int serialize(Hickey *sys) const override;
    };

    class String : public Object {
    private:
        std::string *s;
    public:
        explicit String(const char *c = "");
        ~String() override;
        u4int sign() const override;
        bool equals(const Hickey *const target) const override; //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override;
        s4int serialize(Hickey *sys) const override;
    };

    class MapNode : public Object {
    private:
        friend class Map;
        friend class JsonObject;
        Object *key;
        Object *value;
    public:
        explicit MapNode(Object *key = new Object(), Object *value = new Object());
        ~MapNode() override;
        u4int sign() const override;
        bool equals(const Hickey *const target) const override; //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override;
        s4int serialize(Hickey *sys) const override;
    };

    class Map : public Object {
    private:
        Queue *item;
        RedBlackTree *index;
        static const s4int MAP_REDBLACKTREE_NODE = 114514;
        class MRBTN final : public Object {
        public:
            int hash_code;
            void* value_node;
            explicit MRBTN(int hash_code = 0, MapNode* value_node = nullptr);
            ~MRBTN() override;
            u4int sign() const override;
            s4int clone(Hickey *&target) const override;
            s4int hash() const override;
            s4int serialize(Hickey *sys) const override;
        };
    public:
        Map();
        ~Map() override;
        s4int m_insert(String *k, Object *v);
        s4int m_delete(s4int hash_value);
        Object* m_find(s4int hash_value);
        u4int sign() const override;
        bool equals(const Hickey *const target) const override { return false; } //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override { return 0; }
        s4int serialize(Hickey *sys) const override;
        s4int insert(Object *add_item);
    };

    class ArrayNode : public Object {
    private:
        friend class Array;
        friend class JsonObject;
        Object *key;
        Object *value;
    public:
        explicit ArrayNode(Object *key = new Object(), Object *value = new Object());
        ~ArrayNode() override;
        u4int sign() const override;
        bool equals(const Hickey *const target) const override; //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override;
        s4int serialize(Hickey *sys) const override;
    };

    class Array : public Object {
    private:
        Queue *item;
        static const s4int MAX_LENGTH = 1024;
        static const s4int ARRAY_LIST_NODE = 114515;
        class ALN final {
        public:
            ArrayNode** array;
            ALN() { array = new ArrayNode*[MAX_LENGTH](); }
            ~ALN() { delete array; }
        };
        s4int size;
        ALN* index;
    public:
        Array();
        ~Array() override;
        s4int a_insert(ArrayNode *v);
        s4int a_delete(s4int fifo_index);
        Object* a_find(s4int fifo_index);
        u4int sign() const override;
        bool equals(const Hickey *const target) const override { return false; } //NOLINT
        s4int clone(Hickey *&target) const override;
        s4int hash() const override { return size; }
        s4int serialize(Hickey *sys) const override;
        s4int insert(Object *add_item);
    };
}
// ====  ====
#if KO_KO_SRC_H
namespace sys {
    Object* new_default_instance(u4int type) {
        switch (type) {
            case INT_KO:
                return new Int();
            case STRING_KO:
                return new String();
            case MAP_NODE_KO:
                return new MapNode();
            case ARRAY_NODE_KO:
                return new ArrayNode();
            default:
                return new Object();
        }
    }

    int analysis(const std::string &json_string, void*& json_object) {
        if (json_object == nullptr || !(((Object*)json_object)->sign() == ARRAY_KO || ((Object*)json_object)->sign() == MAP_KO)) { return 0; }
        //
        std::string::const_iterator cit = json_string.begin();
#ifdef __linux__
        if ('{' == *cit) {
            delete (Map*)json_object;
            json_object = nullptr;
            json_object = new Map();
        } else if ('[' == *cit) {
            delete (Map*)json_object;
            json_object = nullptr;
            json_object = new Array();
        }
#endif
        int level = 0;
        auto* stack = new Stack(STRING_KO);
        String* top = nullptr;
        void* object = json_object;
        auto* stack_object = new Stack(OBJECT_KO);
        auto* stack_string = new Stack(STRING_KO);
        stack_object->s_insert(reinterpret_cast<Object*>(json_object));
        stack_string->s_insert(new String("main"));
        bool mode_string = false;
        bool key_or_value = true;
        Object* str_kv[2];
        str_kv[0] = nullptr;
        str_kv[1] = nullptr;
        int type = INT_KO;
        std::string str;
        str.clear();
        //
        for(;cit != json_string.end();) {
            if (mode_string) { if ('"' == *cit) { mode_string = false; type = STRING_KO; } else { str.push_back(*cit); } } else {
                if (' ' == *cit) {} else if ('"' == *cit) {
                    mode_string = true;
                } else if (':' == *cit) {
                    if (!(key_or_value && type == STRING_KO)) { return 0; }
                    str_kv[0] = new String(str.c_str());
                    key_or_value = false;
                    str.clear();
                    type = INT_KO;
                } else if ('.' == *cit) {
                    if (type != INT_KO) { return 0; }
                    type = INT_KO; //Code_K::DOUBLE;
                    str.push_back(*cit);
                } else if (',' == *cit) {
                    if (str.empty() && key_or_value) {
                        auto* tmp_object = new Object();
                        str_kv[0] = new String();
                        if (stack_object->head->value->hash() == MAP_KO) {
                            delete tmp_object;
                            tmp_object = new Map();
                        } else if (stack_object->head->value->hash() == ARRAY_KO) {
                            delete tmp_object;
                            tmp_object = new Array();
                        }
                        stack_string->head->value->clone(reinterpret_cast<Hickey*&>(str_kv[0]));
                        stack_object->head->value->clone(reinterpret_cast<Hickey*&>(tmp_object));
                        stack_object->s_delete();
                        stack_string->s_delete();
                        if (String("a*i*o").equals(str_kv[0])) {
                            ((Array*)object)->insert(tmp_object);
                            delete str_kv[0];
                        } else {
                            ((Map*)object)->insert(new MapNode(str_kv[0], tmp_object));
                        }
                        tmp_object = nullptr;
                    } else {
                        switch (type) {
                            case STRING_KO:
                                str_kv[1] = new String(str.c_str());
                                break;
                            case INT_KO:
                                str_kv[1] = new Int(atoi(str.c_str())); //NOLINT
                                break;
                            default:
                                return 0;
                        }
                        if (key_or_value) {
                            ((Array*)object)->insert(str_kv[1]);
                        } else {
                            ((Map*)object)->insert(new MapNode(str_kv[0], str_kv[1]));
                        }
                    }
                    key_or_value = true;
                    str.clear();
                    type = INT_KO;
                    str_kv[0] = nullptr;
                    str_kv[1] = nullptr;
                } else if ('{' == *cit) {
                    level = level + 1;
                    if (level != 1 && !key_or_value) {
                        str.clear();
                        auto* lok = new Map();
                        stack_object->s_insert(lok);
                        object = lok;
                        stack_string->s_insert(str_kv[0]);
                        str_kv[0] = nullptr;
                        str_kv[1] = nullptr;
                        key_or_value = true;
                    } else if (top != nullptr && ((String*)stack->head->value)->equals(top)) {
                        //
                        str.clear();
                        auto* lok = new Map();
                        stack_object->s_insert(lok);
                        object = lok;
                        stack_string->s_insert(new String("a*i*o"));
                        str_kv[0] = nullptr;
                        str_kv[1] = nullptr;
                        key_or_value = true;
                    }
                    std::string s = std::to_string(level);
                    s.append("<{>");
                    stack->s_insert(new String(s.c_str()));
                    top = (String*)stack->head->value;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                } else if ('}' == *cit) {
                    std::string s = std::to_string(level);
                    s.append("<{>");
                    if (str.empty() && key_or_value) {
                        auto* tmp_object = new Object();
                        str_kv[0] = new String();
                        stack_string->head->value->clone(reinterpret_cast<Hickey*&>(str_kv[0]));
                        stack_object->head->value->clone(reinterpret_cast<Hickey*&>(tmp_object));
                        stack_object->s_delete();
                        stack_string->s_delete();
                        ((Map*)object)->insert(new MapNode(str_kv[0], tmp_object));
                    } else {
                        switch (type) {
                            case STRING_KO:
                                str_kv[1] = new String(str.c_str());
                                break;
                            case INT_KO:
                                str_kv[1] = new Int(atoi(str.c_str())); //NOLINT
                                break;
                            default:
                                return 0;
                        }
                        if (key_or_value) {
                            ((Array*)object)->insert(str_kv[1]);
                        } else {
                            ((Map*)object)->insert(new MapNode(str_kv[0], str_kv[1]));
                        }
                    }
                    key_or_value = true;
                    str.clear();
                    type = INT_KO;
                    str_kv[0] = nullptr;
                    str_kv[1] = nullptr;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                    level = level - 1;
                    stack->s_delete();
                    if (level != 0) { top = (String*)stack->head->value; }
                    if (level == 0) { if ((cit + 1) != json_string.end()) { return 0; } } else {
                        auto* ito = stack_object->head->next->value;
                        //if(ito->sign() != MAP_KO) { return 0; }
                        object = ito;
                    }
                } else if ('[' == *cit) {
                    level = level + 1;
                    if (level != 1 && !key_or_value) {
                        str.clear();
                        auto* lok = new Array();
                        stack_object->s_insert(lok);
                        object = lok;
                        stack_string->s_insert(str_kv[0]);
                        str_kv[0] = nullptr;
                        str_kv[1] = nullptr;
                        key_or_value = true;
                    }
                    std::string s = std::to_string(level);
                    s.append("<[>");
                    stack->s_insert(new String(s.c_str()));
                    top = (String*)stack->head->value;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                } else if (']' == *cit) {
                    std::string s = std::to_string(level);
                    s.append("<[>");
                    if (str.empty() && key_or_value) {
                        auto* tmp_object = new Object();
                        str_kv[0] = new String();
                        stack_string->head->value->clone(reinterpret_cast<Hickey*&>(str_kv[0]));
                        stack_object->head->value->clone(reinterpret_cast<Hickey*&>(tmp_object));
                        stack_object->s_delete();
                        stack_string->s_delete();
                        ((Array*)object)->insert(tmp_object);
                        delete str_kv[0];
                    } else {
                        switch (type) {
                            case STRING_KO:
                                str_kv[1] = new String(str.c_str());
                                break;
                            case INT_KO:
                                str_kv[1] = new Int(atoi(str.c_str())); //NOLINT
                                break;
                            default:
                                return 0;
                        }
                        if (key_or_value) {
                            ((Array*)object)->insert(str_kv[1]);
                        } else {
                            ((Map*)object)->insert(new MapNode(str_kv[0], str_kv[1]));
                        }
                    }
                    key_or_value = true;
                    str.clear();
                    type = INT_KO;
                    str_kv[0] = nullptr;
                    str_kv[1] = nullptr;
                    if (!String(s.c_str()).equals(top)) { return 0; }
                    level = level - 1;
                    stack->s_delete();
                    if (level != 0) { top = (String*)stack->head->value; }
                    if (level == 0) { if ((cit + 1) != json_string.end()) { return 0; } } else {
                        auto* ito = stack_object->head->next->value;
                        //if(ito->sign() != ARRAY_KO) { return 0; }
                        object = ito;
                    }
                } else {
                    str.push_back(*cit);
                }
            }
            cit++;
        }
        //
        delete stack;
        top = nullptr;
        object = nullptr;
        str_kv[0] = nullptr;
        str_kv[1] = nullptr;
        stack_object = nullptr;
        stack_string = nullptr;
        return 1;
    }

    // ====  ====

    LinkedNode::LinkedNode(Object *value) : value(value) { next = nullptr; }

    LinkedNode::~LinkedNode() {
        delete next;
        delete value;
    }

    // ====  ====

    Stack::Stack(u4int type) : type(type) { head = nullptr; }

    Stack::~Stack() { delete head; }

    s4int Stack::s_insert(Object *value) {
        auto *node = new LinkedNode(value);
        node->next = head;
        head = node;
        return 1;
    }

    Object * Stack::s_delete() {
        if (head == nullptr) { return nullptr; }
        LinkedNode *node = head;
        head = node->next;
        node->next = nullptr;
        auto *v = node->value;
        auto *r = new_default_instance(type);
        v->clone(reinterpret_cast<Hickey *&>(r));
        delete node;
        return r;
    }

    u4int Stack::sign() const { return STACK_KO; }

    s4int Stack::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        auto *h = head;
        for (int i = 0; h != nullptr; i++) {
            if (i != 0) { out->append(","); }
            h->value->serialize(out);
            h = h->next;
        }
        return 1;
    }

    // ====  ====

    Queue::Queue(u4int type) : type(type) { head = nullptr; }

    Queue::~Queue() { delete head; }

    s4int Queue::q_insert(Object *value) {
        if (head == nullptr) {
            head = new LinkedNode(value);
            return 1;
        }
        LinkedNode *last = head;
        for (; last->next != nullptr; last = last->next) {}
        last->next = new LinkedNode(value);
        return 1;
    }

    Object* Queue::q_delete() {
        if (head == nullptr) { return nullptr; }
        LinkedNode *node = head;
        head = node->next;
        node->next = nullptr;
        auto *v = node->value;
        auto *r = new_default_instance(type);
        v->clone(reinterpret_cast<Hickey *&>(r));
        delete node;
        return r;
    }

    u4int Queue::sign() const { return QUEUE_KO; }

    s4int Queue::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new Queue(type);
        for (LinkedNode *node = head; node != nullptr; node = node->next) {
            auto *v = new_default_instance(node->value->sign());
            node->value->clone(reinterpret_cast<Hickey *&>(v));
            ((Queue *) target)->q_insert(v);
        }
        return 1;
    }

    s4int Queue::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        auto *h = head;
        for (int i = 0; h != nullptr; i++) {
            if (i != 0) { out->append(","); }
            h->value->serialize(out);
            h = h->next;
        }
        return 1;
    }

    // ====  ====

    Int::Int(int i) : i(i) {}

    u4int Int::sign() const { return INT_KO; }

    bool Int::equals(const Hickey *const target) const {
        return sign() == target->sign() ? i == ((Int *) target)->i : false;
    }

    s4int Int::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new Int(i);
        return 1;
    }

    s4int Int::hash() const { return i; }

    s4int Int::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        out->append("%d", i);
        return 1;
    }

    // ====  ====

    String::String(const char *c) { s = new std::string(c); }

    String::~String() { delete s; }

    u4int String::sign() const { return STRING_KO; }

    bool String::equals(const Hickey *const target) const {
        return sign() == target->sign() ? *s == *((String *) target)->s : false;
    }

    s4int String::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new String(s->c_str());
        return 1;
    }

    s4int String::hash() const { return Util::u()->hash_code(s->c_str()); }

    s4int String::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        out->append("\"%s\"", s->c_str());
        return 1;
    }

    // ====  ====

    MapNode::MapNode(Object *key, Object *value) : key(key), value(value) {}

    MapNode::~MapNode() {
        delete value;
        delete key;
    }

    u4int MapNode::sign() const { return MAP_NODE_KO; }

    bool MapNode::equals(const Hickey *const target) const {
        return sign() == target->sign() ? key->equals(((MapNode *) target)->key) &&
                                          value->equals(((MapNode *) target)->value) : false;
    }

    s4int MapNode::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        auto *k = new_default_instance(key->sign());
        auto *v = new_default_instance(value->sign());
        key->clone(reinterpret_cast<Hickey *&>(k));
        value->clone(reinterpret_cast<Hickey *&>(v));
        target = new MapNode(k, v);
        return 1;
    }

    s4int MapNode::hash() const { return key->hash(); }

    s4int MapNode::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        key->serialize(out);
        out->append(":");
        value->serialize(out);
        return 1;
    }

    // ====  ====

    Map::MRBTN::MRBTN(int hash_code, MapNode *value_node) : hash_code(hash_code), value_node(value_node) {}

    Map::MRBTN::~MRBTN() { hash_code = 0; value_node = nullptr; }

    u4int Map::MRBTN::sign() const { return MAP_REDBLACKTREE_NODE; }

    s4int Map::MRBTN::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new MRBTN(hash_code,(MapNode*)value_node);
        return 1;
    }

    s4int Map::MRBTN::hash() const { return hash_code; }

    s4int Map::MRBTN::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        out->append("==== %d ==== 0x%X ====",hash_code, value_node);
        return 1;
    }

    Map::Map() {
        item = new Queue(MAP_NODE_KO);
        index = new RedBlackTree(MAP_REDBLACKTREE_NODE);
    }

    Map::~Map() {
        delete index;
        delete item;
    }

    s4int Map::m_insert(String *k, Object *v) {
        auto* node = new MapNode(k, v);
        item->q_insert(node);
        index->rbt_insert(new MRBTN(k->hash(),node));
        return 1;
    }

    s4int Map::m_delete(s4int hash_value) {
        auto* node = (MapNode*)m_find(hash_value);
        if (node == nullptr) { return 0; }
        index->rbt_delete(node->hash());
        return 1;
    }

    Object * Map::m_find(s4int hash_value) {
        auto* value_node = (MRBTN*)index->rbt_find(hash_value);
        if (value_node == nullptr) { return nullptr; }
        return (MapNode*)value_node->value_node;
    }

    u4int Map::sign() const { return MAP_KO; }

    s4int Map::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign() && target->sign() != OBJECT_KO) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new Map();
        auto* t = new Queue(MAP_NODE_KO);
        item->clone(reinterpret_cast<Hickey*&>(t));
        for(LinkedNode* tn = t->head; tn != nullptr; tn = tn->next) {
            ((Map*)target)->insert(tn->value);
            tn->value = nullptr;
        }
        delete t;
        return 1;
    }

    s4int Map::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        out->append("{");
        item->serialize(out);
        out->append("}");
        return 1;
    }

    s4int Map::insert(Object *add_item) {
        if (add_item->sign() != MAP_NODE_KO) { return 0; }
        item->q_insert(add_item);
        index->rbt_insert(new MRBTN(add_item->hash(),(MapNode*)add_item));
        return 1;
    }

    // ====  ====

    ArrayNode::ArrayNode(Object *key, Object *value) : key(key), value(value) {}

    ArrayNode::~ArrayNode() {
        delete value;
        delete key;
    }

    u4int ArrayNode::sign() const { return ARRAY_NODE_KO; }

    bool ArrayNode::equals(const Hickey *const target) const {
        return sign() == target->sign() ? key->equals(((ArrayNode *) target)->key) &&
                                          value->equals(((ArrayNode *) target)->value) : false;
    }

    s4int ArrayNode::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign()) { return 0; }
        if (this == target) { return 0; }
        delete target;
        auto *k = new_default_instance(key->sign());
        auto *v = new_default_instance(value->sign());
        key->clone(reinterpret_cast<Hickey *&>(k));
        value->clone(reinterpret_cast<Hickey *&>(v));
        target = new ArrayNode(k, v);
        return 0;
    }

    s4int ArrayNode::hash() const { return key->hash(); }

    s4int ArrayNode::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        value->serialize(out);
        return 1;
    }

    // ====  ====

    Array::Array() { item = new Queue(ARRAY_NODE_KO); size = 0; index = new ALN(); }

    Array::~Array() { delete item; }

    s4int Array::a_insert(ArrayNode *v) {
        if (size == MAX_LENGTH) { return 0; }
        item->q_insert(v);
        *(index->array+size) = v;
        size++;
        return 1;
    }

    s4int Array::a_delete(s4int fifo_index) {
        auto* node = (ArrayNode*)a_find(fifo_index);
        if (node == nullptr) { return 0; }
        bool move = false;
        for (int i = 0; i < size; i++) {
            if (move) {
                *(index->array+i-1) = *(index->array+i);
            }
            if ((*(index->array+i))->hash() == fifo_index) {
                move = true;
            }
        }
        size--;
        return 1;
    }

    Object * Array::a_find(s4int fifo_index) {
        if (fifo_index >= size) { return nullptr; }
        return *(index->array+fifo_index);
    }

    u4int Array::sign() const { return ARRAY_KO; }

    s4int Array::clone(Hickey *&target) const {
        if (target == nullptr) { return 0; }
        if (sign() != target->sign() && target->sign() != OBJECT_KO) { return 0; }
        if (this == target) { return 0; }
        delete target;
        target = new Array();
        item->clone(reinterpret_cast<Hickey *&>(((Array *) target)->item));
        ((Array *) target)->size = size;
        int i = 0;
        for (LinkedNode* n = ((Array *) target)->item->head;n != nullptr;n = n->next) {
            *(((Array *) target)->index->array+i) = (ArrayNode*)n->value;
            i++;
        }
        if (i != size) { return 0; }
        return 1;
    }

    s4int Array::serialize(Hickey *sys) const {
        if (sys->sign() != SYSTEM_STREAM_KO) { return 0; }
        auto *out = (SystemStream *) sys;
        out->append("[");
        item->serialize(out);
        out->append("]");
        return 1;
    }

    s4int Array::insert(Object *add_item) {
        //if (add_item->sign() == 0) { return 0; }
        a_insert(new ArrayNode(new Int(add_item->sign()), add_item));
        return 1;
    }

    // ====  ====

    class JsonObject {
    private:
        Object* map_or_array;
        Object* default_object;
    public:
        explicit JsonObject(u4int mode = 0u) { default_object = new Object(); if (mode == 0) { map_or_array = new Map(); } else { map_or_array = new Array(); } }
        ~JsonObject() { delete map_or_array; delete default_object; }
        s4int Add(const char* key, const char* value) {
            if (map_or_array->sign() == MAP_KO) {
                auto* map = (Map*)map_or_array;
                return map->m_insert(new String(key), new String(value));
            }
            return 0;
        }
        s4int Add(const char* key, int value) {
            if (map_or_array->sign() == MAP_KO) {
                auto* map = (Map*)map_or_array;
                return map->m_insert(new String(key), new Int(value));
            }
            return 0;
        }
        s4int Add(const char* key, JsonObject& value) {
            if (map_or_array->sign() == MAP_KO) {
                auto* map = (Map*)map_or_array;
                auto* object = new Object();
                value.map_or_array->clone(reinterpret_cast<Hickey *&>(object));
                if (object->sign() != MAP_KO && object->sign() != ARRAY_KO) { return 0; }
                return map->m_insert(new String(key), object);
            }
            return 0;
        }
        s4int Add(const char* value) {
            if (map_or_array->sign() == ARRAY_KO) {
                auto* array = (Array*)map_or_array;
                return array->a_insert(new ArrayNode(new Int(STRING_KO),new String(value)));
            }
            return 0;
        }
        s4int Add(int value) {
            if (map_or_array->sign() == ARRAY_KO) {
                auto* array = (Array*)map_or_array;
                return array->a_insert(new ArrayNode(new Int(INT_KO),new Int(value)));
            }
            return 0;
        }
        s4int Add(JsonObject& value) {
            if (map_or_array->sign() == ARRAY_KO) {
                auto* array = (Array*)map_or_array;
                auto* object = new Object();
                value.map_or_array->clone(reinterpret_cast<Hickey *&>(object));
                if (object->sign() != MAP_KO && object->sign() != ARRAY_KO) { return 0; }
                return array->a_insert(new ArrayNode(new Int(object->sign()), object));
            }
            return 0;
        }
        s4int AddEmptyObject(const char* key) {
            if (map_or_array->sign() == MAP_KO) {
                auto* map = (Map*)map_or_array;
                return map->m_insert(new String(key), new Map());
            }
            return 0;
        }
        s4int AddEmptyArray(const char* key) {
            if (map_or_array->sign() == MAP_KO) {
                auto* map = (Map*)map_or_array;
                return map->m_insert(new String(key), new Array());
            }
            return 0;
        }
        std::string ToString() const { return ""; } //NOLINT
        bool IsEmpty() {
            if (map_or_array->sign() == MAP_KO) {
                auto* tmp = new Map();
                bool result = ((Map*)map_or_array)->equals(tmp);
                delete tmp;
                return result;
            } else {
                return ((Array*)map_or_array)->hash() == 0;
            }
        }
        void Clear() {}
        bool IsArray() { return map_or_array->sign() == ARRAY_KO; }
        s4int ArraySize() { return ((Array*)map_or_array)->hash(); }
        s4int Parse(const std::string& str) {
            if (analysis(str, reinterpret_cast<void *&>(map_or_array)) == 1) { return 0; }
            return 1;
        }
        bool KeyExist(const char* key) const {
            if (map_or_array->sign() == MAP_KO) {
                auto* map = (Map*)map_or_array;
                return map->m_find(Util::u()->hash_code(key)) != nullptr;
            }
            return false;
        }
        JsonObject& operator[](const char* key) {
            if (KeyExist(key)) {
                auto* map = (Map*)map_or_array;
                auto* node = (MapNode*)map->m_find(Util::u()->hash_code(key));
                if (node->value->sign() == MAP_KO) {
                    map_or_array = (Map*)node->value;
                    return *this;
                } else if (node->value->sign() == ARRAY_KO) {
                    map_or_array = (Array*)node->value;
                    return *this;
                }
            }
            map_or_array = new Array();
            return *this;
        }
        Object* operator()(const char* key) const {
            if (KeyExist(key)) {
                auto* map = (Map*)map_or_array;
                auto* node = (MapNode*)map->m_find(Util::u()->hash_code(key));
                if (node != nullptr) { return node->value; }
            }
            return default_object;
        }
        JsonObject& operator[](const u4int index) {
            if (map_or_array->sign() == ARRAY_KO) {
                auto* array = (Array*)map_or_array;
                auto* node = (ArrayNode*)array->a_find(index);
                if (node->value->sign() == MAP_KO) {
                    map_or_array = (Map*)node->value;
                    return *this;
                } else if (node->value->sign() == ARRAY_KO) {
                    map_or_array = (Array*)node->value;
                    return *this;
                }
            }
            map_or_array = new Array();
            return *this;
        }
        Object* operator()(const u4int index) const {
            if (map_or_array->sign() == ARRAY_KO) {
                auto* array = (Array*)map_or_array;
                auto* node = (ArrayNode*)array->a_find(index);
                if (node != nullptr) { return node->value; }
            }
            return default_object;
        }
    };
}
#if KO_KO_TEST_H
int test_system_json_run() {
    {
        auto *map = new sys::Map();
        map->m_insert(new sys::String("id"), new sys::Int(1));
        map->m_insert(new sys::String("name"), new sys::String("alice"));
        auto *mate = new sys::Map();
        mate->m_insert(new sys::String("number"), new sys::Int(2));
        auto *array = new sys::Array();
        auto *ma1 = new sys::Map();
        ma1->m_insert(new sys::String("id"), new sys::Int(2));
        ma1->m_insert(new sys::String("name"), new sys::String("one"));
        array->insert(ma1);
        auto *ma2 = new sys::Map();
        ma2->m_insert(new sys::String("id"), new sys::Int(3));
        ma2->m_insert(new sys::String("name"), new sys::String("two"));
        ma2->m_insert(new sys::String("message"), new sys::String("hello"));
        array->insert(ma2);
        mate->insert(new sys::MapNode(new sys::String("array"), array));
        map->m_insert(new sys::String("mate"), mate);
        auto *out = new sys::SystemStream(1u, 1u);
        map->serialize(out);
        out->end();

        out->start(1u);
        {
            out->maybe(1u);
            auto* tmp_moa = map->m_find(sys::Util::u()->hash_code("mate"));
            out->append("\n第一层key为mate（加入JsonObject之后由于返回的是node而不是实际的元素Object故无法继续往深层调用）的内容：");
            tmp_moa->serialize(out);
            out->append("\n");
            if (tmp_moa->sign() == sys::MAP_KO) {
                tmp_moa = ((sys::Map*)tmp_moa)->m_find(sys::Util::u()->hash_code("array"));
                out->append("第二层key为array的内容：");
                tmp_moa->serialize(out);
                out->append("\n");
                if (tmp_moa->sign() == sys::ARRAY_KO) {
                    tmp_moa = ((sys::Array*)tmp_moa)->a_find(1);
                    out->append("第三层index为1的内容：");
                    tmp_moa->serialize(out);
                    out->append("\n");

                    tmp_moa = ((sys::Map*)tmp_moa)->m_find(sys::Util::u()->hash_code("message"));
                    out->append("第四层key为message的内容：");
                    tmp_moa->serialize(out);
                    out->append("\n");
                }
            }
        }
        out->end();

        delete out;
        delete map;
    }
    {
        auto* out = new sys::SystemStream(1u,1u);
        auto* json = new sys::Map();

        //sys::analysis("{\"id\":1,\"name\":\"alice\",\"message\":{\"result\":1,\"error\":{\"code\":1001}}}",json); //NOLINT
        //sys::analysis("{\"number\":3,\"name\":[\"alice\",\"mate\",\"array\"],\"result\":0}",json); //NOLINT
        sys::analysis("{\"id\":1,\"name\":\"alice\",\"mate\":{\"number\":2,\"array\":[{\"id\":2,\"name\":\"one\"},{\"id\":3,\"name\":\"two\",\"message\":\"hello\"}]}}", reinterpret_cast<void *&>(json)); //NOLINT

        //auto* json_shadow = (sys::Array*)json;
        json->serialize(out);
        out->end();
        delete json;
        delete out;
    }
    {
        auto* out = new sys::SystemStream(1u,1u);
        auto* json = new sys::JsonObject();
        json->Parse("{\"id\":1,\"name\":\"alice\",\"mate\":{\"number\":2,\"array\":[{\"id\":2,\"name\":\"one\"},{\"id\":3,\"name\":\"two\",\"message\":\"hello\"}]}}"); //NOLINT

        {
            auto json_shadow = *json;
            json_shadow["mate"]["array"][1]("message")->serialize(out);
            json_shadow = *json;
            json_shadow["mate"]["array"](0u)->serialize(out);
            json_shadow = *new sys::JsonObject();
        }

        out->end();
        delete json;
        delete out;
    }
    {
        {
            auto* out = new sys::SystemStream(1u,1u);
            auto* json = new sys::JsonObject();

            {
                auto json_shadow = *json;
                json_shadow.Add("id",1);
                json_shadow.Add("name","alice");
                json_shadow.AddEmptyObject("mate");
                json_shadow["mate"].Add("number",2);
                json_shadow = *json;
                json_shadow["mate"].AddEmptyArray("array");
                json_shadow = *json;
                sys::JsonObject a1;
                a1.Add("id",2);
                a1.Add("name","one");
                json_shadow["mate"]["array"].Add(a1);
                json_shadow = *json;
                sys::JsonObject a2;
                a2.Add("id",3);
                a2.Add("name","two");
                a2.Add("message","hello");
                json_shadow["mate"]["array"].Add(a2);
                json_shadow = *new sys::JsonObject();
                out->append("\n由此，由于析构问题，重载的[]()没有new对象会导致释放时报错\n");
                out->append("因为指针的地址并没有改变，所以如果需要重复访问，需要从头再来一遍\n");
                out->append("总，虽然只要使用了重载，就需要重新赋一次值，且最后一次要转走有点麻烦，不过基本已经达到预期效果\n");
            }

            {
                auto json_shadow = *json;
                json_shadow["mate"]["array"][1]("message")->serialize(out);
                json_shadow = *json;
                json_shadow["mate"]["array"](0u)->serialize(out);
                json_shadow = *new sys::JsonObject();
            }

            out->end();
            delete json;
            delete out;
        }
    }
    return 1;
}
#endif

#endif
// ====  ====
#endif //KO_KO_JSON_H
