#include <iostream>
#include "json.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
#if _WIN32 || WIN32
#ifdef __w64
    system("chcp 65001");
#endif
#endif
    test_system_json_run();
    return 0;
}
