#ifndef KO_KO_CONFIGURATION_H
#define KO_KO_CONFIGURATION_H

#ifdef KO_KO_SRC_H
#undef KO_KO_SRC_H
#endif
#define KO_KO_SRC_H true

#ifdef KO_KO_TEST_H
#undef KO_KO_TEST_H
#endif
#define KO_KO_TEST_H true

#endif //KO_KO_CONFIGURATION_H
