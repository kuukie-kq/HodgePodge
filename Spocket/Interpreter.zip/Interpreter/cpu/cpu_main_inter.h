//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_CPU_MAIN_INTER_H
#define INTERPRETER_CPU_MAIN_INTER_H

#include "stamp/time_stamp.h"
#include "step/counter_step.h"

int cpu_main_inter();

//题目：
//实现一个简单的汇编语言解释器，支持以下指令：
//mov a v 把数v赋值给a，其中a是指寄存器名称，由不超过10个小写字母组成，v是寄存器或者常数（常数为-10000~10000的整数）
//inc a   寄存器a加1
//dec a   寄存器a减1
//jnz a v 如果寄存器a的值不是0，则相对跳转v条指令。
//输入保证最多有100个寄存器，100条语句；执行inc, dec和jnz之前，相应寄存器一定已经用mov赋值过，并且程序最多执行1,000,000,000条语句后就会终止。
//输出执行完毕后各个变量的值。请尽量优化程序的执行速度。
////样例输入1
//mov bx 2
//mov ax 5
//inc bx
//dec ax
//jnz ax -2
//dec ax
////样例输出1
//ax -1
//bx 7
////样例输入2
//mov ax 10000
//mov bx ax
//dec bx
//jnz bx -1
//dec ax
//jnz ax -4
////样例输出2
//ax 0
//bx 0
////

//help
//思路:
//
//   0000 0000 0000 0000 0000 0000 0000 0000 32位   u4_int
//   指令 4种  参数一 寄存器 100种  参数二 寄存器或立即数 100+20001种
//   指令：00--mov 01--inc 10--dec 11--jnz 2位
//   寄存器：2^7 = 128      1000 0000   8位
//   数：2^15 = 32768      0000 0000 0000 0000 16位
//   0000 0100 0000 0000 0000 0000 0000 0000 32位
//         ↑固定位        ↑位为1则表示后面7位为寄存器 0 表示后15位为立即数(true number+10000)
//
//
//两种执行方式
//    一种写死的四种指令操作 时间≈1000000000ns = 1s  -- step()
//    另一种可以添加指令操作 时间≈2000000000ns = 2s  -- step_point()
//    ↑使用的是函数指针的方式

// CMakeLists笔记
//在多级目录情况下，使用add_library与target_link_library时
//不要使用外部需要link的库，注意library的定义，是一个完全独立的，既最接近库的存在
//同时link下以名称来区分，存在同名问题，目录的层数最好区别开来一级XX二级XX_XX三级XX_XX_XX
//link一串中的链接有先后顺序，顺序颠倒也会出现not define的情况
//循环引用问题，一定要注意
//其中需要额外说明的是外部link库与循环引用问题可以在局部地方再细节link，但因为有顺序问题，可能会出现其他错误，还是老老实实在add executable中写一下比较好，可以只写有问题的文件
//总结，add_library与target_link_library不是很适合作为package的链接方式，这也是为什么clion建文件夹没有package的原因

#endif //INTERPRETER_CPU_MAIN_INTER_H
