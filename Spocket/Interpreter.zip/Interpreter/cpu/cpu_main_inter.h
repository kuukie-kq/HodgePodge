//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_CPU_MAIN_INTER_H
#define INTERPRETER_CPU_MAIN_INTER_H

#include "stamp/time_stamp.h"
#include "step/counter_step.h"

int cpu_main_inter();

#endif //INTERPRETER_CPU_MAIN_INTER_H
