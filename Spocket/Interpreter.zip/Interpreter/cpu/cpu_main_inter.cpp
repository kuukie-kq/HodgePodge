//
// Created by kuu-kie on 2022/7/12.
//

#include "cpu_main_inter.h"

int cpu_main_inter() {
    auto* timer = new time_stamp();
    auto* counter = new counter_step();
    counter->read();
    for (;;) {
        #ifndef STEP_POINT
        if (counter->step_point() == 0) { break; }
        #else
        if (counter->step() == 0) { break; }
        #endif
    }
    counter->result();
    delete counter;
    timer->time_line_passed();
    delete timer;
    return 0;
}
