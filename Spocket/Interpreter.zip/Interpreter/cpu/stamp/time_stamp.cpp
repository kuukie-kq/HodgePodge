//
// Created by kuu-kie on 2022/7/12.
//

#include "time_stamp.h"

time_stamp::time_stamp() {
    start_stamp = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::system_clock::now().time_since_epoch()
            );
}

time_stamp::~time_stamp() {
    start_stamp = std::chrono::nanoseconds::zero();
}

int time_stamp::time_line_passed() {
    std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::system_clock::now().time_since_epoch()
            );
    long long passed = now.count() - start_stamp.count();
    if(passed > 0) {
        return (int)(passed);
    }
    return 0;
}
