//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_TIME_STAMP_H
#define INTERPRETER_TIME_STAMP_H

#include <chrono>

class time_stamp {
private:
    std::chrono::nanoseconds start_stamp = std::chrono::nanoseconds::zero();
public:
    time_stamp();
    ~time_stamp();
    int time_line_passed();
};

#endif //INTERPRETER_TIME_STAMP_H
