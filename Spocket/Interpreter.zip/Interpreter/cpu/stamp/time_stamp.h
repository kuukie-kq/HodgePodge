//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_TIME_STAMP_H
#define INTERPRETER_TIME_STAMP_H

#include <chrono>

class time_stamp {
private:
    std::chrono::nanoseconds start_stamp = std::chrono::nanoseconds::zero();
public:
    time_stamp();
    ~time_stamp();
    int time_line_passed();
};

//时间戳
//C++11 chrono库
//使用的最高精度，nanoseconds纳秒
//格式化输出方式
//先将时间戳转换成chrono::time_point或者chrono::system_clock::time_point
//然后就可以使用chrono::system_clock::to_time_t转成std::time_t
//既ctime库中的使用方式

#endif //INTERPRETER_TIME_STAMP_H
