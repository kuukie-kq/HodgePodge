//
// Created by kuu-kie on 2022/7/12.
//

#include "counter_step.h"

unsigned int counter_step::calculate(int index, const char* word) {
    if (constant(word) == 0 && index == 2) {
        int number = string_number(word);
        if (number >= -10000 && number <= 10000) {
            unsigned int result = number + 10000;
            return result;
        } else { return 1u << 15u; }
    } else {
        unsigned int result = constant(word);
        if (index == 0) {
            return result << 24u;
        } else if (index == 1) {
            return result << 16u;
        } else {
            return result << 8u;
        }
    }
}

int counter_step::string_number(const char* number) {
    return 0;
}

int counter_step::constant(const char* reg) {
    char* sta[104] = {
            "mov", "inc", "dec", "jnz",
            "ax", "bx", "cx", "dx", "ex", "fx", "gx", "hx", "ix", "jx",
            "bax", "bbx", "bcx", "bdx", "bex", "bfx", "bgx", "bhx", "bix", "bjx",
            "cax", "cbx", "ccx", "cdx", "cex", "cfx", "cgx", "chx", "cix", "cjx",
            "dax", "dbx", "dcx", "ddx", "dex", "dfx", "dgx", "dhx", "dix", "djx",
            "eax", "ebx", "ecx", "edx", "eex", "efx", "egx", "ehx", "eix", "ejx",
            "fax", "fbx", "fcx", "fdx", "fex", "ffx", "fgx", "fhx", "fix", "fjx",
            "gax", "gbx", "gcx", "gdx", "gex", "gfx", "ggx", "ghx", "gix", "gjx",
            "hax", "hbx", "hcx", "hdx", "hex", "hfx", "hgx", "hhx", "hix", "hjx",
            "iax", "ibx", "icx", "idx", "iex", "ifx", "igx", "ihx", "iix", "ijx",
            "jax", "jbx", "jcx", "jdx", "jex", "jfx", "jgx", "jhx", "jix", "jjx"
    };
    int stb[104] = {
            4, 5, 6, 7,
            129, 130, 131, 132, 133, 134, 135, 136, 137, 138,
            139, 140, 141, 142, 143, 144, 145, 146, 147, 148,
            149, 150, 151, 152, 153, 154, 155, 156, 157, 158,
            159, 160, 161, 162, 163, 164, 165, 166, 167, 168,
            169, 170, 171, 172, 173, 174, 175, 176, 177, 178,
            179, 180, 181, 182, 183, 184, 185, 186, 187, 188,
            189, 190, 191, 192, 193, 194, 195, 196, 197, 198,
            199, 200, 201, 202, 203, 204, 205, 206, 207, 208,
            209, 210, 211, 212, 213, 214, 215, 216, 217, 218,
            219, 220, 221, 222, 223, 224, 225, 226, 227, 228,
    };
    for (int i = 0; i < 104; i++) {
        if (reg == sta[i]) {
            if (i > 3) {
                linked->insert(csr->array_index(i - 4), reg);
            }
            return stb[i];
        }
    }
    return 0;
}

counter_step::counter_step() {
    pc = 0;
    cs = 1;
    csr = new array();
    ir = new array_list();
    ins = new coding_tree();
    linked = new linked_list();
}

counter_step::~counter_step() {
    delete linked;
    delete ins;
    delete ir;
    delete csr;
}

void counter_step::read(const char* file) {

}

int counter_step::step() {
    if (pc <= 1000000000 && pc >= 0) {
        pc++;
        unsigned int ip = ir->get(cs);
        unsigned int first = ip >> 24u;
        unsigned int second = (ip << 8u) >> 24u;
        unsigned int third = (ip << 16u) >> 16u;
        if (first == 4) {
            if (third > 1u << 15u) {
                third = third >> 8u;
                csr->exchange((int) (second) - 129, csr->get((int) (third) - 129));
            } else {
                csr->exchange((int) (second) - 129, (int) third - 10000);
            }
            cs++;
        } else if (first == 5) {
            csr->exchange((int) (second) - 129, csr->get((int) (second) - 129) + 1);
            cs++;
        } else if (first == 6) {
            csr->exchange((int) (second) - 129, csr->get((int) (second) - 129) - 1);
            cs++;
        } else if (first == 7) {
            if (csr->get((int) (second) - 129) == 0) {
                cs++;
            } else {
                cs = cs + ((int) third - 10000);
            }
        } else { return 0; }
        return 1;
    } else { return 0; }
}

int counter_step::step_point() {
    if (pc <= 1000000000 && pc >= 0) {
        pc++;
        unsigned int ip = ir->get(cs);
        if (ip == 0) {
            return 0;
        }
        function fun = ins->found(ip);
        fun(cs, ip, csr);
        return 1;
    } else { return 0; }
}

void counter_step::result() {
    linked->display();
}
