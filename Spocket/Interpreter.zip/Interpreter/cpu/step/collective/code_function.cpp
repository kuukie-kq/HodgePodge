//
// Created by kuu-kie on 2022/7/13.
//

#include "code_function.h"

void mov(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    unsigned int third = (ip << 16u) >> 16u;
    if (first != 4) { return; }
    if (third > 1u << 15u) {
        third = third >> 8u;
        csr->exchange((int) (second) - 129, csr->get((int) (third) - 129));
    } else {
        csr->exchange((int) (second) - 129, (int) third - 10000);
    }
    cs++;
}

void inc(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    if (first != 5) { return; }
    csr->exchange((int) (second) - 129, csr->get((int) (second) - 129) + 1);
    cs++;
}

void dec(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    if (first != 6) { return; }
    csr->exchange((int) (second) - 129, csr->get((int) (second) - 129) - 1);
    cs++;
}

void jnz(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    unsigned int third = (ip << 16u) >> 16u;
    if (first != 7) { return; }
    if (csr->get((int) (second) - 129) == 0) {
        cs++;
    } else {
        cs = cs + ((int) third - 10000);
    }
}
