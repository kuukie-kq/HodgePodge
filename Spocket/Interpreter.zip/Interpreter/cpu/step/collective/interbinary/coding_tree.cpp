//
// Created by Admin on 2022/7/12.
//

#include "coding_tree.h"

void mov(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    unsigned int third = (ip << 16u) >> 16u;
    if (first != 4) { return; }
    if (third > 1u << 15u) {
        third = third >> 8u;
        csr->exchange((int) (second) - 129, csr->get((int) (third) - 129));
    } else {
        csr->exchange((int) (second) - 129, (int) third - 10000);
    }
    cs++;
}

void inc(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    if (first != 5) { return; }
    csr->exchange((int) (second) - 129, csr->get((int) (second) - 129) + 1);
    cs++;
}

void dec(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    if (first != 6) { return; }
    csr->exchange((int) (second) - 129, csr->get((int) (second) - 129) - 1);
    cs++;
}

void jnz(int& cs, unsigned int ip, array* csr) {
    unsigned int first = ip >> 24u;
    unsigned int second = (ip << 8u) >> 24u;
    unsigned int third = (ip << 16u) >> 16u;
    if (first != 7) { return; }
    if (csr->get((int) (second) - 129) == 0) {
        cs++;
    } else {
        cs = cs + ((int) third - 10000);
    }
}

coding_tree::node::node() {
    fun = nullptr;
    left = nullptr;
    right = nullptr;
}

coding_tree::node::~node() {
    delete right;
    delete left;
}

void coding_tree::generation(unsigned char code, function func) {
    code = code - 4;
    node* n = base;
    for (int i = 2; i > 0; i--) {
        if (bit_one(code, i)) {
            if (n->right == nullptr) {
                n->right = new node();
            }
            n = n->right;
        } else {
            if (n->left == nullptr) {
                n->left = new node();
            }
            n = n->left;
        }
    }
    n->fun = func;
}

bool coding_tree::bit_one(unsigned char code, int index) {
    return code & (1u << (unsigned int)(index - 1));
}

coding_tree::coding_tree() {
    base = new node();
    generation(4, mov);
    generation(5, inc);
    generation(6, dec);
    generation(7, jnz);
}

coding_tree::~coding_tree() {
    delete base;
}

function coding_tree::found(unsigned int ip) const {
    unsigned int first = ip >> 24u;
    node* n = base;
    for (int i = 2; i > 0; i--) {
        if(bit_one(first, i)) {
            n = n->right;
        } else {
            n = n->left;
        }
        if (nullptr == n) {
            return nullptr;
        }
    }
    return n->fun;
}
