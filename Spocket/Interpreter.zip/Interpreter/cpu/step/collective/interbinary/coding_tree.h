//
// Created by Admin on 2022/7/12.
//

#ifndef INTERPRETER_CODING_TREE_H
#define INTERPRETER_CODING_TREE_H

#include "../continuous/array.h"

using function = void (*)(int& cs, unsigned int ip, array* csr);
void mov(int& cs, unsigned int ip, array* csr);
void inc(int& cs, unsigned int ip, array* csr);
void dec(int& cs, unsigned int ip, array* csr);
void jnz(int& cs, unsigned int ip, array* csr);

class coding_tree {
private:
    class node {
    public:
        function fun;
        node* left;
        node* right;
        node();
        ~node();
    };
    node* base;
    void generation(unsigned char code, function func);
    static bool bit_one(unsigned char code, int index);
public:
    coding_tree();
    ~coding_tree();
    function found(unsigned int ip) const;
};

#endif //INTERPRETER_CODING_TREE_H
