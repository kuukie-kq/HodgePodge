//
// Created by kuu-kie on 2022/7/12.
//

#include "array.h"

array::array() {
    for (int& i : csr) {
        i = -2147483648;
    }
}

array::~array() {
    for (int& i : csr) {
        i = -2147483648;
    }
}

void array::exchange(const int index, const int value) {
    csr[index] = value;
}

int* array::array_index(const int index) {
    return &csr[index];
}

int array::get(int index) const {
    return csr[index];
}
