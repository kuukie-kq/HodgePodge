//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_CODING_TREE_H
#define INTERPRETER_CODING_TREE_H

#include "code_function.h"

class coding_tree {
private:
    class coding_tree_node {
    public:
        function fun;
        coding_tree_node* left;
        coding_tree_node* right;
        coding_tree_node();
        ~coding_tree_node();
    };
    coding_tree_node* base;
    void generation(unsigned char code, function func);
    static bool bit_one(unsigned char code, int index);
public:
    coding_tree();
    ~coding_tree();
    function found(unsigned int ip) const;
};

#endif //INTERPRETER_CODING_TREE_H
