//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_LINKED_LIST_H
#define INTERPRETER_LINKED_LIST_H

class linked_list {
private:
    class node {
    public:
        int* value;
        int name_key;
        node* next;
        node();
        ~node();
    };
    static int hash(const char* str);
    node* head;
    bool exist(const char* name) const;
public:
    linked_list();
    ~linked_list();
    void insert(int* value, const char* name) const;
    void display() const;
};

#endif //INTERPRETER_LINKED_LIST_H
