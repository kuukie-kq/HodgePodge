//
// Created by kuu-kie on 2022/7/12.
//

#include "array_list.h"

array_list::array_list() {
    size = 0;
    for (unsigned int& i : array) {
        i = 0u;
    }
}

array_list::~array_list() {
    for (unsigned int& i : array) {
        i = 0u;
    }
}

void array_list::append(const unsigned int value) {
    if (size < 100 && size >= 0) {
        array[size] = value;
        size++;
    }
}

unsigned int array_list::get(const int index_positive) const {
    return array[index_positive - 1];
}
