//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_LINKED_LIST_H
#define INTERPRETER_LINKED_LIST_H

#include "../instrument/hash_code.h"
#include "../instrument/system_stream_io.h"

class linked_list {
private:
    class linked_list_node {
    public:
        int* value;
        int name_key;
        linked_list_node* next;
        linked_list_node();
        ~linked_list_node();
    };
    linked_list_node* head;
    bool exist(const char* name) const;
public:
    linked_list();
    ~linked_list();
    std::string* str;
    void insert(int* value, const char* name) const;
    void display();
};

#endif //INTERPRETER_LINKED_LIST_H
