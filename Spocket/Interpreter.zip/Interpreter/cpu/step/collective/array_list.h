//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_ARRAY_LIST_H
#define INTERPRETER_ARRAY_LIST_H


class array_list {
private:
    int size;
    unsigned int array[100];
public:
    array_list();
    ~array_list();
    void append(unsigned int value);
    unsigned int get(int index_positive) const;
};


#endif //INTERPRETER_ARRAY_LIST_H
