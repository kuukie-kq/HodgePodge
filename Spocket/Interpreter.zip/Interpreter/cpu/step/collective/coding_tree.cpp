//
// Created by kuu-kie on 2022/7/12.
//

#include "coding_tree.h"

coding_tree::coding_tree_node::coding_tree_node() {
    fun = nullptr;
    left = nullptr;
    right = nullptr;
}

coding_tree::coding_tree_node::~coding_tree_node() {
    delete right;
    delete left;
}

void coding_tree::generation(unsigned char code, function func) {
    code = code - 4;
    coding_tree_node* n = base;
    for (int i = 2; i > 0; i--) {
        if (bit_one(code, i)) {
            if (n->right == nullptr) {
                n->right = new coding_tree_node();
            }
            n = n->right;
        } else {
            if (n->left == nullptr) {
                n->left = new coding_tree_node();
            }
            n = n->left;
        }
    }
    n->fun = func;
}

bool coding_tree::bit_one(unsigned char code, int index) {
    return code & (1u << (unsigned int)(index - 1));
}

coding_tree::coding_tree() {
    base = new coding_tree_node();
    generation(4, mov);
    generation(5, inc);
    generation(6, dec);
    generation(7, jnz);
}

coding_tree::~coding_tree() {
    delete base;
}

function coding_tree::found(unsigned int ip) const {
    unsigned int first = ip >> 24u;
    coding_tree_node* n = base;
    for (int i = 2; i > 0; i--) {
        if(bit_one(first, i)) {
            n = n->right;
        } else {
            n = n->left;
        }
        if (nullptr == n) {
            return nullptr;
        }
    }
    return n->fun;
}
