//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_ARRAY_H
#define INTERPRETER_ARRAY_H

class array {
private:
    int csr[100];
public:
    array();
    ~array();
    void exchange(int index, int value);
    int* array_index(int index);
    int get(int index) const;
};

#endif //INTERPRETER_ARRAY_H
