//
// Created by kuu-kie on 2022/7/12.
//

#include "linked_list.h"

linked_list::linked_list_node::linked_list_node() {
    value = nullptr;
    name_key = -2147483648;
    next = nullptr;
}

linked_list::linked_list_node::~linked_list_node() {
    delete next;
}

bool linked_list::exist(const char* const name) const {
    int key = (int)hash_code(name);
    for (linked_list_node* n = head->next; n != nullptr; n = n->next) {
        if (key == n->name_key) {
            return true;
        }
    }
    return false;
}

linked_list::linked_list() {
    head = new linked_list_node();
    str = new std::string("");
}

linked_list::~linked_list() {
    delete head;
}

void linked_list::insert(int* const value, const char* const name) const {
    if (!exist(name)) {
        linked_list_node* n = head;
        for(; n->next != nullptr; n = n->next) {}
        n->next = new linked_list_node();
        n->next->value = value;
        n->next->name_key = (int)hash_code(name);
    }
}

void linked_list::display() {
    delete str;
    str = new std::string("");
    for (linked_list_node* n = head->next; n != nullptr; n = n->next) {
        str->append("[").append(std::to_string(n->name_key)).append(" ").append(std::to_string(*n->value)).append("]");
    }
}
