//
// Created by kuu-kie on 2022/7/12.
//

#include "linked_list.h"

linked_list::linked_list_node::linked_list_node() {
    value = nullptr;
    name_key = -2147483648;
    next = nullptr;
}

linked_list::linked_list_node::~linked_list_node() {
    delete next;
}

int linked_list::hash(const char* const str) {
    register int h;
    register char* p;
    for(h = 0, p = (char*)str; *p; p++) {
        h = 31 * h + *p;
    }
    return h;
}

bool linked_list::exist(const char* const name) const {
    int key = hash(name);
    for (linked_list_node* n = head->next; n != nullptr; n = n->next) {
        if (key == n->name_key) {
            return true;
        }
    }
    return false;
}

linked_list::linked_list() {
    head = new linked_list_node();
}

linked_list::~linked_list() {
    delete head;
}

void linked_list::insert(int* const value, const char* const name) const {
    if (!exist(name)) {
        linked_list_node* n = head;
        for(; n->next != nullptr; n = n->next) {}
        n->next = new linked_list_node();
        n->next->value = value;
        n->next->name_key = hash(name);
    }
}

void linked_list::display() const {
    for (linked_list_node* n = head->next; n != nullptr; n = n->next) {}
}
