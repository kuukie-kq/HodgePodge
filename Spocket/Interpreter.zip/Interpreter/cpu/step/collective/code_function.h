//
// Created by kuu-kie on 2022/7/13.
//

#ifndef INTERPRETER_CODE_FUNCTION_H
#define INTERPRETER_CODE_FUNCTION_H

#include "array.h"

using function = void (*)(int& cs, unsigned int ip, array* csr);

void mov(int& cs, unsigned int ip, array* csr);
void inc(int& cs, unsigned int ip, array* csr);
void dec(int& cs, unsigned int ip, array* csr);
void jnz(int& cs, unsigned int ip, array* csr);

#endif //INTERPRETER_CODE_FUNCTION_H
