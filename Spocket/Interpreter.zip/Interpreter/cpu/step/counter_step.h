//
// Created by kuu-kie on 2022/7/12.
//

#ifndef INTERPRETER_COUNTER_STEP_H
#define INTERPRETER_COUNTER_STEP_H

#include "collective/array.h"
#include "collective/array_list.h"
#include "collective/coding_tree.h"
#include "collective/linked_list.h"
#include "instrument/dynamic_split.h"
#include "instrument/system_stream_io.h"

class counter_step {
private:
    int pc;
    int cs;
    array* csr;
    array_list* ir;
    coding_tree* ins;
    linked_list* linked;
    unsigned int calculate(int index, const char* word);
    int constant(const std::string& reg);
public:
    counter_step();
    ~counter_step();
    void read(const char* file = nullptr);
    int step();
    int step_point();
    void result(int time);
};

#endif //INTERPRETER_COUNTER_STEP_H
