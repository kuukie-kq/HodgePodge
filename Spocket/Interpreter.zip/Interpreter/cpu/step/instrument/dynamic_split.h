//
// Created by kuu-kie on 2022/7/13.
//

#ifndef INTERPRETER_DYNAMIC_SPLIT_H
#define INTERPRETER_DYNAMIC_SPLIT_H

#include <vector>
#include <string>

std::vector<std::string> dynamic_split(std::string str, const std::string& pattern);

#endif //INTERPRETER_DYNAMIC_SPLIT_H
