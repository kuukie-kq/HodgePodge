//
// Created by kuu-kie on 2022/7/13.
//

#ifndef INTERPRETER_HASH_CODE_H
#define INTERPRETER_HASH_CODE_H

unsigned int hash_code(const char* str);

#endif //INTERPRETER_HASH_CODE_H
