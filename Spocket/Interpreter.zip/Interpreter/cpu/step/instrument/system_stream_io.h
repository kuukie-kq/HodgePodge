//
// Created by kuu-kie on 2022/7/14.
//

#ifndef INTERPRETER_SYSTEM_STREAM_IO_H
#define INTERPRETER_SYSTEM_STREAM_IO_H

#include <iostream>
#include <sstream>
#include <string>
#include <stdarg.h>

class system_stream_io {
private:
    unsigned int on_or_off;
    unsigned int level;
    void step() const;
    void log() const;
    void warning() const;
    void error() const;
    std::stringstream* ss;
public:
    explicit system_stream_io(unsigned int ooo = 1u);
    ~system_stream_io();
    void clear();
    void start(unsigned int mode);
    void append(const char* format, ...) const;
    void end();
};

extern system_stream_io* ssio;

#endif //INTERPRETER_SYSTEM_STREAM_IO_H
