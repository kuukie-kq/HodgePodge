//
// Created by kuu-kie on 2022/7/14.
//

#ifndef INTERPRETER_SYSTEM_STREAM_IO_H
#define INTERPRETER_SYSTEM_STREAM_IO_H

#include <iostream>
#include <sstream>
#include <string>
#include <stdarg.h>

class system_stream_io {
private:
    bool step_on;
    bool log_on;
    bool warning_on;
    bool error_on;
public:
    std::stringstream* ss;
    system_stream_io();
    ~system_stream_io();
    void clear() const;
    void set(const char* format, ...) const;
    void step() const;
    void log() const;
    void warning() const;
    void error() const;
};

extern system_stream_io* ssio;

#endif //INTERPRETER_SYSTEM_STREAM_IO_H
