//
// Created by kuu-kie on 2022/7/14.
//

#include "system_stream_io.h"

void system_stream_io::step() const {
    std::cout << "<->" << ss->str() << std::endl;
}

void system_stream_io::log() const {
    std::cout << "<*>" << ss->str() << std::endl;
}

void system_stream_io::warning() const {
    std::cout << ">-<" << ss->str() << std::endl;
}

void system_stream_io::error() const {
    std::cerr << ">*<" << ss->str() << std::endl;
}

system_stream_io::system_stream_io(unsigned int ooo) {
    ss = new std::stringstream();
    on_or_off = ooo;
    level = 0;
}

system_stream_io::~system_stream_io() {
    delete ss;
}

void system_stream_io::clear() {
    ss->clear();
    ss->str("");
    level = 0;
}

void system_stream_io::start(unsigned int mode) {
    if (ss->rdbuf()->in_avail() > 0) {
        clear();
    }
    level = mode;
}

void system_stream_io::append(const char* format, ...) const {
    if (level & on_or_off) {
        char *buffer = (char *) malloc(1024);
        va_list args;
        va_start(args, format);
        int length = vsnprintf(buffer, 1024, format, args);
        (length >= 1024) ? *ss << length << "-format and args too long" : *ss << buffer;
        va_end(args);
        delete buffer;
    }
}

void system_stream_io::end() {
    if (level == 0) return;
    bool error_on = (level & 1u) & (on_or_off & 1u);
    bool warning_on = (level & 2u) & (on_or_off & 2u);
    bool log_on = (level & 4u) & (on_or_off & 4u);
    bool step_on = (level & 8u) & (on_or_off & 8u);

    if (error_on) {
        error();
    } else if (warning_on) {
        warning();
    } else if (log_on) {
        log();
    } else if (step_on) {
        step();
    }
    clear();
}

system_stream_io* ssio = new system_stream_io(15u);
