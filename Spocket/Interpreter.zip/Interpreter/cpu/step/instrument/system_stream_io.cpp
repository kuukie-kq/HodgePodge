//
// Created by kuu-kie on 2022/7/14.
//

#include "system_stream_io.h"

system_stream_io::system_stream_io() {
    ss = new std::stringstream();
    step_on = false;
    log_on = true;
    warning_on = true;
    error_on = true;
}

system_stream_io::~system_stream_io() {
    delete ss;
}

void system_stream_io::clear() const {
    ss->clear();
    ss->str("");
}

void system_stream_io::set(const char* format, ...) const {
    char* buffer = (char*)malloc(1024);
    va_list args;
    va_start(args, format);
    int length = vsnprintf(buffer,1024, format, args);
    (length >= 1024) ? *ss << length << "-format and args too long" : *ss << buffer;
    va_end(args);
    delete buffer;
}

void system_stream_io::step() const {
    if (step_on) {
        std::cout << "<->" << ss->str() << std::endl;
    }
    clear();
}

void system_stream_io::log() const {
    if (log_on) {
        std::cout << "<*>" << ss->str() << std::endl;
    }
    clear();
}

void system_stream_io::warning() const {
    if (warning_on) {
        std::cout << ">-<" << ss->str() << std::endl;
    }
    clear();
}

void system_stream_io::error() const {
    if (error_on) {
        std::cerr << ">*<" << ss->str() << std::endl;
    }
    clear();
}

system_stream_io* ssio = new system_stream_io();
