//
// Created by kuu-kie on 2022/7/13.
//

#include "dynamic_split.h"

std::vector<std::string> dynamic_split(std::string str, const std::string& pattern) {
    std::string::size_type pos;
    std::vector<std::string> result;
    str += pattern;  //扩展字符串以方便操作
    unsigned int size = str.size();
    for (unsigned int i = 0; i < size; i++) {
        pos = str.find(pattern, i);
        if (pos < size) {
            std::string s = str.substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern.size() - 1;
        }
    }
    return result;
}
