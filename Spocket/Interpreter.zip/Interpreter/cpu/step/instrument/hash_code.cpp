//
// Created by kuu-kie on 2022/7/13.
//

#include "hash_code.h"

unsigned int hash_code(const char* const str) {
    register unsigned int h;
    register char* p;
    for(h = 0, p = (char*)str; *p; p++) {
        h = 31 * h + *p;
    }
    return h;
}
