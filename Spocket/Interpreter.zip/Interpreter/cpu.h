//
// Created by kuu-kie on 2022-08-29.
//

#ifndef INTERPRETER_CPU_H
#define INTERPRETER_CPU_H

// 编译器指令，有没有用看编译器支持不支持
//#pragma once

// notice
// 注意，切忌在自定义的命名空间中引用系统头文件，避免造成标识符的混乱。
// 在多层namespace的情况下存在里层namespace对于系统namespace中的函数错乱，找不到的情况
#include <iostream> //输入输出
#include <sstream> //输入输出缓冲
#include <cstdarg> //不定参数处理
#include <string> //字符串类
#include <vector> //不定数组，字符串分割
#include <fstream> //读写文件
#include <chrono> //时间戳

namespace kuu {
    // 基本框架，将一些可以用于其他地方的代码封装起来，仿照java
    namespace kie {
        // 最基本的接口，可以用在其他地方的类都继承这个类，相当于java中的Object
        class hickey { //NOLINT 主要消除语法结构复杂，无法分析数据流
        private:
            // 禁用拷贝构造函数
            hickey& operator=(hickey&) = default;
            hickey(hickey&) = default;
            // 禁用赋值运算符
            hickey& operator=(hickey&&) = default;
            hickey(hickey&&) = default;
        protected:
            // 禁用构造函数，也不算禁用，就是无法正常使用，防止产生实例
            // 不过，存在纯虚函数，就产生不了实例
            hickey() = default;
            inline bool check_conversion(const hickey* const target) const { return sign() == target->sign(); } // 方便使用，判断是否是同一种类
        public:
            virtual ~hickey() = default;
            virtual unsigned int sign() const { return 3260681415u; } // 类的签名//相当于java.getClass，由于类之间的关系问题，如果为static模板中还是无法直接使用，故，作为数据类来说，需要保证存在无参的构造函数
            virtual bool equals(const hickey* const target) const { return this == target; } // 判断两个对象是否相等//相当于java.equals
            virtual int clone(hickey*& target) const { return 0; } // 克隆出一个内容一样的不同内存，注意，使用深拷贝，另外注意参数的传递，可能会出现内存无法回收的情况（自己传自己）//相当于java.clone
            virtual int hash() const { return 0; } // 对象的标识或排序规则//相当于java.hashCode
            virtual int serialize(hickey* sys) const { return 0; } // 非规范的序列化//相当于java.toString
        };
        // 一些工具，不想对外暴露的
        namespace {
            //
            // 对于一些很难受的警告可以使用注释 //NOLINT 来消除
            // 明知代码没有问题，规范上也说得过去
            // 好像file is too complex to preform data-flow analysis和never used的警告无法消除
            //
            class utils final {
            private:
                utils() = default;
                ~utils() = default;
                utils& operator=(utils&)  = default;
                utils(const utils&) = default;
                utils& operator=(utils&&)  = default;
                utils(utils&&) = default;
                static utils* u;
            public:
                static utils* signal() { return u; }
                inline unsigned int hash_code(const char* key) const { //NOLINT 主要是消除可以设置为static的静态方法
                    unsigned int result;
                    unsigned char* byte;
                    for (result = 0, byte = (unsigned char*)key; *byte; byte++) {
                        result = result * 31 + *byte;
                    }
                    return result;
                }
                inline std::vector<std::string> spilt(std::string str, const std::string& pattern) const { //NOLINT 主要是消除可以设置为static的静态方法
                    std::string::size_type pos;
                    std::vector<std::string> result;
                    str += pattern;
                    unsigned int size = str.size();
                    for (unsigned int i = 0; i < size; i++) {
                        pos = str.find(pattern, i);
                        if (pos < size) {
                            std::string s = str.substr(i, pos - i);
                            result.push_back(s);
                            i = pos + pattern.size() - 1;
                        }
                    }
                    return result;
                }
                inline unsigned int encode(const char* key) const { //NOLINT 主要是消除可以设置为static的静态方法
                    // 由于数据大小的限制，27进制最大只能存7位
                    // 4294967295
                    // b28jpdl  标准编码数
                    // 为下划线和26个字母，对应应用于类的标识，由于类名一般不短，需摘要部分
                    // 固，保证全覆盖，key只能为6位，且不允许下划线开头
                    unsigned int result;
                    unsigned char* byte;
                    for (result = 0, byte = (unsigned char*)key; *byte; byte++) {
                        if ((*byte - 96) > 0 && (*byte - 96) < 27 ) {
                            result = result * 27 + *byte - 96;
                        } else if (*byte == 95) {
                            result = result * 27;
                        } else {
                            return 0;
                        }
                    }
                    return result;
                }
                inline int decode(unsigned int secret, std::string* key) const { //NOLINT
                    int stack[6];
                    for (int& i : stack) { i = -1; }
                    if (secret == 0) { return 0; }
                    int s = 0;
                    for(unsigned int i = secret; i > 0; i = i / 27) {
                        stack[s++] = static_cast<int>(i % 27u);
                    }
                    for(s--; s >= 0; s--) {
                        if(stack[s] == 0) {
                            key->append("_");
                        } else {
                            key->push_back(static_cast<char>(stack[s] + 96));
                        }
                    }
                    return 1;
                }
            };
            #ifdef INTERPRETER_CPU_H
            #define UTL ({ utils::signal(); })
            utils* utils::u = new utils(); //NOLINT 主要消除初始化时引发的异常无法捕获
            #endif //INTERPRETER_CPU_H
        }

        // 标准流，且已经留好接口，可以应用于文件流网络流（并未测试）
        class system_stream : public hickey {
        private:
            class time_stamp {
            private:
                std::chrono::nanoseconds start_stamp = std::chrono::nanoseconds::zero();
            public:
                time_stamp() {
                    start_stamp = std::chrono::duration_cast<std::chrono::nanoseconds>(
                            std::chrono::system_clock::now().time_since_epoch()
                    );
                }
                ~time_stamp() {
                    start_stamp = std::chrono::nanoseconds::zero();
                }
                unsigned long long time_line_passed() {
                    std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(
                            std::chrono::system_clock::now().time_since_epoch()
                    );
                    unsigned long long passed = now.count() - start_stamp.count();
                    if (passed > 0) {
                        return (passed);
                    }
                    return 0;
                }
                unsigned long long time_start() {
                    return start_stamp.count();
                }
                static unsigned long long time_now() {
                    std::chrono::nanoseconds now = std::chrono::duration_cast<std::chrono::nanoseconds>(
                            std::chrono::system_clock::now().time_since_epoch()
                    );
                    unsigned long long passed = now.count();
                    return passed;
                }
            };
        protected:
            const static int MAX_LENGTH = 1024;
            const static int BUFFER_SIZE = 1048575; // 2^20 - 1
            time_stamp* time;
            unsigned int on_or_off;
            unsigned int level;
            static inline unsigned int time_nano(unsigned long long stamp) {
                unsigned int re = stamp % 1000;
                return re;
            }
            static inline unsigned int time_milli(unsigned long long stamp) {
                unsigned int re = stamp / 1000 % 1000;
                return re;
            }
            static inline unsigned int time_micro(unsigned long long stamp) {
                unsigned int re = stamp / 1000000 % 1000;
                return re;
            }
            static inline unsigned int time_second(unsigned long long stamp) {
                unsigned int re = stamp / 1000000000 % 60;
                return re;
            }
            static inline unsigned int time_minute(unsigned long long stamp) {
                unsigned int re = stamp / 1000000000 / 60 % 60;
                return re;
            }
            static inline unsigned int time_hour(unsigned long long stamp) {
                unsigned int re = stamp / 1000000000 / (60 * 60) % 24;
                return re + 8;// UTC+8 (GMT)
            }
            virtual void step() const {
                if (buff->rdbuf()->in_avail() > BUFFER_SIZE) {
                    std::cout << buff->str();
                    buff->clear();
                    buff->str("");
                }
                unsigned long long tmp = time_stamp::time_now();
                *buff << "<  \t"
                      << time_hour(tmp) << ":" << time_minute(tmp) << "  " << time_second(tmp) << "s "
                      << time_micro(tmp) << "ms " << time_milli(tmp) << "us " << time_nano(tmp) << "ns\n"
                      << ss->str() << " ->\n";
            }
            virtual void log() const {
                if (buff->rdbuf()->in_avail() > 0) {
                    std::cout << buff->str();
                    buff->clear();
                    buff->str("");
                }
                unsigned long long tmp = time_stamp::time_now();
                std::cout << "<  \t"
                          << time_hour(tmp) << ":" << time_minute(tmp) << "  " << time_second(tmp) << "s "
                          << time_micro(tmp) << "ms " << time_milli(tmp) << "us " << time_nano(tmp) << "ns\n"
                          << ss->str() << " *>" << std::endl;
            }
            virtual void warning() const {
                unsigned long long tmp = time_stamp::time_now();
                std::cout << ">  \t"
                          << time_hour(tmp) << ":" << time_minute(tmp) << "  " << time_second(tmp) << "s "
                          << time_micro(
                                  tmp) << "ms " << time_milli(tmp) << "us " << time_nano(tmp) << "ns\n"
                          << ss->str() << " -<" << std::endl;
            }
            virtual void error() const {
                unsigned long long tmp = time_stamp::time_now();
                std::cerr << ">  \t"
                          << time_hour(tmp) << ":" << time_minute(tmp) << "  " << time_second(tmp) << "s "
                          << time_micro(
                                  tmp) << "ms " << time_milli(tmp) << "us " << time_nano(tmp) << "ns\n"
                          << ss->str() << " *<" << std::endl;
            }
            std::stringstream* ss;
            std::stringstream* buff;
        public:
            explicit system_stream(unsigned int ooo = 1u, unsigned int mode = 0) {
                ss = new std::stringstream();
                buff = new std::stringstream();
                on_or_off = ooo;
                level = mode;
                time = new time_stamp();
            }
            ~system_stream() override {
                delete time;
                delete ss;
                delete buff;
            }
            void clear() {
                ss->clear();
                ss->str("");
                level = 0;
            }
            void start(unsigned int mode) {
                if (ss->rdbuf()->in_avail() > 0) {
                    clear();
                }
                level = mode;
            }
            void maybe(unsigned int mode) {
                level = mode;
            }
            void append(const char *format, ...) const {
                if (level & on_or_off) {
                    char *buffer = (char *) malloc(MAX_LENGTH);
                    va_list args;
                    va_start(args, format);
                    int length = vsnprintf(buffer, MAX_LENGTH, format, args);
                    (length >= MAX_LENGTH) ? *ss << length << "- format and args too long" : *ss << buffer;
                    va_end(args);
                    delete buffer;
                }
            }
            void end() {
                if (level == 0) return;
                bool error_on = (level & 1u) & (on_or_off & 1u);
                bool warning_on = (level & 2u) & (on_or_off & 2u);
                bool log_on = (level & 4u) & (on_or_off & 4u);
                bool step_on = (level & 8u) & (on_or_off & 8u);
                unsigned long stamp = time->time_line_passed();
                append("%llu[%d s %d ms %d us %d ns]", stamp, stamp / 1000000000, time_micro(stamp), time_milli(stamp), time_nano(stamp));
                if (error_on) {
                    error();
                } else if (warning_on) {
                    warning();
                } else if (log_on) {
                    log();
                } else if (step_on) {
                    step();
                }
                clear();
            }
            int hash() const override { return static_cast<int>(time->time_start()); }
            unsigned int sign() const override { return UTL->encode("system"); }
            bool equals(const hickey* target) const override {
                if (target->sign() != sign()) {
                    return false;
                }
                return ((system_stream*)target)->ss->str() == ss->str() && ((system_stream*)target)->buff->str() == buff->str();
            }
            int clone(hickey*& target) const override {
                if (target == nullptr) { return 0; }
                if (sign() == target->sign()) {
                    if (target == this) {
                        // 由此可以看出，此clone只能复制一个模式相同的输出流，而流中的数据是没有的
                        target = new system_stream(on_or_off, level);
                        return 2;
                    } else {
                        delete target;
                        target = new system_stream(on_or_off, level);
                        return 1;
                    }
                } else { return 0; }
            }
        };
        //目前还没有想到更好的写法
        class system_error : public hickey {
        public:
            system_stream* error;
            system_error() { error = new system_stream(1u,1u); }
            ~system_error() override { delete error; }
            bool equals(const hickey* target) const override { return false; }
            int hash() const override { return error->hash(); }
            unsigned int sign() const override { return UTL->encode("serror"); }
            int clone(hickey*& target) const override { return 0; }
            // 拷贝构造函数，抛出异常和捕获异常的时候
            system_error(system_error& se) {
                error = new system_stream();
                se.error->clone(reinterpret_cast<hickey*&>(error));
            }
        };

        //宏定义，对于异常的抛出给出一个示例性的写法
//
//        #define ERROR_THROW(message) ({ \
//            auto* serror = new system_error(); \
//            serror->error->append((message)); \
//            serror; \
//        })
//
//        #define ERROR_CACHE(serror) ({ \
//            (serror)->error->end(); \
//            delete (serror); \
//            ; \
//        })
//

        // 在原本的接口上又加了一个序列化的方法
        class serialize : public hickey {
        protected:
            serialize() = default;
        public:
            virtual int stream_print(system_stream* out) = 0; //NOLINT
            unsigned int sign() const override { return UTL->encode("serial"); }
            bool equals(const hickey* target) const override = 0;
            int clone(hickey*& target) const override = 0; // 注意，使用深拷贝，另外注意参数的传递，可能会出现内存无法回收的情况
            int hash() const override = 0;
        };

        // 栈结构，链式结构，需要实现serialize接口
        template<class SERIAL>
        class stack final : public hickey { //NOLINT
        private:
            inline bool template_check(hickey* const data) const { auto* s = new SERIAL(); return s->sign() == data->sign(); }
            class node {
            public:
                hickey* data;
                node* next;
                node() { data = new SERIAL(); next = nullptr; }
                ~node() { delete next; delete data; }
            };
            node* head;
        public:
            stack() { head = new node(); }
            ~stack() override { delete head; }
            int push(hickey* const data) {
                if(template_check(data)) {
                    auto* n = new node();
                    n->next = head->next;
                    head->next = n;
                    //不深拷贝
                    n->data = data;
                    return 1;
                } else { return 0; }
            }
            int pop(hickey*& data) {
                if(template_check(data)) {
                    if(head->next == nullptr) { return 0; }
                    node* n = head->next;
                    head->next = n->next;
                    n->next = nullptr;
                    // 采用深拷贝，然后释放掉原本的内存
                    n->data->clone(reinterpret_cast<hickey*&>(data));
                    delete n;
                    return 1;
                } else { return 0; }
            }
            bool equals(const hickey* target) const override { return this == target; }
            int hash() const override { return 0; }
            int clone(hickey *&target) const override { return 0; }
        };

        // 红黑树，需要实现serialize接口
        template<class SERIAL>
        class red_black_tree final : public hickey {
        private:
            enum red_black { RED = 0, BLACK = 1};
            class node {
            public:
                hickey* value;
                red_black color;
                node* left;
                node* right;
                void* parent;
                explicit node(hickey* value = new SERIAL()) : value(value) {
                    color = RED;
                    left = nullptr;
                    right = nullptr;
                    parent = nullptr;
                }
                ~node() { delete left; delete right; delete value; }
            };
            void left_rotate(node* pivot) {
                node* right = pivot->right;
                pivot->right = right->left;
                if (right->left != nullptr) {
                    right->left->parent = pivot;
                }
                right->parent = pivot->parent;
                if (pivot->parent == nullptr) {
                    root = right;
                } else if (parent_node(pivot)->left == pivot) {
                    parent_node(pivot)->left = right;
                } else {
                    parent_node(pivot)->right = right;
                }
                right->left = pivot;
                pivot->parent = right;
            }
            void right_rotate(node* pivot) {
                node* left = pivot->left;
                pivot->left = left->right;
                if (left->right != nullptr) {
                    left->right->parent = pivot;
                }
                left->parent = pivot->parent;
                if (pivot->parent == nullptr) {
                    root = left;
                } else if (parent_node(pivot)->left == pivot) {
                    parent_node(pivot)->left = left;
                } else {
                    parent_node(pivot)->right = left;
                }
                left->right = pivot;
                pivot->parent = left;
            }
            node* parent_node(node* child) const {
                if(child == nullptr) { return nullptr; }
                return (node*)child->parent;
            }
            void fix_after_append(node* check) {
                for (; check != nullptr && root != check && parent_node(check)->color == RED;) {
                    if (parent_node(check) == parent_node(parent_node(check))->left) {
                        node* uncle = parent_node(parent_node(check))->right;
                        if (uncle != nullptr && uncle->color == RED) {
                            uncle->color = BLACK;
                            parent_node(check)->color = BLACK;
                            check = parent_node(parent_node(check));
                            check->color = RED;
                        } else {
                            if (check == parent_node(check)->right) {
                                check = parent_node(check);
                                left_rotate(check);
                            }
                            parent_node(check)->color = BLACK;
                            parent_node(parent_node(check))->color = RED;
                            right_rotate(parent_node(parent_node(check)));
                        }
                    } else {
                        node* uncle = parent_node(parent_node(check))->left;
                        if (uncle != nullptr && uncle->color == RED) {
                            uncle->color = BLACK;
                            parent_node(check)->color = BLACK;
                            check = parent_node(parent_node(check));
                            check->color = RED;
                        } else {
                            if (check == parent_node(check)->left) {
                                check = parent_node(check);
                                right_rotate(check);
                            }
                            parent_node(check)->color = BLACK;
                            parent_node(parent_node(check))->color = RED;
                            left_rotate(parent_node(parent_node(check)));
                        }
                    }
                }
                root->color = BLACK;
            }
            node* found(int value) {
                node* current = root;
                for (; current != nullptr;) {
                    if (current->value->hash() > value) {
                        current = current->left;
                    } else if (current->value->hash() < value) {
                        current = current->right;
                    } else {
                        break;
                    }
                }
                return current;
            }
            node* successor(node* check) const {
                node* most_left = check->right;
                for (; most_left != nullptr && most_left->left != nullptr;) {
                    most_left = most_left->left;
                }
                return most_left;
            }
            void fix_after_subtract(node* check) {
                for (; check != root && BLACK == check->color;) {
                    if (check == parent_node(check)->left) {
                        node* sister = parent_node(check)->right;
                        if (RED == sister->color) {
                            sister->color = BLACK;
                            parent_node(check)->color = RED;
                            left_rotate(parent_node(check));
                            sister = parent_node(check)->right;
                        }
                        if ((sister->left == nullptr || BLACK == sister->left->color) &&
                            (sister->right == nullptr || BLACK == sister->right->color)) {
                            sister->color = RED;
                            check = parent_node(check);
                        } else {
                            if (sister->right == nullptr || BLACK == sister->right->color) {
                                sister->left->color = BLACK;
                                sister->color = RED;
                                right_rotate(sister);
                                sister = parent_node(check)->right;
                            }
                            sister->color = parent_node(check)->color;
                            parent_node(check)->color = BLACK;
                            if (sister->right != nullptr)
                                sister->right->color = BLACK;
                            left_rotate(parent_node(check));
                            check = root;
                        }
                    } else {
                        node* sister = parent_node(check)->left;
                        if (RED == sister->color) {
                            sister->color = BLACK;
                            parent_node(check)->color = RED;
                            right_rotate(parent_node(check));
                            sister = parent_node(check)->left;
                        }
                        if ((sister->left == nullptr || BLACK == sister->left->color) &&
                            (sister->right == nullptr || BLACK == sister->right->color)) {
                            sister->color = RED;
                            check = parent_node(check);
                        } else {
                            if (sister->left == nullptr || BLACK == sister->left->color) {
                                sister->right->color = BLACK;
                                sister->color = RED;
                                left_rotate(sister);
                                sister = parent_node(check)->left;
                            }
                            sister->color = parent_node(check)->color;
                            if (sister->left != nullptr)
                                sister->left->color = BLACK;
                            parent_node(check)->color = BLACK;
                            right_rotate(parent_node(check));
                            check = root;
                        }
                    }
                }
                check->color = BLACK;
            }
            inline void pre_order(unsigned int index, const unsigned int offset, node* node, const unsigned int level, system_stream* out) const {
                if (node == nullptr) { return; }
                // 树放入数组中，由两个指标表示下标
                // 一个是父节点的下标，一个是父节点的左子（1）还是右子（2）
                // 既，根节点默认0，0
                // 这样父节点的下标乘以2，再加上一个数，即为本节点在数组中的下标
                index = index * 2 + offset;
                out->start(8u);
                out->append("[%4u]{level:%2u,\tcolor:%s\t,value:",
                            index, level, node->color ? "Black\0" : "Red\0");
                ((SERIAL*)node->value)->stream_print(out);
                out->append("}");
                out->end();
                pre_order(index, 1, node->left, level + 1, out);
                pre_order(index, 2, node->right, level + 1, out);
            }
            node* root;
            inline bool template_check(hickey* const data) const { auto* s = new SERIAL(); return s->sign() == data->sign(); }
        public:
            red_black_tree() { root = nullptr; }
            ~red_black_tree() override { delete root; }
            void append(hickey* value) {
                if(!template_check(value)) { return; }
                auto* new_node = new node(value);
                if (root == nullptr) {
                    new_node->color = BLACK;
                    root = new_node;
                }

                node* current = root;
                node* temp = current;
                for (; current != nullptr;) {
                    temp = current;
                    if (current->value->hash() > value->hash()) {
                        current = current->left;
                    } else if (current->value->hash() < value->hash()) {
                        current = current->right;
                    } else {
                        return;
                    }
                }

                if (temp->value->hash() > value->hash()) {
                    temp->left = new_node;
                } else {
                    temp->right = new_node;
                }
                new_node->parent = temp;
                fix_after_append(new_node);
            }
            void subtract(int hash_value) {
                node* delete_node = found(hash_value);
                if (delete_node == nullptr) { return; } //NOLINT 主要是消除抛出异常抛的是一个指针和类型没有继承标准库中的
                if (delete_node->left != nullptr && delete_node->right != nullptr) {
                    node* temp = successor(delete_node);
                    temp->value->clone(delete_node->value);
                    delete_node = temp;
                }
                node* replacement = delete_node->left == nullptr ? delete_node->right : delete_node->left;
                if (replacement == nullptr) {
                    if (delete_node->parent == nullptr) {
                        root = nullptr;
                    } else {
                        if (BLACK == delete_node->color) {
                            fix_after_subtract(delete_node);
                        }
                        if (delete_node == parent_node(delete_node)->left) {
                            parent_node(delete_node)->left = nullptr;
                        } else {
                            parent_node(delete_node)->right = nullptr;
                        }
                        delete_node->parent = nullptr;
                    }
                } else {
                    replacement->color = BLACK;
                    replacement->parent = parent_node(delete_node);
                    if (delete_node->parent == nullptr) {
                        root = replacement;
                    } else if (delete_node == parent_node(delete_node)->left) {
                        parent_node(delete_node)->left = replacement;
                    } else {
                        parent_node(delete_node)->right = replacement;
                    }
                    delete_node->parent = nullptr;
                    delete_node->left = nullptr;
                    delete_node->right = nullptr;
                }
                // 注意此处将数据部分的内存进行了回收，不需要再手动删除find找到的指针
                delete delete_node;
            }
            SERIAL* find(int hash_value) {
                node* new_node = found(hash_value);
                if (new_node == nullptr) { return nullptr; } //NOLINT 主要是消除抛出异常抛的是一个指针和类型没有继承标准库中的
                return (SERIAL*)new_node->value;
            }
            void scanning() const {
                auto* out = new system_stream(15u);
                pre_order(0u, 0, root, 1u, out);
                out->maybe(1u << 2u);
                out->append("输出的部分数据被缓冲了，直接释放内存，则不会显示ほんとうにすみませんでした");
                out->end();
            }
            bool equals(const hickey* target) const override { return target == this; }
            int hash() const override { return 0; }
            int clone(hickey *&target) const override { return 0; }
        };
    }
    // 测试用例，防止过多的maybe unused
    namespace {
        //测试用法
        class data_node final : public kie::serialize {
        private:
            int id;
            std::string* name;
        public:
            explicit data_node(int id = 0, const char* n = "") : id(id) { name = new std::string(n); }
            ~data_node() override { delete name; }
            int stream_print(kie::system_stream* out) override {
                out->append("{id:%d, name:%s}\n", id, name->c_str());
                return 1;
            }
            unsigned int sign() const override { return kie::utils::signal()->encode("data_n"); }
            int hash() const override { return static_cast<int>(kie::utils::signal()->hash_code(name->c_str())); }
            bool equals(const hickey* target) const override {
                if(sign() != target->sign()) { return false; }
                return id == ((data_node*)target)->id && name == ((data_node*)target)->name;
            }
            int clone(hickey *&target) const override {
                if(target == nullptr) { return 0; }
                if(sign() == target->sign()) {
                    if(target == this) {
                        target = new data_node(id, name->c_str());
                        return 2;
                    } else {
                        delete target;
                        target = new data_node(id, name->c_str());
                        return 1;
                    }
                } else { return 0; }
            }
        };

        int test() {
            // 栈测试
            {
                auto* s = new kie::stack<data_node>();
                s->push(new data_node(1, "alice"));
                s->push(new data_node(2, "tom"));
                auto* ss = new kie::stack<data_node>();
                s->clone(reinterpret_cast<kie::hickey*&>(ss));
                ss->equals(s);
                delete ss;
                delete s;
            }
            // 红黑树测试（非逻辑，既栈测试主要测是否可用，本主要测内存是否有问题）
            {
                auto* s = new kie::red_black_tree<data_node>();
                s->append(new data_node(1, "alice"));
                s->append(new data_node(2, "tom"));
                s->append(new data_node(3, "bob"));
                s->append(new data_node(4, "sj"));
                try {
                    s->find(1);
                } catch (kie::system_error *serror) { //NOLINT 主要是消除抛出异常抛的是一个指针和类型没有继承标准库中的
                    serror->error->end();
                    delete serror;
                }
                s->scanning();
                delete s;
            }
            return 0;
        }
    }
    // 虚拟CPU的实现，在原版基础上改进的写法（1，2版github上的testcpu 3，4，5此为5版）
    namespace cpu {
        //类型定义
        //统一类型，只有所占字节大小不同，都按整数类型进行处理
        typedef unsigned long u8int; //NOLINT
        typedef unsigned int u4int;
        typedef unsigned short u2int;
        typedef unsigned char u1int;
        typedef long s8int; //NOLINT
        typedef int s4int;
        typedef short s2int; //NOLINT
        typedef char s1int; //NOLINT

        class virtual_memory {
            //作为CPU自己的小cache
            //参考分页系统的内存思想，目前只用最简单的方式实现
        private:
            u1int use[16]{};
            u2int index[16]{};
            u4int memory[1024]{};
        public:
            virtual_memory() {
                for(u1int& i : use) {
                    i = 0;
                }
                index[0] = 1;
                index[1] = 17;
                index[2] = 33;
                index[3] = 49;
                index[4] = 65;
                index[5] = 81;
                index[6] = 97;
                index[7] = 113;
                index[8] = 129;
                index[9] = 161;
                index[10] = 193;
                index[11] = 225;
                index[12] = 257;
                index[13] = 321;
                index[14] = 385;
                index[15] = 513;
                for (u4int& i : memory) {
                    i = 0u;
                }
                // magic number
                memory[0] = 3260681415u;
            }
            ~virtual_memory() {
                // 只改变使用的部分
                // 参考内存申请之后不初始化出现奇怪的现象
                for(u1int& i : use) {
                    i = 0;
                }
            }
            u4int apply(const u4int size) {
                if (size == 0) { return 0u; }
                if (size <= 1u << 4u) {
                    for (s4int i = 0; i < 8; i++) {
                        if (use[i] == 0) {
                            use[i] = size;
                            return index[i];
                        }
                    }
                    return index[15];
                } else if (size <= 1u << 5u) {
                    for (s4int i = 0; i < 4; i++) {
                        if (use[8 + i] == 0) {
                            use[8 + i] = size;
                            return index[8 + i];
                        }
                    }
                    return index[15];
                } else if (size <= 1u << 6u) {
                    for (s4int i = 0; i < 2; i++) {
                        if (use[12 + i] == 0) {
                            use[12 + i] = size;
                            return index[12 + i];
                        }
                    }
                    return index[15];
                } else if (size <= 1u << 7u) {
                    if (use[14] == 0) {
                        use[14] = size;
                        return index[14];
                    }
                    return index[15];
                }
                return 0u;
            }
            s4int release(const u4int segment) {
                for (s4int i = 0; i < 16; i++) {
                    if (index[i] == segment) {
                        use[i] = 0;
                        return 1;
                    }
                }
                return 0;
            }
            s4int overlay(const u4int segment, const u4int offset, const u4int value) {
                // 写权限校验，无权限控制只对是否能够访问做限制
                for (s4int i = 0; i < 16; i++) {
                    if (index[i] == segment) {
                        if (use[i] > offset) {
                            memory[segment + offset] = value;
                            return 1;
                        }
                        break;
                    }
                }
                return 0;
            }
            u4int read(const u4int segment, const u4int offset) const {
                return memory[segment + offset];
            }
        };

        class function_member final : public kie::serialize {
        private:
            static const u4int MAGIC = 15436125u;
            s4int name_code;
            std::string* name;
            u4int value;
        public:
            explicit function_member(const char* n = "", int value = 0) : value(value) { name = new std::string(n); name_code = kie::utils::signal()->hash_code(name->c_str()); }
            ~function_member() override { delete name; }
            unsigned int sign() const override { return MAGIC; }
            int hash() const override { return name_code; }
            bool equals(const hickey* target) const override {
                if(sign() != target->sign()) { return false; }
                return value == ((function_member*)target)->value && name == ((function_member*)target)->name;
            }
            int stream_print(kie::system_stream* out) override {
                out->append("{\n\t'class':'function_member',\n\t'name_code':%d,\n\t'name':'%s',\n\t'value':%u\n}\n", name_code, name->c_str(), value);
                return 1;
            }
            int clone(hickey*& target) const override {
                if(target == nullptr) { return 0; }
                if(sign() == target->sign()) {
                    if(target == this) {
                        target = new function_member(name->c_str(), value);
                        return 2;
                    } else {
                        delete target;
                        target = new function_member(name->c_str(), value);
                        return 1;
                    }
                } else { return 0; }
            }
            u4int get() const { return value; }
        };

        class function_stack final : public kie::serialize {
        private:
            static const u4int MAGIC = 9549154u;
            u4int segment;
        public:
            explicit function_stack(u4int segment = 0u) : segment(segment) {}
            ~function_stack() override = default;
            int hash() const override { return segment; }
            unsigned int sign() const override { return MAGIC; }
            int stream_print(kie::system_stream* out) override {
                out->append("{\n\t'class':'function_stack',\n\t'segment':%u\n}\n", segment);
                return 1;
            }
            bool equals(const hickey* target) const override {
                if(sign() != target->sign()) { return false; }
                return segment == ((function_stack*)target)->segment;
            }
            int clone(hickey*& target) const override {
                if(target == nullptr) { return 0; }
                if(sign() == target->sign()) {
                    if(target == this) {
                        target = new function_stack(segment);
                        return 2;
                    } else {
                        delete target;
                        target = new function_stack(segment);
                        return 1;
                    }
                } else { return 0; }
            }
        };

        class virtual_register {
            //作为CPU中的寄存器组
            //考虑到硬件中的CPU访问寄存器，采用数组以下标的方式进行访问
        private:
            u4int array[15]{};
        public:
            virtual_register() {
                for (u4int& i : array) {
                    i = 0;
                }
            }
            ~virtual_register() {
                for (u4int& i : array) {
                    i = 0;
                }
            }
            s4int set(const s4int index, const u4int value) {
                array[index] = value;
                return 1;
            }
            u4int get(const s4int index) const {
                return array[index];
            }
        };

        //指令对应的函数
        using function = s4int (*)(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int mov(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int inc(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int dec(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int jnz(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int jny(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int cal(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);
        s4int ret(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs);

        class coding_tree {
            //二叉树结构，主要是保存统一的指令操作函数
            //存在中间结点浪费问题
        private:
            class coding_tree_node {
            public:
                function operation;
                coding_tree_node* left;
                coding_tree_node* right;
                coding_tree_node() {
                    operation = nullptr;
                    left = nullptr;
                    right = nullptr;
                }
                ~coding_tree_node() {
                    delete left;
                    delete right;
                }
            };
            coding_tree_node* base;
            bool bit_one(u1int code, u4int index_positive) const { return code & 1u << (index_positive - 1); } //NOLINT
        public:
            coding_tree() { base = new coding_tree_node(); }
            ~coding_tree() { delete base; }
            s4int generation(u1int code, function fun) const {
                coding_tree_node* node = base;
                for (s4int i = 3; i > 0; i--) {
                    if (bit_one(code, i)) {
                        if (node->right == nullptr) {
                            node->right = new coding_tree_node();
                        }
                        node = node->right;
                    } else {
                        if (node->left == nullptr) {
                            node->left = new coding_tree_node();
                        }
                        node = node->left;
                    }
                }
                node->operation = fun;
                return 1;
            }
            function found(u4int code) const {
                u1int first = code >> 24u;
                coding_tree_node* node = base;
                for (s4int i = 3; i > 0; i--) {
                    if (bit_one(first, i)) {
                        node = node->right;
                    } else {
                        node = node->left;
                    }
                    if (node == nullptr) {
                        return nullptr;
                    }
                }
                return node->operation;
            }
        };

        s4int mov(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs) {
            u4int first = code >> 24u;
            u4int second = (code << 8u) >> 24u;
            u4int third = (code << 16u) >> 16u;

            if (first != 8u) { return 0; }

            if (third > 1u << 15u) {
                third = third >> 8u;
                ncr->set(second - 129, ncr->get(third - 129));
            } else {
                ncr->set(second - 129, third);
            }
            nc++;
            return 1;
        }

        s4int inc(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs) {
            u4int first = code >> 24u;
            u4int second = (code << 8u) >> 24u;

            if (first != 9u) { return 0; }

            ncr->set(second - 129, ncr->get(second - 129) + 1);
            nc++;
            return 1;
        }

        s4int dec(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs) {
            u4int first = code >> 24u;
            u4int second = (code << 8u) >> 24u;

            if (first != 10u) { return 0; }

            ncr->set(second - 129, ncr->get(second - 129) - 1);
            nc++;
            return 1;
        }

        s4int jnz(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs) {
            u4int first = code >> 24u;
            u4int second = (code << 8u) >> 24u;
            u4int third = (code << 16u) >> 16u;

            if (first != 12u) { return 0; }

            if (ncr->get(second - 129) == 0) {
                nc++;
            } else {
                nc = nc - third;
            }
            return 1;
        }

        s4int jny(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs) {
            u4int first = code >> 24u;
            u4int second = (code << 8u) >> 24u;
            u4int third = (code << 16u) >> 16u;

            if (first != 13u) { return 0; }

            if (ncr->get(second - 129) == 0) {
                nc++;
            } else {
                nc = nc + third;
            }
            return 1;
        }

        s4int cal(u4int& nc, u4int code, virtual_register* ncr, virtual_memory* mem, kie::stack<function_stack>* scf, u4int& cs) {
            u4int first = code >> 24u;
            u4int second = (code << 8u) >> 24u;
            u4int third = (code << 16u) >> 16u;

            if (first != 14u) { return 0; }

            nc++;
            u4int segment = mem->apply(12u);
            scf->push(new function_stack(segment));
            mem->overlay(segment, 1, cs);
            mem->overlay(segment, 2, nc);
            mem->overlay(segment, 3, ncr->get(4));
            mem->overlay(segment, 4, ncr->get(5));
            mem->overlay(segment, 5, ncr->get(6));
            mem->overlay(segment, 6, ncr->get(7));
            mem->overlay(segment, 7, ncr->get(8));
            mem->overlay(segment, 8, ncr->get(9));
            mem->overlay(segment, 9, ncr->get(10));
            mem->overlay(segment, 10, ncr->get(11));
            mem->overlay(segment, 11, ncr->get(12));

            if (second == 0) { cs = third; }
            nc = 0;
            return 1;
        }

        s4int ret(u4int& nc, const u4int code, virtual_register* ncr, virtual_memory* const mem, kie::stack<function_stack>* const scf, u4int& cs) {
            u4int first = code >> 24u;

            if (first != 15u) { return 0; }

            auto* s = new function_stack();
            scf->pop(reinterpret_cast<kie::hickey*&>(s));
            u4int segment = s->hash();
            cs = mem->read(segment,1);
            nc = mem->read(segment,2);
            ncr->set(4,mem->read(segment,3));
            ncr->set(5,mem->read(segment,4));
            ncr->set(6,mem->read(segment,5));
            ncr->set(7,mem->read(segment,6));
            ncr->set(8,mem->read(segment,7));
            ncr->set(9,mem->read(segment,8));
            ncr->set(10,mem->read(segment,9));
            ncr->set(11,mem->read(segment,10));
            ncr->set(12,mem->read(segment,11));
            mem->release(segment);
            return 1;
        }

        class counter_step {
            //主体
            //pc程序计数器，记录一个生命周期里所执行的指令数
            //cs当前访问指令的起始位置，调用函数时修改此值，即可实现跳转
            //nc访问指令的偏移，用于获取下一跳指令
        private:
            s4int pc;
            u4int cs;
            u4int nc;
            virtual_register* ncr;
            virtual_memory* vmm;
            kie::stack<function_stack>* scf;
            coding_tree* ins;
            kie::red_black_tree<function_member>* fm;
            u4int constant(const std::string& str) const { //NOLINT
                std::string sta[22] = {
                        "mov", "inc", "dec", "jnz", "jny", "cal", "ret",
                        "ax", "bx", "cx", "dx",
                        "e1x", "e2x", "e3x", "e4x", "e5x", "e6x", "e7x", "e8x", "e9x",
                        "rx", "fx"
                };
                u4int stb[22] = {
                        8u, 9u, 10u, 12u, 13u, 14u, 15u,
                        129u, 130u, 131u, 132u,
                        133u, 134u, 135u, 136u, 137u, 138u, 139u, 140u, 141u,
                        142u, 143u
                };
                for (int i = 0; i < 22; i++) {
                    if (sta[i] == str) {
                        return stb[i];
                    }
                }
                return 0u;
            }
            u4int only_name(const std::string& str) const { auto* s = fm->find((int)kie::utils::signal()->hash_code(str.c_str())); return s == nullptr ? 0u : s->get(); }
            u4int calculate(s4int index, const std::string& word) const {
                if (constant(word) == 0 && index == 2) {
                    if (only_name(word) != 0) { return only_name(word); }
                    s4int number = std::stoi(word);
                    if (number < 0) {
                        return 0u;
                    } else {
                        return (u4int)number;
                    }
                } else {
                    u4int number = constant(word);
                    if (index == 0) {
                        return number << 24u;
                    } else if (index == 1) {
                        return number << 16u;
                    } else {
                        return number << 8u;
                    }
                }
            }
        public:
            counter_step() {
                pc = 0;
                cs = 1;
                nc = 0;
                ncr = new virtual_register();
                vmm = new virtual_memory();
                scf = new kie::stack<function_stack>();
                ins = new coding_tree();
                ins->generation(8u, mov);
                ins->generation(9u, inc);
                ins->generation(10u, dec);
                ins->generation(12u, jnz);
                ins->generation(13u, jny);
                ins->generation(14u, cal);
                ins->generation(15u, ret);
                fm = new kie::red_black_tree<function_member>();
            }
            ~counter_step() {
                delete ncr;
                delete vmm;
                delete scf;
                delete ins;
                delete fm;
            }
            s4int read(const char* name, u4int length = 0, const char* file = nullptr) {
                if (fm->find((int)kie::utils::signal()->hash_code(name)) != nullptr) { return 0; }
                std::string str;
                u4int segment = 0;
                if (file == nullptr) {
                    if (length == 15) {
                        str = "mov e1x 12\n"
                              "mov e2x 31\n"
                              "mov e3x 5\n"
                              "mov e4x 36\n"
                              "mov ax e1x\n"
                              "mov bx e2x\n"
                              "cal 0 17\n"
                              "mov e5x rx\n"
                              "mov ax e3x\n"
                              "mov bx e4x\n"
                              "cal 0 17\n"
                              "mov ax e5x\n"
                              "mov bx rx\n"
                              "cal 0 17\n"
                              "mov e6x rx";
                        segment = vmm->apply(length);
                    } else if (length == 9) {
                        str = "mov e1x ax\n"
                              "mov e2x bx\n"
                              "cal 0 33\n"
                              "mov dx rx\n"
                              "inc e1x\n"
                              "dec e2x\n"
                              "jnz e2x 2\n"
                              "mov rx e1x\n"
                              "ret";
                        segment = vmm->apply(length);
                    } else if (length == 11) {
                        str = "mov e1x ax\n"
                              "mov e2x bx\n"
                              "dec ax\n"
                              "dec bx\n"
                              "jny ax 2\n"
                              "jny bx 4\n"
                              "jnz bx 4\n"
                              "mov rx e1x\n"
                              "ret\n"
                              "mov rx e2x\n"
                              "ret";
                        segment = vmm->apply(length);
                    }
                } else {
                    if (length == 0) {
                        str = "";
                        std::ifstream in_read(file, std::ios::in);
                        s4int number = 0;
                        for (std::string line; std::getline(in_read, line);) {
                            number++;
                            str.append(line).append("\n");
                        }
                        segment = vmm->apply(number);
                    } else {
                        str = file;
                        segment = vmm->apply(length);
                    }
                }
                if (segment == 0) { return 0; }
                // 真正的主要部分，注意stoi可能抛出异常，出现说明有地方写错了，不做捕获处理（编译器做好后，不会出现这类问题，出现说明编译器有bug）
                std::vector<std::string> lines = kie::utils::signal()->spilt(str, "\n");
                for (s4int i = 0; i < lines.size(); i++) {
                    std::vector<std::string> words = kie::utils::signal()->spilt(lines[i], " ");
                    u4int code = 0;
                    for (s4int j = 0; j < words.size(); j++) {
                        code = code + calculate(j,words[j]);
                    }
                    vmm->overlay(segment, i, code);
                }
                // 函数名处理，只做了15位
                fm->append(new function_member(name, segment));
                if (fm->find((int)kie::utils::signal()->hash_code("main")) != nullptr) { auto* s = fm->find((int)kie::utils::signal()->hash_code("main")); cs = s->get(); nc = 0u; }
                return 1;
            }
            s4int interlude(const char* name = "main") {
                auto* s = fm->find((int)kie::utils::signal()->hash_code(name));
                u4int segment = s->get();
                fm->subtract((int)kie::utils::signal()->hash_code(name));
                if (segment != 0) {
                    return vmm->release(segment);
                }
                return 0;
            }
            s4int step_by_step() {
                if (pc >= 0 && pc < 2000000000) {
                    u4int code = vmm->read(cs, nc);
                    if (code == 0) { return 0; }
                    function fun = ins->found(code);
                    if (fun == nullptr) { return 0; }
                    if (fun(nc, code, ncr, vmm, scf, cs) == 0) { return 0; }
                    pc++;
                    return 1;
                } else {
                    return 0;
                }
            }
            s4int result() const {
//                std::printf("ありがとうごじゃいます\n");
//                std::printf("pc = [0x%08X(%d)]\n", pc, pc);
//                std::printf("[0x%08X(%d)]\n", ncr->get(2), ncr->get(2));
//                std::printf("[0x%08X(%d)]\n", ncr->get(3), ncr->get(3));
                auto* out = new kie::system_stream(15u,8u);
                out->append("ありがとうごじゃいます");
                out->end();
                out->start(8u);
                out->append("pc = [0x%08X(%d)]\tcx [0x%08X(%d)]\tdx [0x%08X(%d)]", pc, pc, ncr->get(2), ncr->get(2), ncr->get(3), ncr->get(3));
                out->end();
                out->start(8u);
                out->append("目前，15个寄存器中，规定的用法：rx为固定的返回值寄存器（非必要不做其他用处），fx为预留的调用函数，前面的4个寄存器则作为参数使用，局部变量寄存器使用中间的9个寄存器。因为目前实现的关系，非引用传参任何寄存器都可以。");
                out->end();
                out->start(4u);
                out->append("間違いはありませんが、異常がないかどうかは再確認が必要です");
                out->end();
                delete out;
                return 1;
            }
        };
    }

    //  创建日期  2022-08-29
    //  相关说明包含测试用例，用于纪录版本，如果已有内容需要替换，则通过注释保存更换之前的内容
    //  对于大部分函数，默认的返回值类型为int，且正常结束为1，一般错误结束为0
    //  版本日志  ====  ====
    //  ==== 2022-08-30 ====
    //  基本框架主要部分基本完成，同时测试也没有问题
    //  不过引发了另一个思考，是不是不使用纯虚函数比较合适
    //  ==== 2022-08-31 ====
    //  将虚拟CPU进一步更新，使其中所需要使用的部分数据结构变得更加灵活
    //  ==== 2022-09-06 ====
    //  通过测试，将基本框架部分进行完善调整
    //  主要是对一些虚函数进行操作权限限制
    int interpreter_cpu_main() {
        test();
        auto* time = new kie::system_stream(1u,1u);
        auto* counter = new cpu::counter_step();
        //第一步
        {
            //加载函数
            auto* out = new kie::system_stream(1u);
            if (counter->read("add", 0, "../cpu/cpu_add.kuu") == 0) {
                out->maybe(1u);
                out->append("加载函数add时内存が足りないのかもしれません");
            }
            if (counter->read("sub", 0, "../cpu/cpu_sub.kuu") == 0) {
                out->maybe(1u);
                out->append("加载函数seb时内存が足りないのかもしれません");
            }
            if (counter->read("gather", 0, "../cpu/cpu_gather.kuu") == 0) {
                out->maybe(1u);
                out->append("加载函数gather时内存が足りないのかもしれません");
            }
            if (counter->read("test", 0, "../cpu/test_array_spacing.kuu") == 0) {
                out->maybe(1u);
                out->append("加载函数test时内存が足りないのかもしれません");
            }
            if (counter->read("main", 1, "cal 0 test") == 0) {
                out->maybe(1u);
                out->append("加载函数main时内存が足りないのかもしれません");
            }
            out->end();
        }
        //第二步
        for (;;) {
            if (counter->step_by_step() == 0) { break; }
        }
        //第三步
        counter->result();
        //结束
        //测试
        //第壹步
        if (counter->interlude() == 0) {
            auto* out = new kie::system_stream(1u << 1u, 1u << 1u);
            out->append("気をつけて清理加载的函数内存に異常が出る");
            out->end();
            delete out;
        }
        //第贰步
        if (counter->read("main", 8, "mov ax 10000\nmov bx ax\ndec bx\njnz bx 1\ndec ax\njnz ax 4\nmov cx ax\nmov dx bx") == 0) {
            auto* out = new kie::system_stream(1u, 1u);
            out->append("加载函数main时内存が足りないのかもしれません");
            out->end();
            delete out;
        }
        //第弎步
        for (;;) {
            if (counter->step_by_step() == 0) { break; }
        }
        //第肆步
        counter->result();
        //结束
        time->end();
        return 0;
    }
}

#endif //INTERPRETER_CPU_H
