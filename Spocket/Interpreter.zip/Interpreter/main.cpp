#include <iostream>
#include "cpu/cpu_main_inter.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    cpu_main_inter();
    return 0;
}
