#include <iostream>
#include "cpu.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    //system为执行脚本命令与exec区别
    //Windows默认代码页936 编码为GBK 说明简体中文 可能与系统语言有关 不是utf-8(65001)编码存在乱码问题
    system("chcp 65001");

    kuu::interpreter_cpu_main();
    return 0;
}
