#include <iostream>
#include "cpu/cpu_main_inter.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    cpu_main_inter();
    return 0;
}

//寄存器类
//基于类有16个寄存器实例，ax、bx、cx、dx等等
//大内存，寻址方式，分页系统，一次直接读一块
//mov 寄存器 立即数或寄存器
//inc
//dec
//jnz
//call 换页
//ret 回页
//实现函数调用
//读文件，加载到内存
//实现调度（非CPU调度）
//再加上中断处理
